import os, sys; sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
"""Reproduce Kim et al. 2007 Fig. 2 (lumped 18650 oven test) to pin down the t_sei convention."""
import numpy as np
from scipy.integrate import solve_ivp
R=8.314; SIG=5.670374419e-8
A=dict(sei=1.667e15, ne=2.5e13, pe=6.667e13, e=5.14e25)
E=dict(sei=1.3508e5, ne=1.3508e5, pe=1.396e5, e=2.74e5)
H=dict(sei=257., ne=1714., pe=314., e=155.)            # J/g
Wc,Wp,We,rcp = 6.104e5, 1.221e6, 4.069e5, 2.789e6        # g/m3, g/m3, g/m3, J/m3K  (Kim Table 1)
D,Hh=0.018,0.065; V=np.pi*(D/2)**2*Hh; Aext=np.pi*D*Hh+2*np.pi*(D/2)**2
h,eps=7.17,0.8                                           # Kim Sec 3.1
def run(Toven_C, z_init, z_ref, t_end=150*60):
    To=Toven_C+273.15
    def f(t,y):
        T,cs,cn,z,a,ce=y
        Rs=A['sei']*np.exp(-E['sei']/(R*T))*max(cs,0)
        Rn=A['ne']*np.exp(-z/z_ref)*max(cn,0)*np.exp(-E['ne']/(R*T))
        Rp=A['pe']*max(a,0)*max(1-a,0)*np.exp(-E['pe']/(R*T))
        Re=A['e']*np.exp(-E['e']/(R*T))*max(ce,0)
        S=(H['sei']*Wc*Rs+H['ne']*Wc*Rn+H['pe']*Wp*Rp+H['e']*We*Re)*V   # W
        Qx=h*Aext*(To-T)+eps*SIG*Aext*(To**4-T**4)
        return [(S+Qx)/(rcp*V), -Rs, -Rn, Rn, Rp, -Re]
    sol=solve_ivp(f,(0,t_end),[35+273.15,0.15,0.75,z_init,0.04,1.0],method='LSODA',rtol=1e-7,atol=1e-10,max_step=5)
    T=sol.y[0]-273.15; i=np.argmax(T)
    run.c_ne_end = sol.y[2, -1]
    return T.max(), sol.t[i]/60
READINGS = [(0.033, 0.033, "literal: z(0) = z_ref = 0.033"), (0.15, 0.033, "adopted: z(0) = 0.15, z_ref = 0.033"),
            (0.033, 0.15, "swapped: z(0) = 0.033, z_ref = 0.15")]
if __name__ == "__main__":
    import json
    out = {"readings": [], "scan": []}
    for zi, zr, lab in READINGS:
        for To in (150, 155):
            Tm, tm = run(To, zi, zr)
            out["readings"].append({"reading": lab, "oven_C": To, "peak_C": Tm, "t_peak_min": tm, "overshoot_K": Tm - To, "c_ne_end": run.c_ne_end})
            print(f"{lab:40s} oven {To} C: peak {Tm:6.1f} C at {tm:5.1f} min, overshoot {Tm-To:6.1f} K")
    for To in (144, 145, 146, 147, 148, 149, 150):          # adopted reading, 150-min horizon
        Tm, tm = run(To, 0.15, 0.033)
        out["scan"].append({"oven_C": To, "peak_C": Tm, "t_peak_min": tm, "overshoot_K": Tm - To})
        print(f"adopted reading, oven {To} C: overshoot {Tm-To:6.1f} K at {tm:5.1f} min")
    print("Kim Fig. 2: 150 C -> no runaway; 155 C -> runaway near 50-60 min")
    os.makedirs(os.path.join(os.path.dirname(__file__), "..", "analysis", "review"), exist_ok=True)
    json.dump(out, open(os.path.join(os.path.dirname(__file__), "..", "analysis", "review", "kim_benchmark.json"), "w"), indent=1)
