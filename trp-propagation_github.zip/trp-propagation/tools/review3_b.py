"""#12 seed-block bootstrap for P(esc|K); #13 regression composition and refit with delivered vent energy;
#15 closed-form parameter correlations; #16 whole-surface (probit) slope estimator for P5 ratios."""
from review_common import *
import json, statsmodels.api as sm
from scipy.stats import norm
L = {}
P1 = pd.read_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl"))
Pp = P1.groupby("point").esc.mean(); Nn = P1.groupby("point").size(); tp = Pp[(Pp >= 0.05) & (Pp <= 0.95) & (Nn >= 200)].index
T = P1[P1.point.isin(tp)].copy()
# ---- #12 seed-block bootstrap of P(esc | K) at transition points
seeds = np.sort(T.seed.unique()); rng = np.random.default_rng(0); bs = {k: [] for k in range(5)}
by = {s: g for s, g in T.groupby("seed")}
for _ in range(2000):
    smp = pd.concat([by[s] for s in rng.choice(seeds, len(seeds))])
    for k in range(5):
        g = smp[smp.n_r1_trig == k]
        if len(g): bs[k].append(g.esc.mean())
L["PescK_bootstrap"] = {k: {"P": float(T[T.n_r1_trig == k].esc.mean()), "n": int((T.n_r1_trig == k).sum()), "ci": list(np.percentile(bs[k], [2.5, 97.5])) if bs[k] else None,
                            "per_point_median": float(T[T.n_r1_trig == k].groupby("point").esc.mean().median()) if (T.n_r1_trig == k).any() else None} for k in range(5)}
# ---- #13 composition and refit with the initiator's delivered vent energy
T["filler"] = T.G.map(gname); L["transition_composition"] = T.groupby(["filler", "h_c"]).point.nunique().reset_index().rename(columns={"point": "points"}).to_dict("records")
EJ = {int(k): v["E_ej_kJ"] for k, v in json.load(open(os.path.join(OUT, "R3_initiator_ejecta.json"))).items()}
T["vent_ini_kJ"] = [EJ[int(s_)] * e / 4 for s_, e in zip(T.seed, T.eta)]      # captured ejecta energy delivered to each neighbour
T["ej_ini_kJ"] = [EJ[int(s_)] for s_ in T.seed]
X0 = pd.get_dummies(T.point, drop_first=True, dtype=float); out = {}
for nm, cols in (("fej", ["Tz", "fz"]), ("delivered_vent", ["Tz", "vz"])):
    X = X0.copy(); X["Tz"] = (T.Ttrig_r1_min - T.Ttrig_r1_min.mean()) / 12.0
    X["fz"] = (T.fej_ini - T.fej_ini.mean()) / 0.0433; X["vz"] = (T.ej_ini_kJ - T.ej_ini_kJ.mean()) / T.ej_ini_kJ.std()
    X = sm.add_constant(X[[c for c in X.columns if c not in ("fz", "vz") or c in cols]])
    m = sm.Logit(T.esc.values, X).fit(disp=False, method="bfgs", maxiter=3000, cov_type="cluster", cov_kwds={"groups": T.seed.values})
    k = cols[1]
    out[nm] = {"OR": float(np.exp(m.params[k])), "CI": list(np.exp(m.params[k] + np.array([-1.96, 1.96]) * m.bse[k])), "OR_Tmin": float(np.exp(m.params["Tz"])), "AIC": float(m.aic)}
out["ej_scale_kJ"] = float(T.ej_ini_kJ.std()); out["corr_fej_ej"] = float(np.corrcoef(T.fej_ini, T.ej_ini_kJ)[0, 1]); L["regression_vent"] = out
L["formula"] = "logit P(escape) = alpha_point + b1 (T_trig,min - mean)/12 + b2 (f_ej,ini - mean)/0.043 + b3 (mean f_ej,r1 - mean)/0.022"
# ---- #15 closed-form parameter correlations (seed-block bootstrap on the fine grid)
p = A.tidy(os.path.join(RES, "P7d_fine.jsonl.gz")); E = p.pivot_table(index=["G", "h_c", "eta"], columns="seed", values="esc"); ns = E.shape[1]
A_s, fEz, dT = 0.008, 0.825 * 83.9e3 / 4, 185.0
def cfit(cols):
    pts = []
    for (G, h), sub in E.groupby(level=[0, 1]):
        e_ = sub.index.get_level_values(2).values; M = sub.values[:, cols]; k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
        xs, fit = A.pava(e_, k / np.maximum(n, 1), np.maximum(n, 1)); v = A.crossing(xs, fit, 0.1)
        if np.isfinite(v): pts.append((G, h, v))
    G, h, v = map(np.array, zip(*pts)); X = np.column_stack([np.ones_like(h), h * A_s, 3 * G])
    return np.linalg.lstsq(X, v * fEz / dT, rcond=None)[0]
rng = np.random.default_rng(0); bb = np.array([cfit(rng.integers(0, ns, ns)) for _ in range(500)])
cr = np.corrcoef(bb.T); L["closed_corr"] = {"C_tauh": float(cr[0, 1]), "C_tauG": float(cr[0, 2]), "tauh_tauG": float(cr[1, 2])}
# ---- #16 whole-surface probit slope estimator for the P5 variants (and P6e controls)
P5 = A.tidy(os.path.join(RES, "P5_robustness.jsonl.gz")); P6 = A.tidy(os.path.join(RES, "P6e_lumped.jsonl.gz")); P6["tag"] = P6.point.str.split("|").str[0].str[2:]
D = pd.concat([P5, P6], ignore_index=True)
def surf_slope(g):
    # P(esc) = Phi((eta - a - b*h)/s): probit in eta and h; b = -coef_h/coef_eta
    X = sm.add_constant(np.column_stack([g.eta.values, g.h_c.values]))
    m = sm.GLM(g.esc.values, X, family=sm.families.Binomial(link=sm.families.links.Probit())).fit()
    return -m.params[2] / m.params[1]
rows = []
for G in (0.013, 0.102):
    for tag, g in D[np.isclose(D.G, G)].groupby("tag"):
        g = g[g.h_c <= 75]
        if g.esc.nunique() < 2: continue
        rows.append({"variant": tag, "filler": gname(G), "surface_slope": surf_slope(g)})
s = pd.DataFrame(rows); base = s[s.variant == "baseline"].set_index("filler").surface_slope
s["surface_ratio"] = s.apply(lambda r: r.surface_slope / base[r.filler], axis=1)
cb = pd.concat([pd.read_csv(os.path.join(OUT, "P5_slope_ratios_bootstrap.csv")), pd.read_csv(os.path.join(OUT, "P6e_slope_ratios_bootstrap.csv"))])
s = s.merge(cb[["variant", "filler", "ratio", "predicted"]], on=["variant", "filler"], how="left")
s.to_csv(os.path.join(OUT, "R3_surface_slopes.csv"), index=False); L["surface_slopes"] = s.round(4).to_dict("records")
json.dump(L, open(os.path.join(OUT, "ledger_R3b.json"), "w"), indent=1, default=float)
print(json.dumps({k: L[k] for k in ("PescK_bootstrap", "regression_vent", "closed_corr")}, indent=0, default=lambda x: round(float(x), 4)))
print(pd.DataFrame(L["transition_composition"]).to_string(index=False)); print(s.round(3).to_string(index=False))
