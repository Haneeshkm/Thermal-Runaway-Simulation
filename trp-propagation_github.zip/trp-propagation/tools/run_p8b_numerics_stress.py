import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import campaign as C
base = [("G=potting1_2mm|eta=1.5|h=2", dict(eta_lo=1.5, eta_hi=1.5, G_lo=C.G_CASES["potting1_2mm"], G_hi=C.G_CASES["potting1_2mm"], h_c=2.0)),
        ("G=air_2mm|eta=1.35|h=75", dict(eta_lo=1.35, eta_hi=1.35, G_lo=C.G_CASES["air_2mm"], G_hi=C.G_CASES["air_2mm"], h_c=75.0)),
        ("V=dir1|G=air_2mm|eta=0.5|h=2", dict(eta_lo=0.5, eta_hi=0.5, G_lo=C.G_CASES["air_2mm"], G_hi=C.G_CASES["air_2mm"], h_c=2.0, vent_split="dirichlet", split_conc=1.0))]
P = []
for name, ov in base:
    P.append(C.point(f"N=dt0.05|{name}", dt=0.05, n_fine=50, n_coarse=5, **ov))
    P.append(C.point(f"N=substep_half|{name}", n_fine=200, n_coarse=20, **ov))
C.run(P, seeds=range(60), out=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results_v2', 'P8b_numerics_stress.jsonl.gz'), workers=1, base='v2.1', verbose=False)
