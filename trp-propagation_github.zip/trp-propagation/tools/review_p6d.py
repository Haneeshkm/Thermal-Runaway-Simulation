"""P6d: directional (Dirichlet) vent split vs equal split. Boundary, linearity, first-ring structure, partial cascades."""
from review_common import *
p = A.tidy(os.path.join(RES, "P6d_split.jsonl.gz")); p["tag"] = p.point.str.split("|").str[0].str[2:]
base = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); base["tag"] = "equal"
base = base[base.G.isin([0.013, 0.102]) & base.h_c.isin([2, 10, 35, 75])]
allp = pd.concat([base, p], ignore_index=True)
crit = A.critical_eta(allp, levels=(0.1, 0.5), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "P6d_critical_eta.csv"), index=False)
print(crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10").round(3).to_string())
fit = rule_fit(crit); fit.to_csv(os.path.join(OUT, "P6d_rule.csv"), index=False); print(fit.round(4).to_string(index=False))
# cascade structure at transition points (0.05 <= P <= 0.95) of each split
rows = []
for tag, g in allp.groupby("tag"):
    P = g.groupby("point").esc.mean(); tp = P[(P >= 0.05) & (P <= 0.95)].index; s = g[g.point.isin(tp)]
    k = {f"P(esc|K={i})": (s[s.n_r1_trig == i].esc.mean() if (s.n_r1_trig == i).any() else np.nan) for i in range(5)}
    nk = {f"n(K={i})": int((s.n_r1_trig == i).sum()) for i in range(5)}
    e = s[s.esc == 1]
    rows.append({"split": tag, "transition_points": len(tp), "runs": len(s), "partial_frac_all": ((s.n_trig > 1) & (s.n_trig < 25)).mean(),
                 "full_given_escape": (e.n_trig == 25).mean() if len(e) else np.nan, **nk, **k})
st = pd.DataFrame(rows); st.to_csv(os.path.join(OUT, "P6d_structure.csv"), index=False)
pd.set_option("display.width", 250); print(st.round(3).to_string(index=False))
