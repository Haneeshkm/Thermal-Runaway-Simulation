"""Test: does the energy captured by the most exposed neighbour (eta_eff = z*eta*w_max of the initiator)
collapse equal and directional splits onto one escape curve?  Weights are regenerated exactly from the engine's
keyed random streams (same call as in trp_v2.run)."""
from review_common import *
import trp_v2 as V
p = A.tidy(os.path.join(RES, "P6d_split.jsonl.gz")); p["tag"] = p.point.str.split("|").str[0].str[2:]
base = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); base["tag"] = "equal"
base = base[base.G.isin([0.013, 0.102]) & base.h_c.isin([2, 10, 35, 75])]
def wmax(seed, conc):
    # initiator at the centre: offsets (0,0); 5x5 interior cell has all four neighbours
    return V._rng(seed, "split", 0, 0).dirichlet([conc] * 4).max()
p["conc"] = np.where(p.tag == "dir1", 1.0, 4.0)
p["w_max"] = [wmax(s, c) for s, c in zip(p.seed, p.conc)]
base["w_max"] = 0.25
allp = pd.concat([base, p], ignore_index=True); allp["eta_eff"] = 4 * allp.eta * allp.w_max
allp["d_dir4"] = (allp.tag == "dir4").astype(int); allp["d_dir1"] = (allp.tag == "dir1").astype(int)
import statsmodels.formula.api as smf
rows = []
for (G, h), g in allp.groupby(["G", "h_c"]):
    for var in ("eta", "eta_eff"):
        m = smf.logit(f"esc ~ {var} + d_dir4 + d_dir1", data=g).fit(disp=False, method="bfgs", maxiter=1000)
        tags = ["d_dir4", "d_dir1"]
        rows.append({"filler": gname(G), "h_c": h, "x": var, "split_effects": " ".join(f"{c[2:]}={m.params[c]:+.2f}(p={m.pvalues[c]:.2g})" for c in tags),
                     "max_abs_split_logodds": max(abs(m.params[c]) for c in tags), "llf": m.llf})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "P6d_collapse.csv"), index=False)
pd.set_option("display.width", 250); print(t.round(3).to_string(index=False))
# critical eta_eff at 10% per split from a logistic fit in eta_eff (pooled over seeds)
crow = []
for (G, h, tag), g in allp.groupby(["G", "h_c", "tag"]):
    if g.esc.nunique() < 2: continue
    m = smf.logit("esc ~ eta_eff", data=g).fit(disp=False, method="bfgs", maxiter=1000)
    b0, b1 = m.params; crow.append({"filler": gname(G), "h_c": h, "split": tag, "eta_eff10": (np.log(0.1 / 0.9) - b0) / b1})
c = pd.DataFrame(crow); c.to_csv(os.path.join(OUT, "P6d_eta_eff10.csv"), index=False)
print(c.pivot_table(index=["filler", "h_c"], columns="split", values="eta_eff10").round(3).to_string())
