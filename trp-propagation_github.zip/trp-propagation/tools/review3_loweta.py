"""Strong (and one mild) directional split extended below eta = 0.5; merged with P6d (seeds 0-39) for crossings."""
from review_common import *
import json
lo = A.tidy(os.path.join(RES, "P8c_loweta.jsonl.gz")); p6 = A.tidy(os.path.join(RES, "P6d_split.jsonl.gz"))
p6 = p6[p6.seed < 40]
for d in (lo, p6): d["tag"] = d.point.str.split("|").str[0].str[2:]
keys = set(zip(lo.tag, lo.G.round(4), lo.h_c)); p6 = p6[[k in keys for k in zip(p6.tag, p6.G.round(4), p6.h_c)]]
allp = pd.concat([lo, p6], ignore_index=True)
crit = A.critical_eta(allp, levels=(0.1, 0.5), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "R3_loweta_critical.csv"), index=False)
P = allp.groupby(["tag", "G", "h_c", "eta"]).esc.mean().unstack("eta")
print(P.round(3).to_string()); print(crit[["tag", "filler", "h_c", "eta10", "eta10_lo", "eta10_hi", "eta50"]].round(3).to_string(index=False))
json.dump({"runs": len(lo), "crit": crit[["tag", "filler", "h_c", "eta10", "eta10_lo", "eta10_hi", "eta50"]].round(4).to_dict("records")}, open(os.path.join(OUT, "ledger_R3_loweta.json"), "w"), indent=1, default=float)
