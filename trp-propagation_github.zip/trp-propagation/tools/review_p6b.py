"""P6b: fine eta grid (0.02) around the boundary vs the coarse-grid (P1b) estimate at the same (filler, h_c)."""
from review_common import *
fine = A.tidy(os.path.join(RES, "P6b_refine.jsonl.gz")); fine["tag"] = "fine"
cf = A.critical_eta(fine, levels=(0.1, 0.5), B=1000)
coarse = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv"))
rows = []
for _, r in cf.iterrows():
    c = coarse[np.isclose(coarse.G, r.G) & np.isclose(coarse.h_c, r.h_c)].iloc[0]
    rows.append({"filler": gname(r.G), "h_c": r.h_c, "eta10_coarse": c.eta10, "eta10_coarse_CI": f"{c.eta10_lo:.3f}-{c.eta10_hi:.3f}",
                 "eta10_fine": r.eta10, "eta10_fine_CI": f"{r.eta10_lo:.3f}-{r.eta10_hi:.3f}", "d10": r.eta10 - c.eta10,
                 "eta50_coarse": c.eta50, "eta50_fine": r.eta50, "d50": r.eta50 - c.eta50})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "P6b_fine_vs_coarse.csv"), index=False); print(t.round(3).to_string(index=False))
# implied slope between h_c = 5 and 35 on each grid
for g in ("air_2mm", "silicone_2mm"):
    s = t[t.filler == g].sort_values("h_c")
    print(g, "slope 5->35: coarse %.4f  fine %.4f" % ((s.eta10_coarse.iloc[1] - s.eta10_coarse.iloc[0]) / 30, (s.eta10_fine.iloc[1] - s.eta10_fine.iloc[0]) / 30))
