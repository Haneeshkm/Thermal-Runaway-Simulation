"""P7b: merge seeds 40-199 at 28 near-boundary points with P1b; recompute the coarse-grid crossings and compare."""
from review_common import *
import json
p1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); ex = A.tidy(os.path.join(RES, "P7b_extend.jsonl.gz"))
assert set(ex.point) <= set(p1.point)
key1 = set(zip(p1.point, p1.seed)); dup = ex[[k in key1 for k in zip(ex.point, ex.seed)]]
d1 = p1.set_index(["point", "seed"]); same = sum(int(d1.loc[(r.point, r.seed), "esc"]) == r.esc and int(d1.loc[(r.point, r.seed), "n_trig"]) == r.n_trig for r in dup.itertuples())
print(f"duplicated (point, seed) pairs already in P1b: {len(dup)}; identical outcomes and cascade sizes: {same}")
ex = ex[[k not in key1 for k in zip(ex.point, ex.seed)]]
merged = pd.concat([p1, ex], ignore_index=True); merged["tag"] = ""; p1["tag"] = ""
keep = lambda d: d[d.G < 0.2]
c0 = A.critical_eta(keep(p1), levels=(0.1,), B=500); c1 = A.critical_eta(keep(merged), levels=(0.1,), B=500)
m = c0.merge(c1, on=["G", "h_c"], suffixes=("_before", "_after")); m["d"] = m.eta10_after - m.eta10_before; m["filler"] = m.G.map(gname)
P = ex.groupby("point").esc.agg(["sum", "count"]); orig = p1[p1.point.isin(P.index)].groupby("point").esc.agg(["sum", "count"])
pts = orig.join(P, lsuffix="_40", rsuffix="_ext"); pts["P_40"] = pts.sum_40 / pts.count_40; pts["P_200"] = (pts.sum_40 + pts.sum_ext) / (pts.count_40 + pts.count_ext)
L = {"duplicates": int(len(dup)), "duplicates_identical": int(same), "points_extended": len(pts), "max_P200": float(pts.P_200.max()), "points_P200_ge_0.05": int((pts.P_200 >= 0.05).sum()),
     "d_eta10": [float(m.d[np.isfinite(m.d)].min()), float(m.d[np.isfinite(m.d)].abs().max())], "changed_settings": int((m.d.abs() > 1e-9).sum())}
json.dump(L, open(os.path.join(OUT, "ledger_R2_P7b.json"), "w"), indent=1, default=float)
print(L); print(pts.sort_values("P_200", ascending=False).head(8)[["sum_40", "count_40", "sum_ext", "count_ext", "P_40", "P_200"]].round(3).to_string())
print(m[m.d.abs() > 1e-9][["filler", "h_c", "eta10_before", "eta10_after", "d"]].round(4).to_string(index=False))
