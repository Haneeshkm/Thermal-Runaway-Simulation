"""Round-2 #14: independent-cascade null matched to the empirical first-ring distribution of K (5x5, centre initiator)."""
from review_common import *
import json
P1 = pd.read_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl"))
n_r, n_c = 5, 5; N = 25; ini = 12
nbr = [[] for _ in range(N)]
for r in range(n_r):
    for c in range(n_c):
        i = r * n_c + c
        if c + 1 < n_c: nbr[i] += [i + 1]; nbr[i + 1] += [i]
        if r + 1 < n_r: nbr[i] += [i + n_c]; nbr[i + n_c] += [i]
ring1 = nbr[ini]; ring = [abs(i // 5 - 2) + abs(i % 5 - 2) for i in range(N)]
def simulate(Kdist, q, n_sim, rng):
    sizes = np.empty(n_sim, int); esc = np.empty(n_sim, bool)
    Ks = rng.choice(np.arange(5), size=n_sim, p=Kdist)
    for s in range(n_sim):
        failed = {ini} | set(rng.choice(ring1, Ks[s], replace=False).tolist())
        front = [i for i in failed if i != ini]; tried = set()
        while front:
            new = []
            for i in front:
                for j in nbr[i]:
                    if j in failed or (i, j) in tried: continue
                    tried.add((i, j))
                    if ring[j] >= 2 and rng.random() < q: failed.add(j); new.append(j)
            front = new
        sizes[s] = len(failed); esc[s] = any(ring[i] >= 2 for i in failed)
    return sizes, esc
Pp = P1.groupby("point").esc.mean(); Nn = P1.groupby("point").size(); tp = Pp[(Pp >= 0.05) & (Pp <= 0.95) & (Nn >= 200)].index
rng = np.random.default_rng(3); rows = []
for pt in tp[:20]:
    d = P1[P1.point == pt]; Kd = np.bincount(d.n_r1_trig, minlength=5)[:5] / len(d); target = d.esc.mean()
    lo, hi = 0.0, 1.0
    for _ in range(12):                      # bisection on q so that simulated P(escape) matches the Monte Carlo
        q = 0.5 * (lo + hi); _, e = simulate(Kd, q, 1500, rng)
        if e.mean() < target: lo = q
        else: hi = q
    q = 0.5 * (lo + hi); s, e = simulate(Kd, q, 8000, rng)
    obs = d.n_trig.values
    rows.append({"point": pt, "P_esc": target, "q_fit": q, "obs_partial": np.mean((obs > 1) & (obs < N)), "ic_partial": np.mean((s > 1) & (s < N)),
                 "obs_full": np.mean(obs == N), "ic_full": np.mean(s == N), "obs_full_given_esc": np.mean(obs[d.esc.values == 1] == N),
                 "ic_full_given_esc": np.mean(s[e] == N) if e.any() else np.nan})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "R2_independent_cascade.csv"), index=False)
summ = {k: [float(t[k].mean()), float(t[k].min()), float(t[k].max())] for k in t.columns if k not in ("point",)}
json.dump(summ, open(os.path.join(OUT, "ledger_R2_ic.json"), "w"), indent=1)
for k, v in summ.items(): print(f"{k:20s} mean {v[0]:.3f} range {v[1]:.3f}-{v[2]:.3f}")
