"""Refit the quantities that used the coarse-grid boundary on the fine-grid (P7d) estimates: ROM vs MC, closed form
(seed-block bootstrap, LOO, LOFO; mean and quantile T_trig), weighted/censored rule fits, cooling requirements."""
from review_common import *
import json, statsmodels.api as sm
from scipy.stats import truncnorm, binom, norm
from scipy.optimize import minimize
L = {}
fine = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_fine.csv"))
A_s, fEz = 0.008, 0.825 * 83.9e3 / 4
# ---- ROM vs fine MC
rom = json.load(open(os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json"))); etas = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)])
a_, b_ = (180 - 210) / 12, (245 - 210) / 12; F = lambda T: truncnorm.cdf(T, a_, b_, loc=210, scale=12)
fej = np.linspace(0.75, 0.90, 16); ef = np.linspace(0.4, 1.6, 2401)
def cross(G, h, Lv):
    Tp = np.array([rom[f"{G}_{int(h)}_{e}"] for e in etas]); T = np.interp(np.outer(ef, fej / 0.825), etas, Tp)
    p = (1 - binom.cdf(1, 4, F(T))).mean(axis=1); return ef[np.argmax(p >= Lv)] if p.max() >= Lv else np.inf
rows = []
for _, r in fine.iterrows():
    rows.append({"filler": gname(r.G), "h_c": r.h_c, "MC_eta10": r.eta10, "ROM_eta10": cross(r.G, r.h_c, 0.1), "MC_eta50": r.eta50, "ROM_eta50": cross(r.G, r.h_c, 0.5)})
t = pd.DataFrame(rows); t.to_csv(os.path.join(ROOT, "analysis", "T_rom_vs_mc_fine.csv"), index=False)
for Lv in ("10", "50"):
    f = t[np.isfinite(t[f"MC_eta{Lv}"]) & np.isfinite(t[f"ROM_eta{Lv}"])]; d = f[f"ROM_eta{Lv}"] - f[f"MC_eta{Lv}"]
    L[f"rom{Lv}"] = {"n": len(f), "MAE": float(d.abs().mean()), "max": float(d.abs().max()), "bias": float(d.mean()), "corr": float(np.corrcoef(f[f"MC_eta{Lv}"], f[f"ROM_eta{Lv}"])[0, 1])}
# ---- closed form on fine estimates with seed-block bootstrap
p = A.tidy(os.path.join(RES, "P7d_fine.jsonl.gz")); E = p.pivot_table(index=["G", "h_c", "eta"], columns="seed", values="esc"); ns = E.shape[1]
def crit_from(cols, level):
    out = {}
    for (G, h), sub in E.groupby(level=[0, 1]):
        e_ = sub.index.get_level_values(2).values; M = sub.values[:, cols]
        k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
        xs, fit = A.pava(e_, k / np.maximum(n, 1), np.maximum(n, 1)); out[(G, h)] = A.crossing(xs, fit, level)
    return out
def Tq(level):
    from scipy.optimize import brentq
    return brentq(lambda T: 1 - binom.cdf(1, 4, F(T)) - level, 180.01, 244.99)
def cfit(cr, dT):
    pts = [(G, h, v) for (G, h), v in cr.items() if np.isfinite(v)]
    G, h, v = map(np.array, zip(*pts)); Y = v * fEz / dT; X = np.column_stack([np.ones_like(h), h * A_s, 3 * G])
    beta = np.linalg.lstsq(X, Y, rcond=None)[0]; pred = X @ beta * dT / fEz
    r2 = 1 - ((Y - X @ beta) ** 2).sum() / ((Y - Y.mean()) ** 2).sum()
    return beta, r2, G, h, v, X, Y
rng = np.random.default_rng(0)
for lev, tag in ((0.1, "10"), (0.5, "50")):
    cr0 = crit_from(np.arange(ns), lev); bcr = [crit_from(rng.integers(0, ns, ns), lev) for _ in range(1000)]
    for mode, dT in (("mean", 185.0), ("quantile", Tq(lev) - 25.0)):
        beta, r2, G, h, v, X, Y = cfit(cr0, dT); bb = np.array([cfit(c, dT)[0] for c in bcr])
        loo = []
        for i in range(len(Y)):
            bi = np.linalg.lstsq(np.delete(X, i, 0), np.delete(Y, i), rcond=None)[0]; loo.append(abs(X[i] @ bi * dT / fEz - v[i]))
        lofo = []
        for g in np.unique(G):
            msk = np.isclose(G, g); bi = np.linalg.lstsq(X[~msk], Y[~msk], rcond=None)[0]; lofo += list(np.abs(X[msk] @ bi * dT / fEz - v[msk]))
        L[f"closed{tag}_{mode}"] = {"dT": dT, "n": len(Y), "C_eff": beta[0], "tau_h": beta[1], "tau_G": beta[2], "R2": r2,
                                    "ci_lo": list(np.percentile(bb, 2.5, axis=0)), "ci_hi": list(np.percentile(bb, 97.5, axis=0)),
                                    "MAE_fit": float(np.mean(np.abs(X @ beta * dT / fEz - v))), "MAE_LOO": float(np.mean(loo)), "max_LOO": float(np.max(loo)),
                                    "MAE_LOFO": float(np.mean(lofo)), "max_LOFO": float(np.max(lofo))}
    L[f"Tq{tag}"] = Tq(lev)
# ---- weighted and censored rule fits on fine estimates
for G in (0.013, 0.041, 0.102):
    d = fine[np.isclose(fine.G, G) & np.isfinite(fine.eta10)].sort_values("h_c"); g = gname(G)
    w = 1 / (((d.eta10_hi - d.eta10_lo) / (2 * 1.96)) ** 2); mw = sm.WLS(d.eta10.values, sm.add_constant(d.h_c.values), weights=w.values).fit()
    b, a = np.polyfit(d.h_c, d.eta10, 1)
    coarse = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv")); cz = coarse[np.isclose(coarse.G, G) & (coarse.h_c <= 100) & ~coarse.h_c.isin(d.h_c)]
    xc = cz[(~np.isfinite(cz.eta10)) | (cz.eta10 >= 1.45)].h_c.values
    def nll(pp):
        aa, bb_, ls = pp; s = np.exp(ls)
        return -(norm.logpdf(d.eta10.values, aa + bb_ * d.h_c.values, s).sum() + norm.logsf(1.45, aa + bb_ * xc, s).sum())
    rr = minimize(nll, [a, b, np.log(0.01)], method="Nelder-Mead", options={"xatol": 1e-9, "fatol": 1e-12, "maxiter": 8000})
    L[f"fits_{g}"] = {"OLS": [a, b], "WLS": list(mw.params), "censored": list(rr.x[:2]), "n": len(d), "n_censored": len(xc)}
    L[f"cooling_eta1_{g}"] = {"h_c": (1 - a) / b, "UA": (1 - a) / b * A_s, "kappa_UA": b / A_s}
json.dump(L, open(os.path.join(OUT, "ledger_R3_fine.json"), "w"), indent=1, default=float)
print(json.dumps({k: v for k, v in L.items() if not k.startswith("closed")}, indent=0, default=lambda x: round(float(x), 4))[:2500])
for k in [k for k in L if k.startswith("closed")]:
    v = L[k]; print(k, "C %.1f [%.1f,%.1f] tau_h %.0f [%.0f,%.0f] tau_G %.0f [%.0f,%.0f] R2 %.4f LOO %.3f(%.3f) LOFO %.3f(%.3f)" % (v["C_eff"], v["ci_lo"][0], v["ci_hi"][0], v["tau_h"], v["ci_lo"][1], v["ci_hi"][1], v["tau_G"], v["ci_lo"][2], v["ci_hi"][2], v["R2"], v["MAE_LOO"], v["max_LOO"], v["MAE_LOFO"], v["max_LOFO"]))
