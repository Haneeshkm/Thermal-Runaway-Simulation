"""Review analyses part B: #14 attribution with seed-clustered SEs and stated scalings; #16 closed form with an
effective trigger quantile, leave-one-out and leave-one-filler-out; #17 P5 slope ratios with seed-block bootstrap
under one consistent rule; #20 machine-readable P_esc map."""
from review_common import *
import json, statsmodels.api as sm
from scipy.stats import truncnorm, binom
from scipy.optimize import brentq
L = {}
P1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
# ---------------- #14
Pp = P1.groupby("point").esc.mean(); N = P1.groupby("point").size()
tp = Pp[(Pp >= 0.05) & (Pp <= 0.95) & (N >= 200)].index; tr = P1[P1.point.isin(tp)].copy()
sd = A.PRIOR_SD; L["attr_scalings"] = {k: sd[k] for k in ("Ttrig_r1_min_z".replace("_z", ""), "fej_ini", "fej_r1_mean")}
for k in ("Ttrig_r1_min", "fej_ini", "fej_r1_mean"): tr[k + "_z"] = (tr[k] - tr[k].mean()) / sd[k]
L["attr_empirical_sd"] = {k: float(tr[k].std()) for k in ("Ttrig_r1_min", "fej_ini", "fej_r1_mean")}
X = pd.get_dummies(tr.point, drop_first=True, dtype=float); X[["Ttrig_r1_min_z", "fej_ini_z", "fej_r1_mean_z"]] = tr[["Ttrig_r1_min_z", "fej_ini_z", "fej_r1_mean_z"]]
X = sm.add_constant(X); y = tr.esc.values
m0 = sm.Logit(y, X).fit(disp=False, method="bfgs", maxiter=2000)
mc = sm.Logit(y, X).fit(disp=False, method="bfgs", maxiter=2000, cov_type="cluster", cov_kwds={"groups": tr.seed.values})
for k in ("Ttrig_r1_min_z", "fej_ini_z", "fej_r1_mean_z"):
    b = mc.params[k]; L[f"attr_{k}"] = {"OR": np.exp(b), "CI_naive": list(np.exp(b + np.array([-1.96, 1.96]) * m0.bse[k])),
                                        "CI_cluster": list(np.exp(b + np.array([-1.96, 1.96]) * mc.bse[k])), "p_cluster": mc.pvalues[k]}
L["attr_points"] = len(tp); L["attr_runs"] = len(tr)
# ---------------- #16 closed form with an effective trigger quantile
a_, b_ = (180 - 210) / 12, (245 - 210) / 12; F = lambda T: truncnorm.cdf(T, a_, b_, loc=210, scale=12)
def Tq(level):   # trigger temperature at which P(at least 2 of 4 neighbours have T_trig below it) = level
    return brentq(lambda T: 1 - binom.cdf(1, 4, F(T)) - level, 180.01, 244.99)
crit = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv"))
A_s, fEz = 0.008, 0.825 * 83.9e3 / 4
for lev, tag in ((0.1, "10"), (0.5, "50")):
    d = crit[np.isfinite(crit[f"eta{tag}"]) & (crit.G < 0.2) & (crit[f"eta{tag}"] < 1.45)].reset_index(drop=True)
    for mode, dT in (("mean", 185.0), ("quantile", Tq(lev) - 25.0)):
        Y = d[f"eta{tag}"] * fEz / dT; Xc = pd.DataFrame({"hA": d.h_c * A_s, "G3": 3 * d.G}); res = sm.OLS(Y, sm.add_constant(Xc)).fit()
        pred = lambda r, mm: (mm.params["const"] + mm.params["hA"] * r.h_c * A_s + mm.params["G3"] * 3 * r.G) * dT / fEz
        loo = [abs(pred(d.iloc[i], sm.OLS(Y.drop(i), sm.add_constant(Xc.drop(i))).fit()) - d[f"eta{tag}"].iloc[i]) for i in range(len(d))]
        lofo = []
        for G in d.G.unique():
            msk = np.isclose(d.G, G); mm = sm.OLS(Y[~msk], sm.add_constant(Xc[~msk])).fit()
            lofo += [abs(pred(r, mm) - r[f"eta{tag}"]) for _, r in d[msk].iterrows()]
        L[f"closed{tag}_{mode}"] = {"dT": dT, "C_eff": res.params["const"], "C_eff_se": res.bse["const"], "tau_h": res.params["hA"], "tau_h_se": res.bse["hA"],
                                    "tau_G": res.params["G3"], "tau_G_se": res.bse["G3"], "R2": res.rsquared, "n": len(d),
                                    "MAE_fit": float(np.mean(np.abs(res.fittedvalues * dT / fEz - d[f"eta{tag}"]))),
                                    "MAE_LOO": float(np.mean(loo)), "max_LOO": float(np.max(loo)), "MAE_LOFO": float(np.mean(lofo)), "max_LOFO": float(np.max(lofo))}
    L[f"Tq{tag}"] = Tq(lev)
# ---------------- #17 P5 slope ratios: one rule (edge excluded, >=3 points), seed-block bootstrap
P5 = A.tidy(os.path.join(RES, "P5_robustness.jsonl.gz"))
E5 = P5.pivot_table(index=["tag", "G", "h_c", "eta"], columns="seed", values="esc"); ns = E5.shape[1]
def slopes(cols):
    out = {}
    for (tag, G), sub in E5.groupby(level=[0, 1]):
        pts = []
        for h, s2 in sub.groupby(level=2):
            etas = s2.index.get_level_values(3).values; M = s2.values[:, cols]
            k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
            xs, fit = A.pava(etas, k / np.maximum(n, 1), np.maximum(n, 1)); v = A.crossing(xs, fit, 0.1)
            if np.isfinite(v) and v < 1.45: pts.append((h, v))
        if len(pts) >= 3:
            hh, vv = np.array(pts).T; out[(tag, G)] = (np.polyfit(hh, vv, 1)[0], len(pts))
    return out
est = slopes(np.arange(ns)); rng = np.random.default_rng(0); boots = []
for _ in range(1000): boots.append(slopes(rng.integers(0, ns, ns)))
pred = {"k_r=0.40": 2.15, "k_r=1.50": 0.69, "tau_ej=20": 1.11, "lumped": 0.11, "Ttrig=N(190,12)": 0.892, "beta=0.3": None}
rows = []
for (tag, G), (s, n) in est.items():
    if tag == "baseline": continue
    b0 = est.get(("baseline", G))
    if b0 is None: continue
    rb = [bt[(tag, G)][0] / bt[("baseline", G)][0] for bt in boots if (tag, G) in bt and ("baseline", G) in bt]
    rows.append({"variant": tag, "filler": gname(G), "points": n, "slope": s, "baseline_slope": b0[0], "ratio": s / b0[0],
                 "ratio_lo": np.percentile(rb, 2.5), "ratio_hi": np.percentile(rb, 97.5), "B_valid": len(rb), "predicted": pred.get(tag)})
r5 = pd.DataFrame(rows); r5["err"] = r5.ratio / r5.predicted.astype(float) - 1
r5["pred_in_CI"] = (r5.predicted.astype(float) >= r5.ratio_lo) & (r5.predicted.astype(float) <= r5.ratio_hi)
r5.to_csv(os.path.join(OUT, "P5_slope_ratios_bootstrap.csv"), index=False)
L["P5_baseline_slopes"] = {gname(G): est[("baseline", G)][0] for G in (0.013, 0.102) if ("baseline", G) in est}
L["P5_baseline_points"] = {gname(G): est[("baseline", G)][1] for G in (0.013, 0.102) if ("baseline", G) in est}
# ---------------- #20 P_esc map with Wilson intervals
df = C.summarise(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
df["filler"] = df.G_lo.map(gname); df.rename(columns={"G_lo": "G_W_per_K", "eta_lo": "eta"}, inplace=True)
df[["filler", "G_W_per_K", "eta", "h_c", "N", "k_esc", "P_esc", "P_esc_lo", "P_esc_hi", "k_full", "P_full"]].to_csv(
    os.path.join(ROOT, "analysis", "T_Pesc_map_v21.csv"), index=False)
json.dump(L, open(os.path.join(OUT, "ledger_B.json"), "w"), indent=1, default=float)
print(json.dumps(L, indent=1, default=lambda x: round(float(x), 4)))
pd.set_option("display.width", 220); print(r5.round(3).to_string(index=False))
