"""Review analyses on existing data (part A): #8 escape times, #9 one-sided bounds, #10 bootstrap CIs of the
design rule, #11 pooled vs separate slopes and the 50% rule, #12 first-ring statistics with intervals."""
from review_common import *
import json
from scipy.stats import beta as Beta, f as Fdist
from statsmodels.stats.proportion import proportion_confint
L = {}
P1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
recs = C.load(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))

# ---- #9 one-sided bounds for 0/40 and 40/40 (Clopper-Pearson, exact) and Wilson
for n in (40, 200):
    L[f"cp_upper95_0of{n}"] = Beta.ppf(0.95, 1, n)                    # one-sided 95% exact upper bound for 0/n
    L[f"wilson_upper95_0of{n}"] = proportion_confint(0, n, alpha=0.10, method="wilson")[1]   # one-sided 95%
df = C.summarise(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
L["grid_points_zero"] = int((df.k_esc == 0).sum()); L["grid_points_all"] = int((df.k_esc == df.N).sum())
L["grid_points_between"] = int(((df.k_esc > 0) & (df.k_esc < df.N)).sum())
L["zero_points_N40"] = int(((df.k_esc == 0) & (df.N == 40)).sum())

# ---- #8 escape times (time of first ring>=2 failure) in escaping runs
t_esc = []
for d in recs:
    if not d["esc"]: continue
    te = min(t for t, r in zip(d["cells"]["t_trig"], d["cells"]["ring"]) if t is not None and r >= 2)
    t_esc.append((d["point"], te))
te = pd.DataFrame(t_esc, columns=["point", "t_esc"])
L["t_esc_max"] = te.t_esc.max(); L["t_esc_p99"] = te.t_esc.quantile(0.99); L["t_esc_median"] = te.t_esc.median()
P = P1.groupby("point").esc.mean(); near = P[(P > 0) & (P <= 0.5)].index          # slow, near-boundary points
tn = te[te.point.isin(near)]
L["t_esc_near_n"] = len(tn); L["t_esc_near_max"] = tn.t_esc.max(); L["t_esc_near_p95"] = tn.t_esc.quantile(0.95)
L["t_esc_near_max_point"] = tn.loc[tn.t_esc.idxmax(), "point"]
L["runs_reaching_horizon"] = sum(1 for d in recs if d["t_end"] >= 1799)
pd.DataFrame({"point": te.point, "t_esc_s": te.t_esc}).to_csv(os.path.join(OUT, "P1b_escape_times.csv"), index=False)

# ---- #10 seed-block bootstrap of the design-rule fit (eta*10 on insulating fillers, unweighted OLS, edge excluded)
seeds = np.sort(P1.seed.unique()); E = P1.pivot_table(index=["G", "h_c", "eta"], columns="seed", values="esc")
def crit_from(cols, level):
    out = {}
    for (G, h), sub in E.groupby(level=[0, 1]):
        if G > 0.2: continue
        etas = sub.index.get_level_values(2).values; M = sub.values[:, cols]
        k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
        xs, fit = A.pava(etas, k / np.maximum(n, 1), np.maximum(n, 1)); out[(G, h)] = A.crossing(xs, fit, level)
    return out
def fit_rule(cr):
    res = {}
    for G in (0.013, 0.041, 0.102):
        pts = sorted((h, v) for (g, h), v in cr.items() if np.isclose(g, G) and np.isfinite(v) and v < 1.45)
        if len(pts) >= 3:
            h, v = np.array(pts).T; b, a = np.polyfit(h, v, 1); res[G] = (a, b, len(pts))
    return res
rng = np.random.default_rng(0); ns = E.shape[1]
for level, tag in ((0.1, "10"), (0.5, "50")):
    est = fit_rule(crit_from(np.arange(ns), level)); boots = {G: [] for G in est}
    for _ in range(1000):
        fb = fit_rule(crit_from(rng.integers(0, ns, ns), level))
        for G in est:
            if G in fb: boots[G].append(fb[G][:2])
    for G, (a, b, n) in est.items():
        bb = np.array(boots[G]); g = gname(G)
        L[f"rule{tag}_{g}"] = {"eta0": a, "kappa": b, "n": n, "eta0_ci": list(np.percentile(bb[:, 0], [2.5, 97.5])),
                              "kappa_ci": list(np.percentile(bb[:, 1], [2.5, 97.5])), "B_used": len(bb)}

# ---- #11 pooled (common slope, filler intercepts) vs separate slopes, on eta*10 point estimates
crit = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv"))
for level in ("10", "50"):
    d = crit[np.isfinite(crit[f"eta{level}"]) & (crit[f"eta{level}"] < 1.45) & (crit.G < 0.2)].copy()
    y = d[f"eta{level}"].values; h = d.h_c.values; gi = pd.Categorical(d.G).codes; k = gi.max() + 1
    Xs = np.column_stack([np.eye(k)[gi], np.eye(k)[gi] * h[:, None]]); Xp = np.column_stack([np.eye(k)[gi], h])
    rs = ((y - Xs @ np.linalg.lstsq(Xs, y, rcond=None)[0]) ** 2).sum(); rp = ((y - Xp @ np.linalg.lstsq(Xp, y, rcond=None)[0]) ** 2).sum()
    n = len(y); ps, pp = Xs.shape[1], Xp.shape[1]
    F = ((rp - rs) / (ps - pp)) / (rs / (n - ps)); pval = 1 - Fdist.cdf(F, ps - pp, n - ps)
    aic = lambda rss, p: n * np.log(rss / n) + 2 * p
    common = np.linalg.lstsq(Xp, y, rcond=None)[0][-1]
    L[f"pooled{level}"] = {"n": n, "F": F, "df": [ps - pp, n - ps], "p": pval, "AIC_separate": aic(rs, ps), "AIC_pooled": aic(rp, pp), "common_kappa": common}

# ---- #12 first-ring statistics at transition points, by filler, with exact intervals
Pp = P1.groupby("point").esc.mean(); N = P1.groupby("point").size()
tp = Pp[(Pp >= 0.05) & (Pp <= 0.95)].index
rows = []
for scope, sub in [("all runs", P1), ("transition points", P1[P1.point.isin(tp)])] + \
                  [(f"transition, {gname(G)}", P1[P1.point.isin(tp) & np.isclose(P1.G, G)]) for G in (0.013, 0.041, 0.102)]:
    for K in range(5):
        s = sub[sub.n_r1_trig == K]; n = len(s); k = int(s.esc.sum())
        lo, hi = proportion_confint(k, n, alpha=0.05, method="beta") if n else (np.nan, np.nan)
        rows.append({"scope": scope, "K": K, "n": n, "escapes": k, "P": k / n if n else np.nan, "ci_lo": lo, "ci_hi": hi})
fr = pd.DataFrame(rows); fr.to_csv(os.path.join(OUT, "P1b_first_ring_CI.csv"), index=False)
L["transition_points"] = len(tp); L["transition_runs"] = int(P1.point.isin(tp).sum())
json.dump(L, open(os.path.join(OUT, "ledger_A.json"), "w"), indent=1, default=float)
print(json.dumps(L, indent=1, default=lambda x: round(float(x), 4)))
pd.set_option("display.width", 200); print(fr.round(3).to_string(index=False))
