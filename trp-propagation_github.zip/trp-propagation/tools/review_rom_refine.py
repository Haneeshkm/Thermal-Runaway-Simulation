"""#15: reduced-order model on a 0.01 eta grid near the crossings at two settings, vs the 0.05 grid."""
from review_common import *
import json, time, trp_v2 as V
from scipy.stats import truncnorm, binom
rom = json.load(open(os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json")))
a_, b_ = (180 - 210) / 12, (245 - 210) / 12; F = lambda T: truncnorm.cdf(T, a_, b_, loc=210, scale=12)
fej = np.linspace(0.75, 0.90, 16); ef = np.linspace(0.4, 1.6, 2401)
def cross(etas, Tp, L):
    T = np.interp(np.outer(ef, fej / 0.825), etas, Tp); p = (1 - binom.cdf(1, 4, F(T))).mean(axis=1)
    return ef[np.argmax(p >= L)] if p.max() >= L else np.inf
out = {}; t0 = time.time()
for G, h in ((0.013, 10), (0.102, 35)):
    e5 = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)]); T5 = np.array([rom[f"{G}_{h}_{e}"] for e in e5])
    c5 = {L: cross(e5, T5, L) for L in (0.1, 0.5)}
    lo, hi = min(c5.values()) - 0.12, max(c5.values()) + 0.06
    fine = np.round(np.arange(lo, hi + 1e-9, 0.01), 3); Tf = []
    for e in fine:
        r = V.run(V.baseline_v2(calib="v2.1", freeze_others=True, eta_lo=e, eta_hi=e, G_lo=G, G_hi=G, h_c=float(h), fej_lo=0.825,
                                fej_hi=0.825, sd_mass=0, sd_Cp=0, sd_H=0, t_max=600.0), 0)
        c = r["cells"]; Tf.append(np.mean([c["Tmax_c"][i] for i, x in enumerate(c["ring"]) if x == 1]))
    em = np.concatenate([e5[e5 < lo], fine, e5[e5 > hi]]); Tm = np.concatenate([T5[e5 < lo], Tf, T5[e5 > hi]])
    cf = {L: cross(em, Tm, L) for L in (0.1, 0.5)}
    out[f"{gname(G)}_h{h}"] = {"grid005": c5, "grid001": cf, "fine_eta": fine.tolist(), "fine_Tpk": [float(x) for x in Tf]}
    print(gname(G), h, {L: (round(c5[L], 3), round(cf[L], 3), round(cf[L] - c5[L], 3)) for L in c5}, f"{time.time()-t0:.0f}s")
json.dump(out, open(os.path.join(OUT, "rom_refine.json"), "w"), indent=1, default=float)
