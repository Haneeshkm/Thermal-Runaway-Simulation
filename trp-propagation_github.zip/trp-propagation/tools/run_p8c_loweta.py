import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import campaign as C
P = []
for tag, conc, sets in (("dir1", 1.0, [("air_2mm",2),("air_2mm",10),("air_2mm",35),("silicone_2mm",2),("silicone_2mm",10)]), ("dir4", 4.0, [("air_2mm",2)])):
    for g, h in sets:
        for e in ((0.2, 0.3, 0.4) if tag == "dir1" else (0.3, 0.4)):
            P.append(C.point(f"V={tag}|G={g}|eta={e}|h={h}", eta_lo=e, eta_hi=e, G_lo=C.G_CASES[g], G_hi=C.G_CASES[g], h_c=float(h), vent_split="dirichlet", split_conc=conc))
C.run(P, seeds=range(40), out=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results_v2', 'P8c_loweta.jsonl.gz'), workers=1, base='v2.1', verbose=False)
