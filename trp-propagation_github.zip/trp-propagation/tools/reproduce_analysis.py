"""Regenerate every analysis table used in the manuscript from the raw campaign results.

Inputs  (results_v2/):  P1b_phase_v21, P2_epistemic, P3_size_position, P4b_numerics_v21,
                        P4c_numerics_mid_v21, P5_robustness  (.jsonl.gz)
         (analysis/):   rom_Tpeak_v21.json  (from tools/build_rom_grid.py)
Outputs (analysis/):    T_*.csv tables, and cache/*.pkl tidy tables used by the figure scripts.

    python tools/reproduce_analysis.py            # all tables (about 10-20 min, bootstrap dominates)
    python tools/reproduce_analysis.py --quick    # B = 200 bootstrap replicates (for a fast check)

Bootstrap seeds are fixed, so the full run reproduces the published tables exactly.
"""
import json, os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import numpy as np, pandas as pd
from scipy.stats import binomtest, truncnorm, binom
import campaign as C, analysis_v2 as A

QUICK = "--quick" in sys.argv
RES, OUT = os.path.join(ROOT, "results_v2"), os.path.join(ROOT, "analysis")
CACHE = os.path.join(OUT, "cache"); os.makedirs(CACHE, exist_ok=True)
f = lambda name: os.path.join(RES, name + ".jsonl.gz")
o = lambda name: os.path.join(OUT, name)
B_MAIN, B_SEC = (200, 200) if QUICK else (2000, 1000)
INV = {v: k for k, v in C.G_CASES.items()}
def gname(G): return INV[min(INV, key=lambda x: abs(x - G))]
def have(name): return os.path.exists(f(name))

# ---------------------------------------------------------------- P1b: containment maps (v2.1)
if have("P1b_phase_v21"):
    print("P1b ...", flush=True)
    P1 = A.tidy(f("P1b_phase_v21")); P1.to_pickle(os.path.join(CACHE, "P1b_tidy.pkl"))
    crit = A.critical_eta(P1, levels=(0.1, 0.5), B=B_MAIN); crit.to_csv(o("T_critical_eta_v21.csv"), index=False)
    rows = []                                                    # design rule (Sect. 4.2)
    for G, g in crit.groupby("G"):
        g = g[np.isfinite(g.eta10) & (g.eta10 < 1.45)]
        if len(g) < 3: continue
        b, a = np.polyfit(g.h_c, g.eta10, 1); yh = a + b * g.h_c
        r2 = 1 - ((g.eta10 - yh) ** 2).sum() / ((g.eta10 - g.eta10.mean()) ** 2).sum()
        rows.append({"filler": gname(G), "G_W_per_K": G, "eta0": a, "slope": b, "R2": r2,
                     "max_resid": np.abs(g.eta10 - yh).max(), "points": len(g)})
    pd.DataFrame(rows).to_csv(o("T_design_rule_fit_v21.csv"), index=False)
    Pp = P1.groupby("point").esc.mean(); N = P1.groupby("point").size()
    tp = Pp[(Pp >= 0.05) & (Pp <= 0.95) & (N >= 200)].index      # refined transition points
    res, tr = A.attribution(P1[P1.point.isin(tp)]); res.to_csv(o("T_attribution_v21.csv"))
    pd.DataFrame([{"point": p, **A.percolation_check(P1[P1.point == p])} for p in tp[:20]]
                 ).to_csv(o("T_percolation_v21.csv"), index=False)
    ring = pd.DataFrame([{"first_ring_ignited": k, "runs": int((P1.n_r1_trig == k).sum()),
                          "P_escape": P1[P1.n_r1_trig == k].esc.mean()} for k in range(5)])
    ring.to_csv(o("T_first_ring_v21.csv"), index=False)
    # reduced-order model against Monte Carlo (Sect. 4.5)
    rp = os.path.join(OUT, "rom_Tpeak_v21.json")
    if os.path.exists(rp):
        rom = json.load(open(rp)); etas = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)])
        a_, b_ = (180 - 210) / 12, (245 - 210) / 12
        Fg = lambda T: truncnorm.cdf(T, a_, b_, loc=210, scale=12)
        fej = np.linspace(0.75, 0.90, 16); ef = np.linspace(0.4, 1.6, 2401)
        def cross(G, h, L):
            Tp = np.array([rom[f"{G}_{h}_{e}"] for e in etas]); T = np.interp(np.outer(ef, fej / 0.825), etas, Tp)
            p = (1 - binom.cdf(1, 4, Fg(T))).mean(axis=1); return ef[np.argmax(p >= L)] if p.max() >= L else np.inf
        rows = []
        for G, nm in ((0.013, "air"), (0.041, "foam"), (0.102, "silicone")):
            for h in (2, 5, 10, 20, 35, 50, 75, 100):
                c = crit[np.isclose(crit.G, G) & np.isclose(crit.h_c, h)].iloc[0]
                rows.append({"filler": nm, "h_c": h, "MC_eta10": c.eta10, "ROM_eta10": cross(G, h, 0.1),
                             "MC_eta50": c.eta50, "ROM_eta50": cross(G, h, 0.5)})
        pd.DataFrame(rows).to_csv(o("T_rom_vs_mc_v21.csv"), index=False)

# ---------------------------------------------------------------- P2: modelling assumptions (v2.0 reference)
if have("P2_epistemic"):
    print("P2 ...", flush=True)
    P2 = A.tidy(f("P2_epistemic")); P2["cell"] = P2.point.str.split("|", n=1).str[1]
    b = P2[P2.tag == "baseline"].set_index(["cell", "seed"]).esc; rows = []
    for tag, g in P2[P2.tag != "baseline"].groupby("tag"):
        x = g.set_index(["cell", "seed"]).esc; bb = b.reindex(x.index)
        dP = x.groupby(level=0).mean() - bb.groupby(level=0).mean(); sig = 0
        for c in dP.index:
            xa, ba = x.xs(c), bb.xs(c); n = int((xa != ba).sum())
            if n and binomtest(int(((xa == 1) & (ba == 0)).sum()), n, 0.5).pvalue < 0.05: sig += 1
        rows.append({"assumption": tag, "mean_dP": dP.mean(), "max_abs_dP": dP.abs().max(),
                     "more_escape": int(((x == 1) & (bb == 0)).sum()), "less_escape": int(((x == 0) & (bb == 1)).sum()),
                     "cells_sig(p<.05)": sig, "cells": len(dP)})
    pd.DataFrame(rows).sort_values("max_abs_dP", ascending=False).to_csv(o("T_epistemic_paired.csv"), index=False)

# ---------------------------------------------------------------- P3: size and position (v2.0 reference)
if have("P3_size_position"):
    print("P3 ...", flush=True)
    P3 = A.tidy(f("P3_size_position")); P3.to_pickle(os.path.join(CACHE, "P3_tidy.pkl"))
    A.critical_eta(P3, levels=(0.1,), B=500).to_csv(o("T_size_position.csv"), index=False)
    P3.groupby(["eta", "h_c", "tag"]).esc.mean().unstack("tag").to_csv(o("T_size_position_Pesc.csv"))

# ---------------------------------------------------------------- P5: pre-registered predictions (v2.0 reference)
if have("P5_robustness"):
    print("P5 ...", flush=True)
    P5 = A.tidy(f("P5_robustness"))
    ce = A.critical_eta(P5, levels=(0.1, 0.5), B=B_SEC); ce.to_csv(o("T_P5_critical_eta.csv"), index=False)
    pred = {"baseline": 1.00, "k_r=0.40": 2.15, "k_r=1.50": 0.69, "tau_ej=20": 1.11, "lumped": 0.11,
            "Ttrig=N(190,12)": 0.892, "beta=0.3": np.nan}            # recorded before P5 was run
    rows = []
    for L in ("10", "50"):
        for (tag, G), g in ce.groupby(["tag", "G"]):
            d = g[np.isfinite(g[f"eta{L}"])].sort_values("h_c")
            if len(d) < 2: rows.append({"L": int(L), "factor": tag, "G": G, "n": len(d)}); continue
            b_, a_ = np.polyfit(d.h_c, d[f"eta{L}"], 1)
            rows.append({"L": int(L), "factor": tag, "G": G, "n": len(d), "eta0": a_, "slope": b_})
    t = pd.DataFrame(rows); base = t[t.factor == "baseline"].set_index(["L", "G"]).slope
    t["ratio_meas"] = t.apply(lambda r: r.slope / base.get((r.L, r.G), np.nan) if pd.notna(r.get("slope")) else np.nan, axis=1)
    t["ratio_pred"] = t.factor.map(pred); t.to_csv(o("T_P5_rule_vs_pred.csv"), index=False)
    s = t[(t.L == 10) & (t.factor != "baseline") & t.ratio_pred.notna()].copy()
    s["filler"] = np.where(s.G < 0.05, "air", "silicone"); s["err_pre"] = s.ratio_meas / s.ratio_pred - 1
    s.to_csv(o("T_P5_prediction_scorecard.csv"), index=False)

# ---------------------------------------------------------------- numerics (v2.1)
if have("P4b_numerics_v21"):
    print("numerics ...", flush=True)
    recs = C.load(f("P4b_numerics_v21")); D = {}
    for d in recs: D.setdefault(d["point"], {})[d["seed"]] = d
    rows = []
    for p in ["N=dt0.05", "N=substep_half", "N=horizon_x2", "N=no_radiation"]:
        pr = C.paired(recs, "N=base", p)
        dt = [abs(D[p][s]["t_first_nbr"] - D["N=base"][s]["t_first_nbr"]) for s in D[p]
              if D[p][s]["t_first_nbr"] and D["N=base"][s]["t_first_nbr"]]
        rows.append({"point": "air, eta 0.9, h_c 10", "variant": p[2:], **pr, "dt_max_s": max(dt), "dt_p95_s": np.percentile(dt, 95)})
    if have("P4c_numerics_mid_v21") and have("P1b_phase_v21"):
        base = {d["seed"]: d for d in C.load(f("P1b_phase_v21")) if d["point"] == "G=foam_2mm|eta=0.8|h=5" and d["seed"] < 100}
        V = {}
        for d in C.load(f("P4c_numerics_mid_v21")): V.setdefault(d["point"], {})[d["seed"]] = d
        for p, dd in V.items():
            s = sorted(set(dd) & set(base))
            lost = sum(base[k]["esc"] and not dd[k]["esc"] for k in s); gain = sum(dd[k]["esc"] and not base[k]["esc"] for k in s)
            dt = [abs(dd[k]["t_first_nbr"] - base[k]["t_first_nbr"]) for k in s if dd[k]["t_first_nbr"] and base[k]["t_first_nbr"]]
            rows.append({"point": "foam, eta 0.8, h_c 5", "variant": p[2:], "N": len(s), "A_only": lost, "B_only": gain,
                         "P_A": np.mean([base[k]["esc"] for k in s]), "P_B": np.mean([dd[k]["esc"] for k in s]),
                         "mcnemar_p": binomtest(gain, gain + lost, 0.5).pvalue if gain + lost else 1.0,
                         "dt_max_s": max(dt), "dt_p95_s": np.percentile(dt, 95)})
    pd.DataFrame(rows).to_csv(o("T_numerics_v21.csv"), index=False)

print("done; tables in", OUT)
