"""Prepare inputs for revised Figs. 5, 6, 8 and new Fig. 10."""
from review_common import *
import json
os.makedirs(os.path.join(ROOT, "analysis", "cache"), exist_ok=True)
P1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); P1.to_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl"))
LB = json.load(open(os.path.join(OUT, "ledger_B.json")))
rows = []
for k, nm in (("Ttrig_r1_min_z", "Ttrig_r1_min_z"), ("fej_ini_z", "fej_ini_z"), ("fej_r1_mean_z", "fej_r1_mean_z")):
    a = LB[f"attr_{k}"]; rows.append({"feature": nm, "OR": a["OR"], "CI_lo": a["CI_cluster"][0], "CI_hi": a["CI_cluster"][1], "p": a["p_cluster"]})
pd.DataFrame(rows).set_index("feature").to_csv(os.path.join(ROOT, "analysis", "T_attribution_v21_cluster.csv"))
# P6e lumped controls: slope ratios vs the P5 baseline, same rule and seed-block bootstrap as review_existing_b
P5 = A.tidy(os.path.join(RES, "P5_robustness.jsonl.gz")); P5 = P5[P5.tag == "baseline"]
P6 = A.tidy(os.path.join(RES, "P6e_lumped.jsonl.gz")); P6["tag"] = P6.point.str.split("|").str[0].str[2:]
allp = pd.concat([P5, P6], ignore_index=True)
E = allp.pivot_table(index=["tag", "G", "h_c", "eta"], columns="seed", values="esc"); ns = E.shape[1]
def slopes(cols):
    out = {}
    for (tag, G), sub in E.groupby(level=[0, 1]):
        pts = []
        for h, s2 in sub.groupby(level=2):
            etas = s2.index.get_level_values(3).values; M = s2.values[:, cols]
            k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
            xs, fit = A.pava(etas, k / np.maximum(n, 1), np.maximum(n, 1)); v = A.crossing(xs, fit, 0.1)
            if np.isfinite(v) and v < 1.45: pts.append((h, v))
        if len(pts) >= 3: hh, vv = np.array(pts).T; out[(tag, G)] = (np.polyfit(hh, vv, 1)[0], len(pts))
    return out
est = slopes(np.arange(ns)); rng = np.random.default_rng(0); boots = [slopes(rng.integers(0, ns, ns)) for _ in range(1000)]
pred = {"lumped_tau10": 15.0 / 93.3, "twonode_tau5": 88.3 / 93.3}
rows = []
for (tag, G), (s, n) in est.items():
    if tag == "baseline": continue
    rb = [b[(tag, G)][0] / b[("baseline", G)][0] for b in boots if (tag, G) in b and ("baseline", G) in b]
    r = s / est[("baseline", G)][0]
    rows.append({"variant": tag, "filler": gname(G), "points": n, "ratio": r, "ratio_lo": np.percentile(rb, 2.5), "ratio_hi": np.percentile(rb, 97.5),
                 "predicted": pred[tag], "err": r / pred[tag] - 1})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "P6e_slope_ratios_bootstrap.csv"), index=False); print(t.round(3).to_string(index=False))
