"""P6a: calibration envelope. Critical eta and design rule for core- and surface-matched calibrations vs baseline."""
from review_common import *
B = 1000
base = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); base["tag"] = "baseline (15 s)"
keep = base.G.isin([C.G_CASES[g] for g in ("air_2mm", "foam_2mm", "silicone_2mm")]) & base.h_c.isin([2, 5, 10, 20, 35, 50, 75])
frames = [base[keep]]
for f, t in (("P6a_v2.1-core", "core-matched (14 s)"), ("P6a_v2.1-surf", "surface-matched (20 s)")):
    d = A.tidy(os.path.join(RES, f + ".jsonl.gz")); d["tag"] = t; frames.append(d)
allp = pd.concat(frames, ignore_index=True)
crit = A.critical_eta(allp, levels=(0.1, 0.5), B=B); crit.to_csv(os.path.join(OUT, "P6a_critical_eta.csv"), index=False)
fit = rule_fit(crit); fit.to_csv(os.path.join(OUT, "P6a_rule.csv"), index=False)
print(fit.round(4).to_string(index=False))
crit["filler"] = crit.G.map(gname)
piv = crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10")
print("\ncritical eta10 by calibration:"); print(piv.round(3).to_string())
