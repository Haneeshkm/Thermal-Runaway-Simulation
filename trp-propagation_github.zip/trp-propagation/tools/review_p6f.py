"""P6f: array size / initiator position at near-threshold points (v2.1), boundary vent share lost vs redistributed."""
from review_common import *
p = A.tidy(os.path.join(RES, "P6f_size_boundary.jsonl.gz"))
p["config"] = p.point.str.split("|").str[0].str[2:]; p["boundary"] = p.point.str.split("|").str[1].str[2:]
p["tag"] = p.config + "|" + p.boundary
crit = A.critical_eta(p, levels=(0.1, 0.5), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "P6f_critical_eta.csv"), index=False)
print(crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10").round(3).T.to_string())
# seed-paired comparisons against 5x5 centre (lost) at every point
recs = C.load(os.path.join(RES, "P6f_size_boundary.jsonl.gz"))
ref = {(d["point"].split("|", 2)[2], d["seed"]): d["esc"] for d in recs if d["point"].startswith("S=5x5_centre|B=lost")}
rows = []
for tag in sorted(set(p.tag)):
    if tag == "5x5_centre|lost": continue
    sub = [d for d in recs if d["point"].startswith(f"S={tag.split('|')[0]}|B={tag.split('|')[1]}")]
    up = sum(1 for d in sub if d["esc"] and not ref[(d["point"].split("|", 2)[2], d["seed"])])
    dn = sum(1 for d in sub if not d["esc"] and ref[(d["point"].split("|", 2)[2], d["seed"])])
    from scipy.stats import binomtest
    rows.append({"config": tag, "runs": len(sub), "more_escape": up, "less_escape": dn,
                 "mcnemar_p": binomtest(up, up + dn, 0.5).pvalue if up + dn else 1.0,
                 "P_esc": np.mean([d["esc"] for d in sub]), "P_esc_ref": np.mean([ref[(d["point"].split("|", 2)[2], d["seed"])] for d in sub])})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "P6f_paired.csv"), index=False); print(t.round(4).to_string(index=False))
