"""Round-2 #17/#18: full-model histories at near-boundary points. (i) Peak core temperature of first-ring neighbours in runs
with no first-ring failure, against the reduced-order T_c,pk at the run's effective eta; (ii) temperatures of the three other
neighbours of the first first-ring cell to fail, at its failure time."""
from review_common import *
import json, trp_v2 as V, time
rom = json.load(open(os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json"))); etas = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)])
PTS = [("air_2mm", 10.0, 0.72), ("foam_2mm", 20.0, 0.91), ("silicone_2mm", 10.0, 0.93)]
out = os.path.join(OUT, "R2_hist.json"); R = json.load(open(out)) if os.path.exists(out) else {}
t0 = time.time()
for g, h, e in PTS:
    G = C.G_CASES[g]; key = f"{g}_{h}_{e}"; R.setdefault(key, {"rom_vs_mc": [], "sink": []})
    Tp = np.array([rom[f"{G}_{int(h)}_{x}"] for x in etas])
    done = {x["seed"] for x in R[key]["rom_vs_mc"]} | {x["seed"] for x in R[key]["sink"]} | set(R[key].get("seeds_done", []))
    for s in range(40):
        if s in done: continue
        if time.time() - t0 > 240: break
        r = V.run(V.baseline_v2(eta_lo=e, eta_hi=e, G_lo=G, G_hi=G, h_c=h, record_history=True), s)
        c = r["cells"]; Tc = np.array(r["history"]["Tc"]); Ts = np.array(r["history"]["T"]); t = np.array(r["history"]["t"])
        ring = c["ring"]; ini = ring.index(0); r1 = [i for i, x in enumerate(ring) if x == 1]
        trig1 = [i for i in r1 if c["trig"][i]]
        if not trig1:
            rom_pk = float(np.interp(e * c["fej"][ini] / 0.825, etas, Tp))
            for i in r1: R[key]["rom_vs_mc"].append({"seed": s, "cell": i, "mc_peak": float(Tc[:, i].max()), "rom": rom_pk})
        else:
            j = min(trig1, key=lambda i: c["t_trig"][i]); k = int(np.searchsorted(t, c["t_trig"][j]))
            rr, cc = divmod(j, 5); others = [rr2 * 5 + cc2 for rr2, cc2 in ((rr - 1, cc), (rr + 1, cc), (rr, cc - 1), (rr, cc + 1)) if 0 <= rr2 < 5 and 0 <= cc2 < 5 and rr2 * 5 + cc2 != ini]
            R[key]["sink"].append({"seed": s, "exposed_can": float(Ts[k, j]), "exposed_core": float(Tc[k, j]), "sink_can_mean": float(Ts[k, others].mean()),
                                   "sink_core_mean": float(Tc[k, others].mean()), "t_fail": float(c["t_trig"][j])})
        R[key].setdefault("seeds_done", []).append(s)
        json.dump(R, open(out, "w"))
print({k: len(v.get("seeds_done", [])) for k, v in R.items()}, f"{time.time()-t0:.0f}s")
