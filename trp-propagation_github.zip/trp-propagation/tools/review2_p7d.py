"""P7d: fine-grid (0.02) critical eta at the 20 design-rule settings; refit of the linear rule with seed-block bootstrap."""
from review_common import *
import json
from scipy.stats import f as Fdist
p = A.tidy(os.path.join(RES, "P7d_fine.jsonl.gz")); p["tag"] = "fine"
crit = A.critical_eta(p, levels=(0.1, 0.5), B=2000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(ROOT, "analysis", "T_critical_eta_fine.csv"), index=False)
coarse = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv"))
m = crit.merge(coarse[["G", "h_c", "eta10", "eta50"]], on=["G", "h_c"], suffixes=("", "_coarse"))
m["d10"] = m.eta10 - m.eta10_coarse; m["d50"] = m.eta50 - m.eta50_coarse
L = {"d10": [float(m.d10.min()), float(m.d10.median()), float(m.d10.max())], "d50": [float(m.d50[np.isfinite(m.d50)].min()), float(m.d50[np.isfinite(m.d50)].median()), float(m.d50[np.isfinite(m.d50)].max())],
     "edge_flags": m[["filler", "h_c", "eta10_flag", "eta50_flag"]].to_dict("records")}
# rule fit with seed-block bootstrap of the whole fit (isotonic on fine grid, then line)
E = p.pivot_table(index=["G", "h_c", "eta"], columns="seed", values="esc"); ns = E.shape[1]
def crit_from(cols, level):
    out = {}
    for (G, h), sub in E.groupby(level=[0, 1]):
        etas = sub.index.get_level_values(2).values; M = sub.values[:, cols]
        k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
        xs, fit = A.pava(etas, k / np.maximum(n, 1), np.maximum(n, 1)); out[(G, h)] = A.crossing(xs, fit, level)
    return out
def fit(cr):
    res = {}
    for G in (0.013, 0.041, 0.102):
        pts = sorted((h, v) for (g, h), v in cr.items() if np.isclose(g, G) and np.isfinite(v))
        if len(pts) >= 3: h, v = np.array(pts).T; b, a = np.polyfit(h, v, 1); res[G] = (a, b, len(pts), h, v)
    return res
rng = np.random.default_rng(0)
for lev, tag in ((0.1, "10"), (0.5, "50")):
    est = fit(crit_from(np.arange(ns), lev)); boots = {G: [] for G in est}
    for _ in range(1000):
        fb = fit(crit_from(rng.integers(0, ns, ns), lev))
        for G in est:
            if G in fb: boots[G].append(fb[G][:2])
    for G, (a, b, n, h, v) in est.items():
        bb = np.array(boots[G]); yh = a + b * h
        L[f"rule{tag}_{gname(G)}"] = {"eta0": a, "kappa": b, "n": n, "R2": float(1 - ((v - yh) ** 2).sum() / ((v - v.mean()) ** 2).sum()),
                                     "max_resid": float(np.abs(v - yh).max()), "eta0_ci": list(np.percentile(bb[:, 0], [2.5, 97.5])), "kappa_ci": list(np.percentile(bb[:, 1], [2.5, 97.5]))}
    # pooled common-slope test
    rows = [(G, h_, v_) for G, (a, b, n, h, v) in est.items() for h_, v_ in zip(h, v)]
    g_, h_, y = map(np.array, zip(*rows)); gi = pd.Categorical(g_).codes; k = gi.max() + 1
    Xs = np.column_stack([np.eye(k)[gi], np.eye(k)[gi] * h_[:, None]]); Xp = np.column_stack([np.eye(k)[gi], h_])
    rs = ((y - Xs @ np.linalg.lstsq(Xs, y, rcond=None)[0]) ** 2).sum(); rp = ((y - Xp @ np.linalg.lstsq(Xp, y, rcond=None)[0]) ** 2).sum()
    nn = len(y); F = ((rp - rs) / (Xs.shape[1] - Xp.shape[1])) / (rs / (nn - Xs.shape[1]))
    aic = lambda r_, p_: nn * np.log(r_ / nn) + 2 * p_
    L[f"pooled{tag}"] = {"n": nn, "F": F, "df": [Xs.shape[1] - Xp.shape[1], nn - Xs.shape[1]], "p": float(1 - Fdist.cdf(F, Xs.shape[1] - Xp.shape[1], nn - Xs.shape[1])),
                         "AIC_sep": aic(rs, Xs.shape[1]), "AIC_pooled": aic(rp, Xp.shape[1]), "common_kappa": float(np.linalg.lstsq(Xp, y, rcond=None)[0][-1])}
json.dump(L, open(os.path.join(OUT, "ledger_R2_P7d.json"), "w"), indent=1, default=float)
print(m[["filler", "h_c", "eta10", "eta10_lo", "eta10_hi", "eta10_coarse", "d10", "eta50", "eta50_coarse", "d50"]].round(3).to_string(index=False))
for k, v in L.items():
    if k.startswith(("rule", "pooled", "d")): print(k, {kk: (np.round(vv, 4).tolist() if isinstance(vv, (list, np.ndarray)) else (round(vv, 4) if isinstance(vv, float) else vv)) for kk, vv in v.items()} if isinstance(v, dict) else np.round(v, 3))
