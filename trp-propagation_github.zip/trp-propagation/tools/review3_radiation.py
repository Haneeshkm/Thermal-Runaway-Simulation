"""Radiation at the geometric view factor F_rad = 0.16 (adjacent 21 mm cans, 2 mm gap) vs the assumed 0.06 (P1, seeds 0-39)."""
from review_common import *
import json
from scipy.stats import binomtest
R = C.load(os.path.join(RES, "P8a_radiation.jsonl.gz")); base = {(d["point"], d["seed"]): d for d in C.load(os.path.join(RES, "P1b_phase_v21.jsonl.gz")) if d["seed"] < 40}
more = less = n = 0; rows = []
for d in R:
    k = (d["point"].split("|", 1)[1], d["seed"]); b = base[k]; n += 1
    more += d["esc"] and not b["esc"]; less += (not d["esc"]) and b["esc"]
    rows.append({"point": k[0], "seed": d["seed"], "esc_rad": int(d["esc"]), "esc_base": int(b["esc"]),
                 "dt_first": (d["t_first_nbr"] - b["t_first_nbr"]) if d["t_first_nbr"] and b["t_first_nbr"] else np.nan})
t = pd.DataFrame(rows)
L = {"runs": n, "more_escape": int(more), "less_escape": int(less), "p": binomtest(int(more), int(more + less), 0.5).pvalue if more + less else 1.0,
     "dt_first_median": float(t.dt_first.median()), "dt_first_p05": float(t.dt_first.quantile(0.05))}
# critical eta on the same eta sets, seeds 0-39, isotonic + interpolation
t["G"] = t.point.str.extract(r"G=(\w+?)\|")[0].map(C.G_CASES); t["eta"] = t.point.str.extract(r"eta=([\d.]+)")[0].astype(float); t["h_c"] = t.point.str.extract(r"h=(\d+)")[0].astype(float)
res = []
for (G, h), g in t.groupby(["G", "h_c"]):
    for col in ("esc_base", "esc_rad"):
        s = g.groupby("eta")[col].agg(["sum", "count"]).reset_index()
        xs, fit = A.pava(s.eta.values, (s["sum"] / s["count"]).values, s["count"].values)
        res.append({"filler": gname(G), "h_c": h, "variant": col, "eta10": A.crossing(xs, fit, 0.1), "eta50": A.crossing(xs, fit, 0.5)})
r = pd.DataFrame(res).pivot_table(index=["filler", "h_c"], columns="variant", values=["eta10", "eta50"])
r.columns = [f"{a}_{b}" for a, b in r.columns]; r["d10"] = r.eta10_esc_rad - r.eta10_esc_base; r["d50"] = r.eta50_esc_rad - r.eta50_esc_base
L["d10"] = [float(r.d10.min()), float(r.d10.max())]; L["d50"] = [float(r.d50.min()), float(r.d50.max())]; L["table"] = r.round(4).reset_index().to_dict("records")
json.dump(L, open(os.path.join(OUT, "ledger_R3_radiation.json"), "w"), indent=1, default=float)
print({k: v for k, v in L.items() if k != "table"}); print(r.round(3).to_string())
