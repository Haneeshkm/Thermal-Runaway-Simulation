"""Round-2 #10: parametric monotone dose-response fits for eta*_p, validated against the fine-grid P6b estimates."""
from review_common import *
import statsmodels.api as sm, json
from scipy.stats import norm
P1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
LINKS = {"logit": sm.families.links.Logit(), "probit": sm.families.links.Probit(), "cloglog": sm.families.links.CLogLog()}
def inv_link(name, p):
    return {"logit": np.log(p / (1 - p)), "probit": norm.ppf(p), "cloglog": np.log(-np.log(1 - p))}[name]
def eta_star(g, link, p):
    k = g.groupby("eta").esc.agg(["sum", "count"]).reset_index()
    if k["sum"].sum() == 0 or (k["sum"] == k["count"]).all(): return np.nan
    # use the points that bracket the transition: last all-zero below and first all-one above, plus everything between
    nz = k.index[k["sum"] > 0]; nf = k.index[k["sum"] < k["count"]]
    lo = max(nz.min() - 1, 0); hi = min(nf.max() + 1, len(k) - 1); kk = k.iloc[lo:hi + 1]
    if len(kk) < 3: return np.nan
    X = sm.add_constant(kk.eta.values); y = np.column_stack([kk["sum"], kk["count"] - kk["sum"]])
    try:
        m = sm.GLM(y, X, family=sm.families.Binomial(link=LINKS[link])).fit()
        b0, b1 = m.params
        return (inv_link(link, p) - b0) / b1 if b1 > 0 else np.nan
    except Exception:
        return np.nan
fine = pd.read_csv(os.path.join(OUT, "P6b_fine_vs_coarse.csv"))
rows = []
for _, r in fine.iterrows():
    G = C.G_CASES[r.filler]; g = P1[np.isclose(P1.G, G) & (P1.h_c == r.h_c)]
    row = {"filler": r.filler, "h_c": r.h_c, "isotonic_coarse": r.eta10_coarse, "fine_grid": r.eta10_fine}
    for ln in LINKS: row[ln] = eta_star(g, ln, 0.1)
    rows.append(row)
t = pd.DataFrame(rows)
for ln in ["isotonic_coarse"] + list(LINKS): t[f"err_{ln}"] = t[ln] - t.fine_grid
print(t.round(3).to_string(index=False))
print({ln: round(float(t[f"err_{ln}"].abs().mean()), 4) for ln in ["isotonic_coarse"] + list(LINKS)})
t.to_csv(os.path.join(OUT, "R2_param_validation.csv"), index=False)
