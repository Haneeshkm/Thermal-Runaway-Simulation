"""P6c: trigger-temperature distribution (SD 8 / 16 C, wide bounds 165-260 C) vs baseline (SD 12, bounds 180-245)."""
from review_common import *
p = A.tidy(os.path.join(RES, "P6c_trigger.jsonl.gz")); p["tag"] = p.point.str.split("|").str[0].str[2:]
base = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); base["tag"] = "baseline"
base = base[base.G.isin([0.013, 0.102]) & base.h_c.isin([5, 35])]
crit = A.critical_eta(pd.concat([base, p], ignore_index=True), levels=(0.1, 0.5), B=1000)
crit["filler"] = crit.G.map(gname); crit.to_csv(os.path.join(OUT, "P6c_critical_eta.csv"), index=False)
print(crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10").round(3).to_string())
print(crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta50").round(3).to_string())
for t in ("sd8", "sd16", "wide"):
    d = crit[crit.tag == t].set_index(["G", "h_c"]); b = crit[crit.tag == "baseline"].set_index(["G", "h_c"])
    k = {G: (d.loc[(G, 35), "eta10"] - d.loc[(G, 5), "eta10"]) / 30 for G in (0.013, 0.102)}
    kb = {G: (b.loc[(G, 35), "eta10"] - b.loc[(G, 5), "eta10"]) / 30 for G in (0.013, 0.102)}
    print(f"{t}: slope 5->35 air {k[0.013]:.4f} (base {kb[0.013]:.4f})  silicone {k[0.102]:.4f} (base {kb[0.102]:.4f})")
