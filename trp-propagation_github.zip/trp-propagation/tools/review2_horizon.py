"""Round-2 #23: rerun the slow directional cascades (failures after 1500 s in P6d) with a 5400 s horizon."""
from review_common import *
import json, time
src = C.load(os.path.join(RES, "P6d_split.jsonl.gz"))
late = [d for d in src if any(t is not None and t > 1500 for t in d["cells"]["t_trig"])]
out = os.path.join(OUT, "R2_long_horizon.json"); R = json.load(open(out)) if os.path.exists(out) else {}
t0 = time.time()
for d in late:
    k = f"{d['point']}|{d['seed']}"
    if k in R: continue
    if time.time() - t0 > 250: break
    ov = dict(d["overrides"]); ov["t_max"] = 5400.0
    r = C._job((d["point"], ov, d["seed"], "v2.1"))
    R[k] = {"n_1800": d["n_trig"], "esc_1800": d["esc"], "n_5400": r["n_trig"], "esc_5400": r["esc"], "t_end": r["t_end"],
            "last_fail": max(t for t in r["cells"]["t_trig"] if t is not None)}
    json.dump(R, open(out, "w"))
print(len(R), "of", len(late), f"{time.time()-t0:.0f}s")
