"""Round-2 analyses on existing data: #12 weighted/censored rule fits, #14 matched-K independent-cascade null,
#15 order-statistic predictors, #16 clustered-regression coefficient table, #20 FDR counts, #21 P6f stratified, #22 Dirichlet stats."""
from review_common import *
import json, statsmodels.api as sm
from scipy.stats import binomtest, norm
from scipy.optimize import minimize
L = {}
P1 = A.tidy(os.path.join(RES, "P1b_phase_v21.jsonl.gz")); recs = C.load(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))
crit = pd.read_csv(os.path.join(ROOT, "analysis", "T_critical_eta_v21.csv"))
# ---- #12 weighted fit (weights 1/var from bootstrap half-width) and censored (Tobit-type) fit treating >=1.45/inf as right-censored at 1.45
for G in (0.013, 0.041, 0.102):
    d = crit[np.isclose(crit.G, G)].sort_values("h_c"); g = gname(G)
    ok = d[np.isfinite(d.eta10) & (d.eta10 < 1.45) & np.isfinite(d.eta10_lo)]
    w = 1 / (((ok.eta10_hi - ok.eta10_lo) / (2 * 1.96)) ** 2)
    Xw = sm.add_constant(ok.h_c.values); mw = sm.WLS(ok.eta10.values, Xw, weights=w.values).fit()
    cens = d[(~np.isfinite(d.eta10)) & (d.eta10 > 0) | (d.eta10 >= 1.45)]
    cens = cens[cens.h_c <= 100]                     # the grid's informative range
    x, y = ok.h_c.values, ok.eta10.values; xc = cens.h_c.values
    def nll(p):
        a, b, ls = p; s = np.exp(ls)
        return -(norm.logpdf(y, a + b * x, s).sum() + norm.logsf(1.45, a + b * xc, s).sum())
    b0, a0 = np.polyfit(x, y, 1)
    r = minimize(nll, [a0, b0, np.log(0.01)], method="Nelder-Mead", options={"xatol": 1e-8, "fatol": 1e-10, "maxiter": 5000})
    L[f"rule_fits_{g}"] = {"OLS": [a0, b0], "WLS": list(mw.params), "censored": list(r.x[:2]), "n_used": len(ok), "n_censored": len(cens)}
# ---- #15 order statistics of first-ring trigger temperatures
Pp = P1.groupby("point").esc.mean(); N = P1.groupby("point").size(); tp = Pp[(Pp >= 0.05) & (Pp <= 0.95) & (N >= 200)].index
rows = []
for d in recs:
    if d["point"] not in tp: continue
    c = d["cells"]; r1 = [i for i, x in enumerate(c["ring"]) if x == 1]; T = sorted(c["Ttrig"][i] for i in r1)
    ini = c["ring"].index(0)
    rows.append({"point": d["point"], "seed": d["seed"], "esc": int(d["esc"]), "T1": T[0], "T2": T[1], "T12": (T[0] + T[1]) / 2, "Tmean": np.mean(T),
                 "fej_ini": c["fej"][ini]})
tr = pd.DataFrame(rows); Xd = pd.get_dummies(tr.point, drop_first=True, dtype=float)
res = {}
for nm, col in (("min", "T1"), ("second_min", "T2"), ("mean_two_lowest", "T12"), ("mean_all_four", "Tmean")):
    X = Xd.copy(); X["Tz"] = (tr[col] - tr[col].mean()) / 12.0; X["fz"] = (tr.fej_ini - tr.fej_ini.mean()) / 0.0433; X = sm.add_constant(X)
    m = sm.Logit(tr.esc.values, X).fit(disp=False, method="bfgs", maxiter=3000, cov_type="cluster", cov_kwds={"groups": tr.seed.values})
    res[nm] = {"OR_per_12C": float(np.exp(m.params["Tz"])), "CI": list(np.exp(m.params["Tz"] + np.array([-1.96, 1.96]) * m.bse["Tz"])), "llf": float(m.llf), "AIC": float(m.aic)}
L["order_statistics"] = res
# ---- #16 full coefficient table (min model, as in the article)
X = Xd.copy(); X["Ttrig_r1_min_z"] = (tr.T1 - tr.T1.mean()) / 12.0; X["fej_ini_z"] = (tr.fej_ini - tr.fej_ini.mean()) / 0.0433
fr1 = []
for d in recs:
    if d["point"] not in tp: continue
    c = d["cells"]; r1 = [i for i, x in enumerate(c["ring"]) if x == 1]; fr1.append(np.mean([c["fej"][i] for i in r1]))
X["fej_r1_mean_z"] = (np.array(fr1) - np.mean(fr1)) / 0.0217; X = sm.add_constant(X)
m0 = sm.Logit(tr.esc.values, X).fit(disp=False, method="bfgs", maxiter=3000)
mc = sm.Logit(tr.esc.values, X).fit(disp=False, method="bfgs", maxiter=3000, cov_type="cluster", cov_kwds={"groups": tr.seed.values})
L["coef_table"] = {k: {"logodds": float(mc.params[k]), "se_naive": float(m0.bse[k]), "se_cluster": float(mc.bse[k]), "p_cluster": float(mc.pvalues[k])}
                   for k in ("Ttrig_r1_min_z", "fej_ini_z", "fej_r1_mean_z")}
L["coef_meta"] = {"runs": len(tr), "points": int(tr.point.nunique()), "clusters_seeds": int(tr.seed.nunique()), "point_fixed_effects": int(tr.point.nunique() - 1),
                  "cov": "statsmodels Logit, cov_type='cluster' (CR1 sandwich with small-sample correction), groups = seed", "converged": bool(mc.mle_retvals["converged"])}
# ---- #20 Benjamini-Hochberg counts for P2
P2 = A.tidy(os.path.join(RES, "P2_epistemic.jsonl.gz")); P2["cell"] = P2.point.str.split("|", n=1).str[1]
b = P2[P2.tag == "baseline"].set_index(["cell", "seed"]).esc; pv = []
for tag, g in P2[P2.tag != "baseline"].groupby("tag"):
    x = g.set_index(["cell", "seed"]).esc; bb = b.reindex(x.index)
    for c_ in x.index.get_level_values(0).unique():
        xa, ba = x.xs(c_), bb.xs(c_); n = int((xa != ba).sum()); k = int(((xa == 1) & (ba == 0)).sum())
        pv.append((tag, c_, binomtest(k, n, 0.5).pvalue if n else 1.0))
pvd = pd.DataFrame(pv, columns=["tag", "cell", "p"]); m_ = len(pvd); pvd = pvd.sort_values("p").reset_index(drop=True)
pvd["bh"] = pvd.p <= (np.arange(1, m_ + 1) / m_) * 0.05; kmax = pvd.index[pvd.bh].max() if pvd.bh.any() else -1
pvd["sig_bh"] = pvd.index <= kmax; pvd["sig_raw"] = pvd.p < 0.05
L["P2_fdr"] = {"tests": m_, "raw": int(pvd.sig_raw.sum()), "bh": int(pvd.sig_bh.sum()), "by_tag": pvd.groupby("tag")[["sig_raw", "sig_bh"]].sum().astype(int).to_dict("index")}
# ---- #21 P6f stratified by filler and cooling
p6 = A.tidy(os.path.join(RES, "P6f_size_boundary.jsonl.gz")); p6["cfg"] = p6.point.str.split("|").str[0].str[2:] + "|" + p6.point.str.split("|").str[1].str[2:]
st = p6.groupby(["cfg", "G", "h_c"]).esc.mean().unstack(["G", "h_c"]); st.columns = [f"{gname(G)}_h{int(h)}" for G, h in st.columns]
st.to_csv(os.path.join(OUT, "R2_P6f_stratified.csv")); L["P6f_stratified"] = st.round(3).to_dict("index")
# ---- #22 Dirichlet summary statistics
rng = np.random.default_rng(1); ds = {}
for cconc in (4.0, 1.0):
    w = np.sort(rng.dirichlet([cconc] * 4, 200000), axis=1)[:, ::-1]
    ds[f"c{int(cconc)}"] = {"wmax_mean": float(w[:, 0].mean()), "wmax_p95": float(np.percentile(w[:, 0], 95)),
                            "top2_mean": float((w[:, 0] + w[:, 1]).mean()), "top2_p95": float(np.percentile(w[:, 0] + w[:, 1], 95))}
L["dirichlet"] = ds
json.dump(L, open(os.path.join(OUT, "ledger_R2a.json"), "w"), indent=1, default=float)
print(json.dumps({k: L[k] for k in ("order_statistics", "coef_meta", "P2_fdr", "dirichlet")}, indent=1, default=lambda x: round(float(x), 4))[:3500])
for G in ("air_2mm", "foam_2mm", "silicone_2mm"): print(G, {k: [round(v, 4) for v in vals] if isinstance(vals, list) else vals for k, vals in L[f"rule_fits_{G}"].items()})
print(st.round(3).to_string())
