from review_common import *
import json
from scipy.stats import truncnorm, binom
R = json.load(open(os.path.join(OUT, "R3_rom_beta.json"))); rom0 = json.load(open(os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json")))
etas = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)]); F = lambda T: truncnorm.cdf(T, -2.5, 35 / 12, loc=210, scale=12)
fej = np.linspace(0.75, 0.90, 16); ef = np.linspace(0.4, 1.6, 2401)
def cross(Tp, L=0.1):
    T = np.interp(np.outer(ef, fej / 0.825), etas, Tp); p = (1 - binom.cdf(1, 4, F(T))).mean(axis=1)
    return ef[np.argmax(p >= L)] if p.max() >= L else np.inf
rows = []
for G in (0.013, 0.041, 0.102):
    for h in (2, 10, 35, 75):
        r = {"filler": gname(G), "h_c": h, "beta0": cross(np.array([rom0[f"{G}_{h}_{e}"] for e in etas]))}
        for b in (0.15, 0.30): r[f"beta{b}"] = cross(np.array([R[f"{b}_{G}_{h}_{e}"] for e in etas]))
        rows.append(r)
t = pd.DataFrame(rows); print(t.round(3).to_string(index=False))
fit = []
for b in ("beta0", "beta0.15", "beta0.3"):
    for G in (0.013, 0.041, 0.102):
        d = t[(t.filler == gname(G)) & np.isfinite(t[b]) & (t[b] < 1.45)]
        if len(d) >= 3: k, a = np.polyfit(d.h_c, d[b], 1); fit.append({"beta": b, "filler": gname(G), "eta0": a, "kappa": k, "n": len(d)})
f = pd.DataFrame(fit); print(f.round(4).to_string(index=False))
t.to_csv(os.path.join(OUT, "R3_rom_beta_crit.csv"), index=False); f.to_csv(os.path.join(OUT, "R3_rom_beta_rule.csv"), index=False)
