"""P7a: excess (eta>1) heat released through a 30 s or 120 s lag vs instantaneous (P1b, same seeds and eta grid)."""
from review_common import *
import json
from scipy.stats import binomtest
p = A.tidy(os.path.join(RES, "P7a_combustion.jsonl.gz")); p["tag"] = p.point.str.split("|").str[0].str[2:]
b = pd.read_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl"))
keys = set(zip(p.G.round(4), p.h_c, p.eta)); b = b[[k in keys for k in zip(b.G.round(4), b.h_c, b.eta)]].copy(); b["tag"] = "instantaneous"
crit = A.critical_eta(pd.concat([b, p], ignore_index=True), levels=(0.1, 0.5), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "R2_P7a_critical_eta.csv"), index=False)
pv = crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10")
print(pv.round(3).to_string())
# seed-paired outcome changes at eta > 1 points
R = C.load(os.path.join(RES, "P7a_combustion.jsonl.gz")); base = {(d["point"], d["seed"]): d["esc"] for d in C.load(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))}
L = {}
for tau in ("comb30", "comb120"):
    more = less = n = 0
    for d in R:
        if not d["point"].startswith(f"K={tau}|"): continue
        if d["overrides"]["eta_lo"] <= 1.0: continue
        k = (d["point"].split("|", 1)[1], d["seed"])
        if k in base: n += 1; more += d["esc"] and not base[k]; less += (not d["esc"]) and base[k]
    L[tau] = {"paired_runs_eta_gt1": n, "more_escape": int(more), "less_escape": int(less), "p": binomtest(int(more), int(more + less), 0.5).pvalue if more + less else 1.0}
pv2 = pv.copy(); pv2["d30"] = pv2.comb30 - pv2.instantaneous; pv2["d120"] = pv2.comb120 - pv2.instantaneous
L["eta10"] = pv2.round(4).reset_index().to_dict("records")
fin = pv2[np.isfinite(pv2.d30)]; L["d30_range"] = [float(fin.d30.min()), float(fin.d30.max())]
fin = pv2[np.isfinite(pv2.d120)]; L["d120_range"] = [float(fin.d120.min()), float(fin.d120.max())]
json.dump(L, open(os.path.join(OUT, "ledger_R2_P7a.json"), "w"), indent=1, default=float)
print({k: v for k, v in L.items() if k != "eta10"})
