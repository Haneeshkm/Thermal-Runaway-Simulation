"""#3 reduced-order model grids at beta = 0.15 and 0.30 (vent heat deposited directly in the core), resumable."""
from review_common import *
import json, time, trp_v2 as V
out = os.path.join(OUT, "R3_rom_beta.json"); R = json.load(open(out)) if os.path.exists(out) else {}
etas = [round(0.4 + 0.05 * k, 2) for k in range(25)]; t0 = time.time()
for beta in (0.15, 0.30):
    for G in (0.013, 0.041, 0.102):
        for h in (2, 10, 35, 75):
            for e in etas:
                k = f"{beta}_{G}_{h}_{e}"
                if k in R: continue
                if time.time() - t0 > 270: json.dump(R, open(out, "w")); print(len(R), "of 600"); sys.exit()
                r = V.run(V.baseline_v2(calib="v2.1", freeze_others=True, eta_lo=e, eta_hi=e, G_lo=G, G_hi=G, h_c=float(h), beta=beta,
                                        fej_lo=0.825, fej_hi=0.825, sd_mass=0, sd_Cp=0, sd_H=0, t_max=600.0), 0)
                c = r["cells"]; R[k] = float(np.mean([c["Tmax_c"][i] for i, x in enumerate(c["ring"]) if x == 1]))
json.dump(R, open(out, "w")); print(len(R), "of 600 (done)")
