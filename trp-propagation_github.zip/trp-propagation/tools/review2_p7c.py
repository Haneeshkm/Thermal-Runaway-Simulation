"""P7c: conduction-only diagonal links. First-ring necessity and boundary shift vs face-only (P1b, same seeds)."""
from review_common import *
import json
R = C.load(os.path.join(RES, "P7c_diagonal.jsonl.gz")); L = {}
viol = 0; esc = 0; diag_first = 0
for d in R:
    if not d["esc"]: continue
    esc += 1; c = d["cells"]
    r1 = sum(1 for t, r in zip(c["trig"], c["ring"]) if t and r == 1)
    if r1 == 0: viol += 1
    # which ring-2 cell failed first, and was a ring-1 cell already failed then?
    t1 = min([t for t, r in zip(c["t_trig"], c["ring"]) if t is not None and r == 1], default=np.inf)
    t2 = min([t for t, r in zip(c["t_trig"], c["ring"]) if t is not None and r >= 2], default=np.inf)
    if t2 < t1: diag_first += 1
L.update(escapes=esc, escapes_without_first_ring=viol, ring2_before_ring1=diag_first, runs=len(R))
p = A.tidy(os.path.join(RES, "P7c_diagonal.jsonl.gz")); p["tag"] = "diagonal"
b = pd.read_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl")); b = b[b.G.isin([0.013, 0.041, 0.102]) & b.h_c.isin([2, 10, 35])].copy(); b["tag"] = "face"
crit = A.critical_eta(pd.concat([b, p], ignore_index=True), levels=(0.1, 0.5), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "R2_P7c_critical_eta.csv"), index=False)
pv = crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10"); pv["d"] = pv.diagonal - pv.face
L["eta10"] = pv.round(4).reset_index().to_dict("records")
# paired comparison on common (point, seed)
key = lambda d: (d["point"].split("|", 1)[1], d["seed"])
face = {(d["point"], d["seed"]): d["esc"] for d in C.load(os.path.join(RES, "P1b_phase_v21.jsonl.gz"))}
more = less = n = 0
for d in R:
    k = (d["point"].split("|", 1)[1], d["seed"])
    if k in face: n += 1; more += d["esc"] and not face[k]; less += (not d["esc"]) and face[k]
from scipy.stats import binomtest
L.update(paired_n=n, more_escape=int(more), less_escape=int(less), mcnemar_p=binomtest(int(more), int(more + less), 0.5).pvalue if more + less else 1.0)
json.dump(L, open(os.path.join(OUT, "ledger_R2_P7c.json"), "w"), indent=1, default=float)
print({k: v for k, v in L.items() if k != "eta10"}); print(pv.round(3).to_string())
