import sys, json, os; sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import campaign as C
pts=json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'p8a_points.json')))
P=[C.point('R=frad016|'+p, eta_lo=e, eta_hi=e, G_lo=C.G_CASES[g], G_hi=C.G_CASES[g], h_c=float(h), F_eta=0.16) for p,e,h,g,_ in pts]
C.run(P, seeds=range(40), out=os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results_v2', 'P8a_radiation.jsonl.gz'), workers=1, base='v2.1', verbose=False)
