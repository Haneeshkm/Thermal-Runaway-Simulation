"""Time-step and sub-step halving at three stress points, seed-paired with the original runs."""
from review_common import *
import json
from scipy.stats import binomtest
R = C.load(os.path.join(RES, "P8b_numerics_stress.jsonl.gz"))
B = {}
for f in ("P1b_phase_v21", "P6d_split"):
    for d in C.load(os.path.join(RES, f + ".jsonl.gz")):
        B[(d["point"], d["seed"])] = d
L = {}; rows = []
for d in R:
    var, pt = d["point"].split("|", 1)
    b = B[(pt, d["seed"])]
    dt = abs(d["t_first_nbr"] - b["t_first_nbr"]) if d["t_first_nbr"] and b["t_first_nbr"] else np.nan
    rows.append({"variant": var[2:], "point": pt, "esc_v": d["esc"], "esc_b": b["esc"], "n_v": d["n_trig"], "n_b": b["n_trig"], "dt": dt,
                 "res": abs(d["ledger"]["balance_residual_rel"])})
t = pd.DataFrame(rows)
for (v, p), g in t.groupby(["variant", "point"]):
    up = int(((g.esc_v) & (~g.esc_b)).sum()); dn = int(((~g.esc_v) & (g.esc_b)).sum())
    L[f"{v}|{p}"] = {"runs": len(g), "P_base": float(g.esc_b.mean()), "P_var": float(g.esc_v.mean()), "gained": up, "lost": dn,
                     "p": binomtest(up, up + dn, 0.5).pvalue if up + dn else 1.0, "cascade_size_changed": int((g.n_v != g.n_b).sum()),
                     "dt_max": float(g.dt.max()) if g.dt.notna().any() else None, "dt_p95": float(g.dt.quantile(0.95)) if g.dt.notna().any() else None,
                     "max_resid": float(g.res.max())}
json.dump(L, open(os.path.join(OUT, "ledger_R3_numerics.json"), "w"), indent=1, default=float)
for k, v in L.items(): print(k, {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in v.items()})
