"""P6e: separate lumping from the ejection-lag change (reference calibration v2.0, P5 seeds and grid)."""
from review_common import *
p6 = A.tidy(os.path.join(RES, "P6e_lumped.jsonl.gz")); p6["tag"] = p6.point.str.split("|").str[0].str[2:]
p5 = A.tidy(os.path.join(RES, "P5_robustness.jsonl.gz"))
p5 = p5[p5.tag.isin(["baseline", "lumped", "tau_ej=20"])].copy()
p5["tag"] = p5.tag.map({"baseline": "twonode_tau10 (baseline)", "lumped": "lumped_tau5 (P5)", "tau_ej=20": "twonode_tau20 (P5)"})
crit = A.critical_eta(pd.concat([p5, p6], ignore_index=True), levels=(0.1,), B=1000); crit["filler"] = crit.G.map(gname)
crit.to_csv(os.path.join(OUT, "P6e_critical_eta.csv"), index=False)
print(crit.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10").round(3).to_string())
fit = rule_fit(crit); b = fit[fit.tag.str.startswith("twonode_tau10")].set_index("filler").kappa
fit["ratio"] = fit.apply(lambda r: r.kappa / b.get(r.filler, np.nan) if pd.notna(r.get("kappa")) else np.nan, axis=1)
tau = {"twonode_tau10 (baseline)": 93.3, "lumped_tau5 (P5)": 10.0, "lumped_tau10": 15.0, "twonode_tau5": 88.3, "twonode_tau20 (P5)": 103.3}
fit["ratio_pred"] = fit.tag.map(lambda t: tau[t] / 93.3)
fit.to_csv(os.path.join(OUT, "P6e_rule.csv"), index=False); print(fit.round(3).to_string(index=False))
