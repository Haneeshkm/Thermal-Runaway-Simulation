"""Shared helpers for the review analyses (P6)."""
import os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import numpy as np, pandas as pd
import campaign as C, analysis_v2 as A

RES = os.path.join(ROOT, "results_v2"); OUT = os.path.join(ROOT, "analysis", "review")
os.makedirs(OUT, exist_ok=True)
INV = {v: k for k, v in C.G_CASES.items()}
def gname(G): return INV[min(INV, key=lambda x: abs(x - G))]

def tidy_tagged(name):
    """Tidy table with tag = everything before '|G=' (works for all campaign naming schemes)."""
    df = A.tidy(os.path.join(RES, name + ".jsonl.gz"))
    df["tag"] = df.point.str.split("|G=").str[0]
    df.loc[~df.point.str.contains(r"\|G=.*\|G=", regex=True) & ~df.tag.str.contains("="), "tag"] = "baseline"
    return df

def rule_fit(crit, level="10", edge=1.45):
    """Linear rule per (tag, G) on finite, non-edge estimates."""
    rows = []
    for (tag, G), g in crit.groupby(["tag", "G"]):
        d = g[np.isfinite(g[f"eta{level}"]) & (g[f"eta{level}"] < edge)].sort_values("h_c")
        if len(d) < 3: rows.append({"tag": tag, "filler": gname(G), "n": len(d)}); continue
        b, a = np.polyfit(d.h_c, d[f"eta{level}"], 1); yh = a + b * d.h_c
        rows.append({"tag": tag, "filler": gname(G), "n": len(d), "eta0": a, "kappa": b,
                     "R2": 1 - ((d[f"eta{level}"] - yh) ** 2).sum() / ((d[f"eta{level}"] - d[f"eta{level}"].mean()) ** 2).sum()})
    return pd.DataFrame(rows)
