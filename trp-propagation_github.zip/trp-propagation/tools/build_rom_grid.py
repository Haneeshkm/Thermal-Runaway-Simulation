"""Reduced-order ignition model (Sect. 2.6): peak core temperature of a first-ring neighbour that is not allowed
to fail, over eta x h_c x G, for one calibration.  Deterministic, nominal properties.  Resumable.

    python tools/build_rom_grid.py v2.1        ->  analysis/rom_Tpeak_v21.json
    python tools/build_rom_grid.py v2.0        ->  analysis/rom_Tpeak.json
"""
import json, os, sys, time
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import numpy as np
import trp_v2 as V

calib = sys.argv[1] if len(sys.argv) > 1 else "v2.1"
out = os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json" if calib == "v2.1" else "rom_Tpeak.json")
res = json.load(open(out)) if os.path.exists(out) else {}
for G in (0.013, 0.041, 0.102):
    for h in (2, 5, 10, 20, 35, 50, 75, 100):
        for e in [round(0.4 + 0.05 * k, 2) for k in range(25)]:
            key = f"{G}_{h}_{e}"
            if key in res:
                continue
            cfg = V.baseline_v2(calib=calib, freeze_others=True, eta_lo=e, eta_hi=e, G_lo=G, G_hi=G, h_c=float(h),
                                fej_lo=0.825, fej_hi=0.825, sd_mass=0, sd_Cp=0, sd_H=0, t_max=600.0)
            r = V.run(cfg, 0); c = r["cells"]
            r1 = [i for i, x in enumerate(c["ring"]) if x == 1]
            res[key] = float(np.mean([c["Tmax_c"][i] for i in r1]))
            json.dump(res, open(out, "w"))
print(f"{len(res)} grid points in {out}")
