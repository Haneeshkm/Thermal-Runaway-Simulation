"""Round-2: #18 closed form refitted inside the seed-block bootstrap; #19 leave-one-point-out slope ratios (P5, P6e);
#22 top-two exposure metric for directional splits."""
from review_common import *
import json, statsmodels.api as sm, statsmodels.formula.api as smf
import trp_v2 as V
L = {}
P1 = pd.read_pickle(os.path.join(ROOT, "analysis", "cache", "P1b_tidy.pkl"))
E = P1.pivot_table(index=["G", "h_c", "eta"], columns="seed", values="esc"); ns = E.shape[1]
A_s, fEz = 0.008, 0.825 * 83.9e3 / 4
def crit(cols, level):
    out = {}
    for (G, h), sub in E.groupby(level=[0, 1]):
        if G > 0.2: continue
        etas = sub.index.get_level_values(2).values; M = sub.values[:, cols]
        k = np.nansum(M, axis=1); n = np.sum(~np.isnan(M), axis=1)
        xs, fit = A.pava(etas, k / np.maximum(n, 1), np.maximum(n, 1)); out[(G, h)] = A.crossing(xs, fit, level)
    return out
def closed(cr, dT):
    pts = [(G, h, v) for (G, h), v in cr.items() if np.isfinite(v) and v < 1.45]
    G, h, v = map(np.array, zip(*pts)); Y = v * fEz / dT; X = np.column_stack([np.ones_like(h), h * A_s, 3 * G])
    return np.linalg.lstsq(X, Y, rcond=None)[0]
rng = np.random.default_rng(0)
for lev, tag, dTs in ((0.1, "10", (185.0, 172.44025396151827)), (0.5, "50", (185.0, 181.61249114435196))):
    est = {dT: closed(crit(np.arange(ns), lev), dT) for dT in dTs}; boots = {dT: [] for dT in dTs}
    for _ in range(1000):
        cr = crit(rng.integers(0, ns, ns), lev)
        for dT in dTs: boots[dT].append(closed(cr, dT))
    for dT in dTs:
        bb = np.array(boots[dT]); nm = "mean" if dT == 185.0 else "quantile"
        L[f"closed{tag}_{nm}_boot"] = {"est": list(est[dT]), "ci_lo": list(np.percentile(bb, 2.5, axis=0)), "ci_hi": list(np.percentile(bb, 97.5, axis=0))}
# ---- #19 leave-one-point-out slope ratios
c5 = pd.read_csv(os.path.join(ROOT, "analysis", "T_P5_critical_eta.csv")); c6 = pd.read_csv(os.path.join(OUT, "P6e_critical_eta.csv"))
c6 = c6[c6.tag.isin(["lumped_tau10", "twonode_tau5"])]
allc = pd.concat([c5[["tag", "G", "h_c", "eta10"]], c6[["tag", "G", "h_c", "eta10"]]])
def pts(tag, G):
    d = allc[(allc.tag == tag) & np.isclose(allc.G, G) & np.isfinite(allc.eta10) & (allc.eta10 < 1.45)].sort_values("h_c")
    return d.h_c.values, d.eta10.values
rows = []
for G in (0.013, 0.102):
    hb, vb = pts("baseline", G); sb = np.polyfit(hb, vb, 1)[0]
    for tag in sorted(set(allc.tag) - {"baseline"}):
        h, v = pts(tag, G)
        if len(h) < 3: continue
        full = np.polyfit(h, v, 1)[0] / sb
        loo = [np.polyfit(np.delete(h, i), np.delete(v, i), 1)[0] / sb for i in range(len(h)) if len(h) - 1 >= 2]
        rows.append({"variant": tag, "filler": gname(G), "points": len(h), "ratio": full, "loo_min": min(loo), "loo_max": max(loo)})
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "R2_loo_slope_ratios.csv"), index=False); print(t.round(3).to_string(index=False))
# ---- #22 top-two exposure metric
p = A.tidy(os.path.join(RES, "P6d_split.jsonl.gz")); p["tag"] = p.point.str.split("|").str[0].str[2:]
base = P1[P1.G.isin([0.013, 0.102]) & P1.h_c.isin([2, 10, 35, 75])].copy(); base["tag"] = "equal"
def ws(seed, conc):
    return np.sort(V._rng(seed, "split", 0, 0).dirichlet([conc] * 4))[::-1]
W = {(s, c): ws(s, c) for s in range(100) for c in (1.0, 4.0)}
p["w1"] = [W[(s, 1.0 if t == "dir1" else 4.0)][0] for s, t in zip(p.seed, p.tag)]
p["w12"] = [W[(s, 1.0 if t == "dir1" else 4.0)][:2].sum() for s, t in zip(p.seed, p.tag)]
base["w1"] = 0.25; base["w12"] = 0.5
allp = pd.concat([base, p], ignore_index=True); allp["eta_eff1"] = 4 * allp.eta * allp.w1; allp["eta_eff2"] = 2 * allp.eta * allp.w12
allp["d4"] = (allp.tag == "dir4").astype(int); allp["d1"] = (allp.tag == "dir1").astype(int)
rows = []
for (G, h), g in allp.groupby(["G", "h_c"]):
    for x in ("eta", "eta_eff1", "eta_eff2"):
        m = smf.logit(f"esc ~ {x} + d4 + d1", data=g).fit(disp=False, method="bfgs", maxiter=2000)
        rows.append({"filler": gname(G), "h_c": h, "x": x, "abs_dir4": abs(m.params["d4"]), "abs_dir1": abs(m.params["d1"]), "llf": m.llf})
tt = pd.DataFrame(rows); tt.to_csv(os.path.join(OUT, "R2_top2_metric.csv"), index=False)
summ = tt.groupby("x")[["abs_dir4", "abs_dir1", "llf"]].agg(["min", "max", "sum"]).round(3)
print(summ.to_string()); L["top2"] = {x: {c: [float(tt[tt.x == x][c].min()), float(tt[tt.x == x][c].max())] for c in ("abs_dir4", "abs_dir1")} | {"llf_sum": float(tt[tt.x == x].llf.sum())} for x in ("eta", "eta_eff1", "eta_eff2")}
json.dump(L, open(os.path.join(OUT, "ledger_R2b.json"), "w"), indent=1, default=float)
for k in [k for k in L if k.startswith("closed")]: print(k, {kk: [round(x, 2) for x in vv] for kk, vv in L[k].items()})
