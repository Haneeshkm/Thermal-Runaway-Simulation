"""#14 reduced-order model with a Dirichlet split (each neighbour its own share); #7 bracket with correlated inputs."""
from review_common import *
import json
from scipy.stats import truncnorm
rom = json.load(open(os.path.join(ROOT, "analysis", "rom_Tpeak_v21.json"))); etas = np.array([round(0.4 + 0.05 * k, 2) for k in range(25)])
a_, b_ = (180 - 210) / 12, (245 - 210) / 12
F = lambda T, mu=210.0: truncnorm.cdf(T, (180 - mu) / 12, (245 - mu) / 12, loc=mu, scale=12)
fej = np.linspace(0.75, 0.90, 16)                      # 16-point grid over the uniform prior of the initiator's f_ej
def Tpk(G, h, x):                                       # peak core T of a neighbour receiving the per-neighbour exposure x (eta units)
    Tp = np.array([rom[f"{G}_{int(h)}_{e}"] for e in etas]); return np.interp(x, etas, Tp, left=Tp[0], right=Tp[-1])
def p_k2(pk):                                           # P(at least 2 of 4) for heterogeneous probabilities (Poisson-binomial)
    q = 1 - pk; p0 = np.prod(q, axis=-1); p1 = sum(pk[..., k] * np.prod(np.delete(q, k, axis=-1), axis=-1) for k in range(4))
    return 1 - p0 - p1
rng = np.random.default_rng(5); W = {c: rng.dirichlet([c] * 4, 3000) for c in (1.0, 4.0)}
eg = np.round(np.arange(0.2, 1.6001, 0.01), 2)
def crossing(G, h, c=None, L=0.1, mu_shift=None):
    P = []
    for e in eg:
        if c is None:  # equal split
            x = np.outer(np.ones(1), e * fej / 0.825)[..., None] * np.ones(4)
            if mu_shift is None: pk = F(Tpk(G, h, x)); P.append(p_k2(pk).mean())
            else:  # lot effect: neighbours' trigger mean shifts with the initiator's f_ej (comonotone bracket)
                mu = 210.0 - mu_shift * (fej - 0.825) / 0.075
                pk = np.stack([F(Tpk(G, h, e * f / 0.825 * np.ones(4)), m) for f, m in zip(fej, mu)]); P.append(p_k2(pk).mean())
        else:
            x = 4 * e * W[c][:, None, :] * (fej / 0.825)[None, :, None]       # samples x fej x 4
            pk = F(Tpk(G, h, x)); P.append(p_k2(pk).mean())
    P = np.array(P); return float(eg[np.argmax(P >= L)]) if P.max() >= L else np.inf
crit6 = A.tidy(os.path.join(RES, "P6d_split.jsonl.gz")); mc = pd.read_csv(os.path.join(OUT, "P6d_critical_eta.csv")); low = pd.read_csv(os.path.join(OUT, "R3_loweta_critical.csv"))
rows = []
for G in (0.013, 0.102):
    for h in (2, 10, 35, 75):
        r = {"filler": gname(G), "h_c": h, "ROM_equal": crossing(G, h), "ROM_c4": crossing(G, h, 4.0), "ROM_c1": crossing(G, h, 1.0)}
        for tag, col in (("equal", "MC_equal"), ("dir4", "MC_c4"), ("dir1", "MC_c1")):
            m = mc[(mc.tag == tag) & np.isclose(mc.G, G) & (mc.h_c == h)]
            v = float(m.eta10.iloc[0]) if len(m) else np.nan
            l = low[(low.tag == tag) & np.isclose(low.G, G) & (low.h_c == h)]
            if len(l): v = float(l.eta10.iloc[0])
            r[col] = v
        rows.append(r)
t = pd.DataFrame(rows); t.to_csv(os.path.join(OUT, "R3_rom_directional.csv"), index=False); print(t.round(3).to_string(index=False))
# correlated-input bracket: neighbours' trigger mean lower by up to 12 C when the initiator's f_ej is at the top of its range
rb = []
for G in (0.013, 0.041, 0.102):
    for h in (2, 10, 35):
        rb.append({"filler": gname(G), "h_c": h, "independent": crossing(G, h), "lot_6C": crossing(G, h, mu_shift=6.0), "lot_12C": crossing(G, h, mu_shift=12.0)})
tb = pd.DataFrame(rb); tb["d6"] = tb.lot_6C - tb.independent; tb["d12"] = tb.lot_12C - tb.independent
tb.to_csv(os.path.join(OUT, "R3_rom_correlated.csv"), index=False); print(tb.round(3).to_string(index=False))
