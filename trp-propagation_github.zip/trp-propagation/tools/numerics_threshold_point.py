"""Integrator audit at a transition point (Sect. 4.8): foam, eta = 0.8, h_c = 5 (P_esc = 0.48 under v2.1).
Runs the halved coupling step and halved sub-steps on seeds 0-99; the paired baseline is taken from P1b.

    python tools/numerics_threshold_point.py   ->  results_v2/P4c_numerics_mid_v21.jsonl.gz
"""
import os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
import campaign as C

ov = dict(eta_lo=0.8, eta_hi=0.8, G_lo=C.G_CASES["foam_2mm"], G_hi=C.G_CASES["foam_2mm"], h_c=5.0)
pts = [C.point("M=dt0.05", dt=0.05, n_fine=50, n_coarse=5, **ov),
       C.point("M=substep_half", n_fine=200, n_coarse=20, **ov)]
C.run(pts, seeds=range(100), out=os.path.join(ROOT, "results_v2", "P4c_numerics_mid_v21.jsonl.gz"), base="v2.1")
