"""Build Online Resource 1 (electronic supplementary material) from the analysis files. Every table is generated."""
import os, sys, json, math
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
import numpy as np, pandas as pd
import trp_v2 as V, campaign as C
AN = os.path.join(ROOT, "analysis"); RV = os.path.join(AN, "review")
INV = {v: k for k, v in C.G_CASES.items()}
FN = {"air_2mm": "Air gap", "foam_2mm": "Foam", "silicone_2mm": "Silicone", "potting1_2mm": "Potting, $k_f=1$", "potting2.4_2mm": "Potting, $k_f=2.4$"}
def gname(G): return INV[min(INV, key=lambda x: abs(x - G))]
def f3(x): return "--" if x is None or (isinstance(x, float) and not np.isfinite(x)) else f"{x:.3f}"
def eta_cell(v, lo=None, hi=None):
    if v is None or (isinstance(v, float) and math.isinf(v)): return "$>1.5$" if v and v > 0 else ("$<0.5$" if v is not None else "--")
    if lo is None or not np.isfinite(lo): return f"{v:.3f}"
    return f"{v:.3f} ({lo:.3f}--{hi:.3f})"
def table(caption, label, header, rows, spec):
    return ("\\begin{table}[H]\n\\centering\\small\n\\caption{" + caption + "}\\label{" + label + "}\n\\begin{tabular}{" + spec + "}\n\\toprule\n"
            + header + " \\\\\n\\midrule\n" + "\n".join(r + " \\\\" for r in rows) + "\n\\bottomrule\n\\end{tabular}\n\\end{table}\n")
out = []
# ---------------- S1 parameter derivations
r, L = 0.0105, 0.070; D = 2 * r; w = D + 0.002
A_lat = 2 * math.pi * r * L; G_cs = 0.95 * A_lat / (r / 2); C_core = 0.85 * 0.070 * 1100
S = 2 * math.pi * L / math.acosh((2 * w ** 2 - D ** 2) / D ** 2)
E_el = 5.0 * 3600 * 3.63
rows = [f"Lateral area $A_\\mathrm{{lat}}=2\\pi rL$ & {A_lat*1e3:.3f}$\\times10^{{-3}}$ m$^2$",
        f"Core--surface conductance $G_{{cs}}=k_rA_\\mathrm{{lat}}/(r/2)$, $k_r=0.95$ & {G_cs:.3f} W\\,K$^{{-1}}$",
        f"Core heat capacity $f_\\mathrm{{core}}mc_p$ & {C_core:.1f} J\\,K$^{{-1}}$",
        f"Core time constant $f_\\mathrm{{core}}mc_p/G_{{cs}}$ & {C_core/G_cs:.1f} s",
        f"Shape factor $S$ (two cylinders, $D$ = 21 mm, spacing 23 mm, $L$ = 70 mm) & {S:.3f} m",
        f"Stored electrical energy $E_\\mathrm{{el}}$ (5.0 Ah $\\times$ 3.63 V) & {E_el/1e3:.1f} kJ"]
KF = {"air_2mm": 0.026, "foam_2mm": 0.08, "silicone_2mm": 0.2, "potting1_2mm": 1.0, "potting2.4_2mm": 2.4}
rows += [f"Link conductance, {FN[g]}: $k_fS$ with $k_f$ = {KF[g]:g} W\\,m$^{{-1}}$\\,K$^{{-1}}$ & {KF[g]*S:.4f} (used: {G:.3f}) W\\,K$^{{-1}}$" for g, G in C.G_CASES.items()]
rows += [f"Calibration {k}: $\\tau_\\mathrm{{ej}}$, $\\omega$ & {v['tau_ej']:.0f} s, {v['omega']:.4f}" for k, v in V.CALIBRATIONS.items()]
out.append("\\section{Derived model quantities}\n" + table("Quantities derived from the parameters of Table~1 of the article (computed from the engine constants)", "tab:s1", "Quantity & Value", rows, "lr"))
# ---------------- S2 verification tests
tests = [("V1", "Run-by-run reproduction of the earlier (v5) engine: identical trigger maps, cascade spans within 0.05 s, first-step fluxes within $10^{-6}$"),
         ("V2", "Module energy balance in four configurations, including the legacy vent model: relative residual below $5\\times10^{-3}$"),
         ("V3", "Two-node cell with very large $G_{cs}$ agrees with the lumped cell in at least 19 of 20 paired runs"),
         ("V4", "Vent budget: no cell delivers more than its ejected-energy budget (to $10^{-9}$ relative), and no ejecta energy is created"),
         ("V2b", "Production baseline: relative energy residual below $10^{-6}$, no ejecta energy created"),
         ("V9", "Single-cell calibration: total heat within 1\\% of 83.9 kJ and can peak between 540 and 850~\\textdegree C"),
         ("V10", "Directional and redistribution options: relative residual below $10^{-9}$, total delivered heat at most $\\eta$ times the ejected energy"),
         ("V11", "Diagonal links and delayed combustion heat: relative residual below $10^{-9}$, no vent heat on diagonal links, added energy conserved to $10^{-3}$")]
out.append("\\section{Verification tests}\nThe tests are in \\texttt{tests/test\\_v2.py} of the code archive and were run before every campaign.\n"
           + table("Automated verification tests", "tab:s2", "Test & What it checks", [f"{a} & {b}" for a, b in tests], "lp{0.78\\textwidth}"))
# ---------------- S3 Kim benchmark
kb = json.load(open(os.path.join(RV, "kim_benchmark.json")))
rows = [f"{d['reading'].split(':')[0]} & {d['oven_C']} & {d['peak_C']:.1f} & {d['t_peak_min']:.1f} & {d['overshoot_K']:.1f} & {max(d['c_ne_end'],0):.3f}" for d in kb["readings"]]
rows2 = [f"{d['oven_C']} & {d['overshoot_K']:.1f} & {d['t_peak_min']:.1f}" for d in kb["scan"]]
out.append("\\section{Kim et al.\\ oven benchmark}\nLumped 18650 oven test of Kim et al.\\ with their parameters, initial temperature 35~\\textdegree C, $h=7.17$~W\\,m$^{-2}$\\,K$^{-1}$, $\\varepsilon=0.8$ and a 150-min horizon (\\texttt{tools/kim\\_bench.py}). Readings of the SEI-thickness variable: literal, $\\delta(0)=\\delta_\\mathrm{ref}=0.033$; adopted, $\\delta(0)=0.15$, $\\delta_\\mathrm{ref}=0.033$; swapped, $\\delta(0)=0.033$, $\\delta_\\mathrm{ref}=0.15$.\n"
           + table("Oven tests at 150 and 155~\\textdegree C. Kim et al.\\ report no runaway at 150~\\textdegree C and runaway after 50--60~min at 155~\\textdegree C", "tab:s3a",
                   "Reading & Oven (\\textdegree C) & Peak (\\textdegree C) & Time of peak (min) & Overshoot (K) & Final $c_\\mathrm{ne}$", rows, "lrrrrr")
           + table("Scan of the oven temperature with the adopted reading", "tab:s3b", "Oven (\\textdegree C) & Overshoot (K) & Time of peak (min)", rows2, "rrr"))
# ---------------- S4 critical eta at 10 and 50 %
crit = pd.read_csv(os.path.join(AN, "T_critical_eta_v21.csv"))
rows = []
for _, r_ in crit.sort_values(["G", "h_c"]).iterrows():
    rows.append(f"{FN[gname(r_.G)]} & {r_.h_c:g} & {r_.N_per_eta} & {eta_cell(r_.eta10, r_.eta10_lo, r_.eta10_hi)} & {eta_cell(r_.eta50, r_.eta50_lo, r_.eta50_hi)}")
out.append("\\section{Critical captured-ejecta fraction at 10\\% and 50\\% escape}\nCampaign P1, calibration v2.1, seed-block bootstrap 95\\% intervals ($B=2000$). The full map of $P_\\mathrm{esc}$ with Wilson intervals is \\texttt{analysis/T\\_Pesc\\_map\\_v21.csv}.\n"
           + "\\begin{center}\\small\\begin{longtable}{llrll}\\caption{Critical $\\eta$ by filler and cooling coefficient}\\label{tab:s4}\\\\\\toprule\nFiller & $h_c$ & Seeds$^{a}$ & $\\eta^*_{10}$ & $\\eta^*_{50}$ \\\\\\midrule\\endhead\n"
           + "\n".join(r_ + " \\\\" for r_ in rows) + "\n\\bottomrule\\end{longtable}\\end{center}\n$^{a}$Median number of seeds per $\\eta$ value; points with $0.05\\le P_\\mathrm{esc}\\le0.95$ have 200.\n")
# ---------------- S5 first ring
fr = pd.read_csv(os.path.join(RV, "P1b_first_ring_CI.csv"))
rows = [f"{r_.scope.replace('_2mm','').replace('transition, ','transition, ')} & {int(r_.K)} & {int(r_.n)} & {int(r_.escapes)} & {f3(r_.P)} & {f3(r_.ci_lo)}--{f3(r_.ci_hi)}" for _, r_ in fr.iterrows() if r_.n > 0]
LA = json.load(open(os.path.join(RV, "ledger_A.json")))
out.append("\\section{First-ring statistics and escape times}\n"
           + table("Escape against the number $K$ of failed first-ring cells, campaign P1, with exact (Clopper--Pearson) 95\\% intervals", "tab:s5",
                   "Scope & $K$ & Runs & Escapes & $P$ & 95\\% interval", rows, "lrrrrl")
           + f"Escape times (first failure beyond the first ring, P1): median {LA['t_esc_median']:.1f} s, 99th percentile {LA['t_esc_p99']:.1f} s, maximum {LA['t_esc_max']:.1f} s; at near-boundary points ($0<P_\\mathrm{{esc}}\\le0.5$, {LA['t_esc_near_n']} escaping runs) the 95th percentile is {LA['t_esc_near_p95']:.1f} s. One-sided exact 95\\% upper bound for 0 escapes in 40 runs: {LA['cp_upper95_0of40']*100:.1f}\\%; in 200 runs: {LA['cp_upper95_0of200']*100:.1f}\\%.\n")
# ---------------- S6 modelling assumptions (P2)
e = pd.read_csv(os.path.join(AN, "T_epistemic_paired.csv"))
rows = [f"{a.replace('_','\\_')} & {m:+.3f} & {mx:.3f} & {int(u)} & {int(d)} & {int(s)}/{int(n)}" for a, m, mx, u, d, s, n in
        zip(e.assumption, e.mean_dP, e.max_abs_dP, e.more_escape, e.less_escape, e["cells_sig(p<.05)"], e.cells)]
out.append("\\section{Modelling assumptions (campaign P2)}\n" + table("Seed-paired effects of sixteen alternative assumptions against the reference model (calibration v2.0), over 32 grid cells with 40 seeds each", "tab:s6",
           "Assumption & Mean $\\Delta P$ & Max $|\\Delta P|$ & More escapes & Fewer & Cells $p<0.05$", rows, "lrrrrr"))
# ---------------- S7 size and position (P3, P6f)
pf = pd.read_csv(os.path.join(RV, "P6f_paired.csv"))
rows = [f"{c.replace('_',' ').replace('|',', ')} & {int(n)} & {int(u)} & {int(d)} & {p:.3f} & {pr:.3f}" for c, n, u, d, p, pr in zip(pf.config, pf.runs, pf.more_escape, pf.less_escape, pf.P_esc, pf.P_esc_ref)]
c6 = pd.read_csv(os.path.join(RV, "P6f_critical_eta.csv")); c6["filler"] = c6.G.map(gname)
rows2 = [f"{t.replace('_',' ').replace('|',', ')} & {FN[f]} & {h:g} & {eta_cell(v)}" for t, f, h, v in zip(c6.tag, c6.filler, c6.h_c, c6.eta10)]
out.append("\\section{Array size, initiator position and boundary vent condition}\n"
           + table("Campaign P6f (calibration v2.1): pooled escape probability over 32 near-threshold settings, with seed-paired counts against the centre of a $5\\times5$ array", "tab:s7a",
                   "Configuration & Runs & More escapes & Fewer & $P_\\mathrm{esc}$ & Reference", rows, "lrrrrr")
           + "\\begin{center}\\small\\begin{longtable}{lllr}\\caption{Campaign P6f: critical $\\eta^*_{10}$ by configuration}\\label{tab:s7b}\\\\\\toprule\nConfiguration & Filler & $h_c$ & $\\eta^*_{10}$ \\\\\\midrule\\endhead\n"
           + "\n".join(r_ + " \\\\" for r_ in rows2) + "\n\\bottomrule\\end{longtable}\\end{center}\n")
# ---------------- S8 numerics
nm = pd.read_csv(os.path.join(AN, "T_numerics_v21.csv"))
rows = [f"{p.replace('eta', '$\\eta$').replace('h_c', '$h_c$')} & {v.replace('_',' ')} & {int(n)} & {pa:.2f} & {pb:.2f} & {int(a)}/{int(b)} & {dm:.3f} & {dp:.3f}" for p, v, n, pa, pb, a, b, dm, dp in
        zip(nm.point, nm.variant, nm.N, nm.P_A, nm.P_B, nm.A_only, nm.B_only, nm.dt_max_s, nm.dt_p95_s)]
out.append("\\section{Numerical convergence}\n" + table("Seed-paired numerical audits (calibration v2.1): escape probability of the baseline and the variant, outcome flips (lost/gained) and shifts in the time of first-neighbour failure", "tab:s8",
           "Setting & Variant & Runs & $P$ base & $P$ variant & Flips & Max shift (s) & 95th pct.\\ (s)", rows, "llrrrrrr"))
# ---------------- S9 reduced-order model
rom = pd.read_csv(os.path.join(AN, "T_rom_vs_mc_fine.csv")); rom["filler"] = rom.filler.map(lambda x: FN[x])
rows = [f"{f} & {h:g} & {eta_cell(a)} & {eta_cell(b)} & {eta_cell(c)} & {eta_cell(d)}" for f, h, a, b, c, d in zip(rom.filler, rom.h_c, rom.MC_eta10, rom.ROM_eta10, rom.MC_eta50, rom.ROM_eta50)]
rr = json.load(open(os.path.join(RV, "rom_refine.json")))
ref = "; ".join(f"{k.replace('_2mm','').replace('_h',', $h_c$ = ')}: 10\\% {v['grid005']['0.1']:.3f} $\\to$ {v['grid001']['0.1']:.3f}, 50\\% {v['grid005']['0.5']:.3f} $\\to$ {v['grid001']['0.5']:.3f}" for k, v in rr.items())
out.append("\\section{Reduced-order ignition model}\nThe reduced-order runs keep the decomposition chemistry and self-heating of the first-ring cells but prevent their internal short and ejecta (trigger temperature out of reach). Grid refinement from $\\eta$ steps of 0.05 to 0.01: " + ref + ".\n"
           + "\\begin{center}\\small\\begin{longtable}{lrllll}\\caption{Reduced-order model (ROM) against the fine-grid Monte Carlo estimates (MC), calibration v2.1}\\label{tab:s9}\\\\\\toprule\nFiller & $h_c$ & MC $\\eta^*_{10}$ & ROM $\\eta^*_{10}$ & MC $\\eta^*_{50}$ & ROM $\\eta^*_{50}$ \\\\\\midrule\\endhead\n"
           + "\n".join(r_ + " \\\\" for r_ in rows) + "\n\\bottomrule\\end{longtable}\\end{center}\n")
# ---------------- S10 review campaigns P6a-P6e
a = pd.read_csv(os.path.join(RV, "P6a_critical_eta.csv")); a["filler"] = a.G.map(gname)
piv = a.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10")
cols = ["core-matched (14 s)", "baseline (15 s)", "surface-matched (20 s)"]
rows = [f"{FN[f]} & {h:g} & " + " & ".join(eta_cell(piv.loc[(f, h), c]) for c in cols) for (f, h) in piv.index]
b = pd.read_csv(os.path.join(RV, "P6b_fine_vs_coarse.csv"))
rows_b = [f"{FN[r_.filler]} & {r_.h_c:g} & {r_.eta10_coarse:.3f} ({r_.eta10_coarse_CI.replace('-', '--')}) & {r_.eta10_fine:.3f} ({r_.eta10_fine_CI.replace('-', '--')}) & {r_.eta50_coarse:.3f} & {eta_cell(r_.eta50_fine)}" for _, r_ in b.iterrows()]
c = pd.read_csv(os.path.join(RV, "P6c_critical_eta.csv")); c["filler"] = c.G.map(gname)
pc = c.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10")
rows_c = [f"{FN[f]} & {h:g} & " + " & ".join(eta_cell(pc.loc[(f, h), t]) for t in ("baseline", "sd8", "sd16", "wide")) for (f, h) in pc.index]
d = pd.read_csv(os.path.join(RV, "P6d_critical_eta.csv")); d["filler"] = d.G.map(gname)
pdd = d.pivot_table(index=["filler", "h_c"], columns="tag", values="eta10")
rows_d = [f"{FN[f]} & {h:g} & " + " & ".join(eta_cell(pdd.loc[(f, h), t]) if t in pdd.columns and not pd.isna(pdd.loc[(f, h), t]) else "$<0.5$" for t in ("equal", "dir4", "dir1")) for (f, h) in pdd.index]
st = pd.read_csv(os.path.join(RV, "P6d_structure.csv")).set_index("split")
rows_s = [f"{s} & {int(st.loc[s,'transition_points'])} & {int(st.loc[s,'runs'])} & {st.loc[s,'partial_frac_all']:.3f} & {st.loc[s,'full_given_escape']:.3f} & "
          + " & ".join(f3(st.loc[s, f'P(esc|K={k})']) for k in range(5)) for s in ("equal", "dir4", "dir1")]
ee = pd.read_csv(os.path.join(RV, "P6d_eta_eff10.csv")); pe = ee.pivot_table(index=["filler", "h_c"], columns="split", values="eta_eff10")
rows_e = [f"{FN[f]} & {h:g} & {pe.loc[(f,h),'equal']:.3f} & {pe.loc[(f,h),'dir4']:.3f} & {pe.loc[(f,h),'dir1']:.3f}" for (f, h) in pe.index]
out.append("\\section{Robustness campaigns P6a--P6d}\n"
           + table("P6a: $\\eta^*_{10}$ under the three calibrations", "tab:s10a", "Filler & $h_c$ & Core-matched & Baseline & Surface-matched", rows, "lrlll")
           + table("P6b: coarse ($\\eta$ step 0.1, P1) against fine ($\\eta$ step 0.02, 100 seeds) estimates", "tab:s10b", "Filler & $h_c$ & $\\eta^*_{10}$ coarse & $\\eta^*_{10}$ fine & $\\eta^*_{50}$ coarse & $\\eta^*_{50}$ fine", rows_b, "lrllll")
           + table("P6c: $\\eta^*_{10}$ for trigger-temperature distributions with SD 12 (baseline), 8 and 16~\\textdegree C, and bounds widened to 165--260~\\textdegree C", "tab:s10c", "Filler & $h_c$ & Baseline & SD 8 & SD 16 & Wide bounds", rows_c, "lrllll")
           + table("P6d: $\\eta^*_{10}$ for equal and directional splits of captured ejecta (Dirichlet concentration 4 and 1)", "tab:s10d", "Filler & $h_c$ & Equal & $c=4$ & $c=1$", rows_d, "lrlll")
           + table("P6d: structure of propagation at the transition points of each split: fraction of runs with a partial cascade, fraction of escaping runs with full module loss, and $P(\\text{escape}\\mid K)$", "tab:s10e",
                   "Split & Points & Runs & Partial & Full$\\mid$esc & $K=0$ & 1 & 2 & 3 & 4", rows_s, "lrrrrrrrrr")
           + table("P6d: critical $\\eta_\\mathrm{eff}=z\\eta w_\\mathrm{max}$ at the 10\\% level from logistic fits (for strong directionality the logistic extrapolation is unreliable where few runs lie below the boundary)", "tab:s10f",
                   "Filler & $h_c$ & Equal & $c=4$ & $c=1$", rows_e, "lrrrr"))
# ---------------- S11 onward: fine grid, regression, predictions, null models, P7 checks, diagnostics
RVJ = lambda f: json.load(open(os.path.join(RV, f)))
fine = pd.read_csv(os.path.join(AN, "T_critical_eta_fine.csv"))
rows = [f"{FN[gname(r_.G)]} & {r_.h_c:g} & {eta_cell(r_.eta10, r_.eta10_lo, r_.eta10_hi)} & {eta_cell(r_.eta50, r_.eta50_lo, r_.eta50_hi)}" for _, r_ in fine.sort_values(["G", "h_c"]).iterrows()]
D = RVJ("ledger_R2_P7d.json"); F3 = RVJ("ledger_R3_fine.json")
rr = [f"{FN[g]} & {D[f'rule{L}_{g}']['eta0']:.3f} ({D[f'rule{L}_{g}']['eta0_ci'][0]:.3f}--{D[f'rule{L}_{g}']['eta0_ci'][1]:.3f}) & {D[f'rule{L}_{g}']['kappa']:.4f} ({D[f'rule{L}_{g}']['kappa_ci'][0]:.4f}--{D[f'rule{L}_{g}']['kappa_ci'][1]:.4f}) & {D[f'rule{L}_{g}']['R2']:.3f} & {L}\\%" for L in ("10", "50") for g in ("air_2mm", "foam_2mm", "silicone_2mm")]
rw = [f"{FN[g]} & {F3[f'fits_{g}']['OLS'][1]:.4f} & {F3[f'fits_{g}']['WLS'][1]:.4f} & {F3[f'fits_{g}']['censored'][1]:.4f} & {F3[f'fits_{g}']['n_censored']}" for g in ("air_2mm", "foam_2mm", "silicone_2mm")]
out.append("\\section{Fine-grid boundary and design rule}\nCampaign P7d: $\\eta$ step 0.02, 100 seeds per point, seed-block bootstrap ($B=2000$ for the estimates, $B=1000$ for the fits).\n"
    + "\\begin{center}\\small\\begin{longtable}{lrll}\\caption{Critical $\\eta$ on the fine grid}\\label{tab:s11a}\\\\\\toprule\nFiller & $h_c$ & $\\eta^*_{10}$ & $\\eta^*_{50}$ \\\\\\midrule\\endhead\n" + "\n".join(x + " \\\\" for x in rows) + "\n\\bottomrule\\end{longtable}\\end{center}\n"
    + table("Linear rule $\\eta^*_p=\\eta_0+\\kappa h_c$ on the fine grid", "tab:s11b", "Filler & $\\eta_0$ (95\\%) & $\\kappa$ (95\\%) & $R^2$ & $p$ (\\%)", [x.replace("\\\\%", "") for x in rr], "lllrr")
    + table("Slope $\\kappa$ of the 10\\% rule by fitting method: unweighted least squares, weighted by the bootstrap precision of each estimate, and with estimates beyond the grid treated as right-censored at $\\eta=1.45$", "tab:s11c", "Filler & Unweighted & Weighted & Censored & Censored points", rw, "lrrrr"))
LR = RVJ("ledger_R2a.json"); ct = LR["coef_table"]; meta = LR["coef_meta"]
nmz = {"Ttrig_r1_min_z": "lowest first-ring trigger temperature (per 12~\\textdegree C)", "fej_ini_z": "initiator ejecta share (per 0.043)", "fej_r1_mean_z": "mean first-ring ejecta share (per 0.022)"}
rows = [f"{nmz[k]} & {v['logodds']:+.3f} & {v['se_naive']:.3f} & {v['se_cluster']:.3f} & {v['p_cluster']:.2g}" for k, v in ct.items()]
os_ = LR["order_statistics"]; nmo = {"min": "minimum", "second_min": "second-lowest", "mean_two_lowest": "mean of the two lowest", "mean_all_four": "mean of all four"}
rows2 = [f"{nmo[k]} & {v['OR_per_12C']:.2f} ({v['CI'][0]:.2f}--{v['CI'][1]:.2f}) & {v['AIC']:.1f}" for k, v in os_.items()]
out.append("\\section{Logistic regression of escape}\n" + f"Model: escape $\\sim$ point fixed effects ({meta['point_fixed_effects']}) + three scaled features; {meta['runs']:,} runs at {meta['points']} transition points; statsmodels \\texttt{{Logit}} with \\texttt{{cov\\_type='cluster'}} (sandwich estimator with small-sample correction) and {meta['clusters_seeds']} seed clusters; the fit converged and no separation occurred.\n"
    + table("Coefficients (log odds per scale unit) with naive and seed-clustered standard errors", "tab:s12a", "Feature & Log odds & SE naive & SE clustered & $p$ (clustered)", rows, "lrrrr")
    + table("Alternative order statistics of the four first-ring trigger temperatures (each fitted with the initiator ejecta share and point fixed effects; odds ratio per 12~\\textdegree C)", "tab:s12b", "Statistic & Odds ratio (95\\%) & AIC", rows2, "llr"))
lo = pd.read_csv(os.path.join(RV, "R2_loo_slope_ratios.csv"))
rows = [f"{v.replace('_', ' ')} & {FN[f]} & {int(n)} & {r_:.2f} & {a:.2f}--{b_:.2f}" for v, f, n, r_, a, b_ in zip(lo.variant, lo.filler, lo.points, lo.ratio, lo.loo_min, lo.loo_max)]
out.append("\\section{Prediction test: sensitivity to single estimates}\n" + table("Slope ratios of Table~6 of the article and their range when each estimate is left out in turn", "tab:s13", "Variant & Filler & Estimates & Ratio & Leave-one-out range", rows, "llrrl"))
ic = pd.read_csv(os.path.join(RV, "R2_independent_cascade.csv")); pc = pd.read_csv(os.path.join(AN, "T_percolation_v21.csv"))
rows = [f"{p_.split('|')[0][2:].replace('_2mm','')}, $\\eta$ = {p_.split('|')[1][4:]}, $h_c$ = {p_.split('|')[2][2:]} & {r_.P_esc:.3f} & {r_.obs_partial:.3f} & {pp:.3f} & {r_.ic_partial:.3f} & {r_.obs_full_given_esc:.3f} & {r_.ic_full_given_esc:.3f}" for p_, r_, pp in zip(ic.point, ic.itertuples(), pc.perc_partial_frac)]
out.append("\\section{Null models of independent spreading}\nBond percolation: one link probability, matched to the mean number of first-ring failures. Independent cascade: the number of failed first-ring cells drawn from its simulated distribution, then one link probability for later links, matched to the simulated escape probability (8000 simulated cascades per point).\n"
    + "\\begin{center}\\footnotesize\\begin{longtable}{lrrrrrr}\\caption{Partial cascades and full module loss at 20 transition points: simulated (MC), bond percolation (BP) and independent cascade (IC)}\\label{tab:s14}\\\\\\toprule\nPoint & $P_\\mathrm{esc}$ & Partial MC & Partial BP & Partial IC & Full$\\mid$esc MC & Full$\\mid$esc IC \\\\\\midrule\\endhead\n" + "\n".join(x + " \\\\" for x in rows) + "\n\\bottomrule\\end{longtable}\\end{center}\n")
A7, B7, C7 = RVJ("ledger_R2_P7a.json"), RVJ("ledger_R2_P7b.json"), RVJ("ledger_R2_P7c.json")
ra = [f"{FN[r_['filler']]} & {r_['h_c']:g} & {eta_cell(r_['instantaneous'])} & {eta_cell(r_['comb30'])} & {eta_cell(r_['comb120'])}" for r_ in A7["eta10"]]
rc = [f"{FN[r_['filler']]} & {r_['h_c']:g} & {eta_cell(r_['face'])} & {eta_cell(r_['diagonal'])}" for r_ in C7["eta10"]]
out.append("\\section{Checks P7a--P7c}\n" + f"P7b: {B7['points_extended']} near-boundary points extended from 40 to 200 seeds; highest escape probability {B7['max_P200']:.3f}; $\\eta^*_{{10}}$ changed by at most {B7['d_eta10'][1]:.4f}; {B7['duplicates_identical']} of {B7['duplicates']} runs repeated weeks apart on the same machine gave identical outcomes. "
    + f"P7a (paired runs at $\\eta>1$): 30 s lag {A7['comb30']['less_escape']} fewer and {A7['comb30']['more_escape']} more escapes in {A7['comb30']['paired_runs_eta_gt1']:,} runs; 120 s lag {A7['comb120']['less_escape']} fewer and {A7['comb120']['more_escape']} more in {A7['comb120']['paired_runs_eta_gt1']:,}. "
    + f"P7c: {C7['escapes']:,} escapes, none without a first-ring failure; {C7['less_escape']} fewer and {C7['more_escape']} more escapes than with face links only in {C7['paired_n']:,} paired runs.\n"
    + table("P7a: $\\eta^*_{10}$ with the excess heat for $\\eta>1$ released with the ejecta (instantaneous) or through a 30 s or 120 s lag (map grid)", "tab:s15a", "Filler & $h_c$ & Instantaneous & 30 s & 120 s", ra, "lrlll")
    + table("P7c: $\\eta^*_{10}$ with face links only and with conduction-only diagonal links (map grid)", "tab:s15b", "Filler & $h_c$ & Face & Diagonal", rc, "lrll"))
H = RVJ("ledger_R2_hist.json"); HZ = RVJ("ledger_R2_horizon.json"); DS = LR["dirichlet"]; RF = RVJ("rom_refine.json")
rows = [f"{FN[k.split('_')[0]+'_2mm']}, $h_c$ = {float(k.split('_')[2]):g}, $\\eta$ = {k.split('_')[3]} & {v['runs_no_first_ring_failure']} ({v['neighbour_samples']}) & {v['mc_peak_median']:.1f} & {v['rom_median']:.1f} & {v['mc_minus_rom_mean']:+.1f} $\\pm$ {v['mc_minus_rom_sd']:.1f} & {v['runs_with_failure']} & {v['sink_can_rise_mean']:.1f}" for k, v in H.items()]
out.append("\\section{Diagnostics}\n"
    + table("Full-model histories at three near-boundary settings (40 seeds each). Left: runs without a first-ring failure (neighbour samples), median peak core temperature of first-ring neighbours in the full model and in the reduced-order model, and their difference (mean $\\pm$ SD, K). Right: runs with a failure, and the mean rise of the can temperature of the other three neighbours of the first neighbour to fail, at its failure (K)", "tab:s16a",
            "Setting & Runs & Full (\\textdegree C) & Reduced (\\textdegree C) & Difference & Runs & Sink rise", rows, "lrrrrrr")
    + f"Dirichlet split: largest share mean {DS['c4']['wmax_mean']:.3f} (95th percentile {DS['c4']['wmax_p95']:.3f}), two largest {DS['c4']['top2_mean']:.3f} ({DS['c4']['top2_p95']:.3f}) for $c=4$; {DS['c1']['wmax_mean']:.3f} ({DS['c1']['wmax_p95']:.3f}) and {DS['c1']['top2_mean']:.3f} ({DS['c1']['top2_p95']:.3f}) for $c=1$. "
    + f"Long-horizon reruns: the {HZ['runs']} slow directional runs (failures after 1500 s) repeated to 5400 s; escape unchanged in {HZ['escape_same']}; complete at 1800 s {HZ['complete_1800']}, at 5400 s {HZ['complete_5400']}; last failure at {HZ['max_last_fail_s']:.0f} s.\n")
# ---------------- third set: residuals, regression, definitions, predictions, P8, reduced-model brackets
rs = pd.read_csv(os.path.join(RV, "R3_rule_residuals.csv"))
rows = [f"{FN[r_.filler]} & {r_.h_c:g} & {r_.eta10:.3f} & {r_.rule:.3f} & {r_.resid:+.3f}" for r_ in rs.itertuples()]
out.append("\\section{Residuals of the design rule}\n" + table("Fine-grid $\\eta^*_{10}$, linear rule and residual by setting; the residuals are negative at both ends of the range and positive in the middle", "tab:s20", "Filler & $h_c$ & $\\eta^*_{10}$ & Rule & Residual", rows, "lrrrr"))
L3 = RVJ("ledger_R3b.json"); rv = L3["regression_vent"]; pk = L3["PescK_bootstrap"]; comp = pd.DataFrame(L3["transition_composition"])
rows = [f"{FN[r_.filler]} & {r_.h_c:g} & {int(r_.points)}" for r_ in comp.itertuples()]
rows2 = [f"{k} & {v['n']} & {v['P']:.3f} & {v['ci'][0]:.3f}--{v['ci'][1]:.3f} & {v['per_point_median']:.2f}" for k, v in pk.items()]
out.append("\\section{Transition points, first-ring statistics and a mechanistic regressor}\n"
    + table("Composition of the 33 transition points ($0.05\\le P_\\mathrm{esc}\\le0.95$, 200 seeds)", "tab:s21a", "Filler & $h_c$ & Points", rows, "lrr")
    + table("Escape against the number $K$ of failed first-ring cells at the transition points, with seed-block bootstrap 95\\% intervals ($B=2000$) and the median over points", "tab:s21b", "$K$ & Runs & $P$ & 95\\% interval & Median over points", rows2, "rrrlr")
    + f"Replacing the initiator's ejecta share by its ejected energy, recomputed for each seed from the same random draws (mean 69.5 kJ, standard deviation {rv['ej_scale_kJ']:.1f} kJ; correlation with the ejecta share {rv['corr_fej_ej']:.2f}), gives an odds ratio of {rv['delivered_vent']['OR']:.1f} ({rv['delivered_vent']['CI'][0]:.1f}--{rv['delivered_vent']['CI'][1]:.1f}) per standard deviation and {rv['delivered_vent']['OR_Tmin']:.2f} per 12~\\textdegree C of the lowest first-ring trigger temperature (AIC {rv['delivered_vent']['AIC']:.0f}), against {rv['fej']['OR']:.2f} and {rv['fej']['OR_Tmin']:.2f} with the ejecta share (AIC {rv['fej']['AIC']:.0f}). Closed-form parameters (10\\% level, mean trigger temperature): bootstrap correlations $C_\\mathrm{{eff}}$--$\\tau_h$ {L3['closed_corr']['C_tauh']:.2f}, $C_\\mathrm{{eff}}$--$\\tau_G$ {L3['closed_corr']['C_tauG']:.2f}, $\\tau_h$--$\\tau_G$ {L3['closed_corr']['tauh_tauG']:.2f}.\n")
defs = [("ejection lag 5 s / 20 s", "$\\tau_\\mathrm{ej}=5$ or 20 s instead of 10 s"), ("core fraction 0.70 / 0.95", "$f_\\mathrm{core}=0.70$ or 0.95 instead of 0.85"),
        ("radial conductivity 0.40 / 1.50", "$k_r=0.40$ or 1.50 W\\,m$^{-1}$\\,K$^{-1}$ instead of 0.95, changing $G_{cs}$"), ("short duration 5 s / 20 s", "$\\tau_\\mathrm{isc}=5$ or 20 s instead of 10 s, same energy"),
        ("internal short by heating rate", "short starts when chemical self-heating exceeds 20 \\textdegree C\\,min$^{-1}$ instead of at $T_\\mathrm{trig}$"),
        ("trigger prior 190 / 230 \\textdegree C", "$T_\\mathrm{trig}\\sim\\mathcal{N}(190,12^2)$ on 160--225 \\textdegree C, or $\\mathcal{N}(230,12^2)$ on 200--265 \\textdegree C"),
        ("30\\% of ejecta heat into core", "$\\beta=0.3$ instead of 0"), ("trigger on can temperature", "failure flagged when the can, not the core, reaches $T_\\mathrm{trig}$ (inconsistent; sanity check)"),
        ("lumped cell", "single thermal node per cell, with $\\tau_\\mathrm{ej}=5$ s"), ("instant ejecta removal", "the ejecta share leaves at once as it is generated, without the reservoir lag"),
        ("radiation off", "no radiation between cans")]
out.append("\\section{Definitions of the alternative assumptions (campaign P2)}\n" + table("Alternatives compared with the reference model (calibration v2.0, $\\tau_\\mathrm{ej}=10$ s, $\\omega=0.875$); each changes only what is listed", "tab:s22", "Alternative & Change", [f"{a} & {b}" for a, b in defs], "lp{0.62\\textwidth}"))
sv = pd.read_csv(os.path.join(RV, "R3_surface_slopes.csv")); sv = sv[sv.variant != "baseline"]
rows = [f"{r_.variant.replace('_', ' ')} & {FN[r_.filler]} & {r_.surface_ratio:.2f} & " + (f"{r_.ratio:.2f}" if np.isfinite(r_.ratio) else "--") + " & " + (f"{r_.predicted:.2f}" if np.isfinite(r_.predicted) else "--") for r_ in sv.itertuples()]
pred_txt = ("Prediction record, notebook 06, cell headed `Pre-registered predictions (22 Oct 2026)', verbatim: "
            "baseline, $\\tau$ 93.3 s, ratio 1.00, slope 0.0090 (reference; P1 measured 0.0089); "
            "k\\_r=0.40, 201.0 s, 2.15, 0.0194, `slower can-to-core path: longer exposure, steeper boundary'; "
            "k\\_r=1.50, 64.6 s, 0.69, 0.0062, `faster can-to-core path: shallower boundary'; "
            "tau\\_ej=20, 103.3 s, 1.11, 0.0100, `small: ejection lag is a minor part of tau'; "
            "lumped, 10.0 s, 0.11, 0.0010, `no can-to-core resistance: boundary nearly flat in h\\_c'; "
            "beta=0.3, no quantitative prediction, `part of vent heat bypasses the can (expect lower eta0)'; "
            "Ttrig=N(190,12), ratio 0.892, slope 0.0080, `intercept and slope both scale by (190-25)/(210-25) = 0.892'. "
            "The slopes refer to the v2.0 phase diagram of that time.\n")
out.append("\\section{Prediction test: record and a whole-surface slope estimator}\n" + pred_txt
    + table("Slope ratios from the whole escape surface (probit model in $\\eta$ and $h_c$, $h_c\\le75$) against the crossing-based ratios of Table~6 of the article and the predictions", "tab:s23", "Variant & Filler & Surface & Crossings & Predicted", rows, "llrrr"))
R8a, R8b, LO = RVJ("ledger_R3_radiation.json"), RVJ("ledger_R3_numerics.json"), pd.read_csv(os.path.join(RV, "R3_loweta_critical.csv"))
ra = [f"{FN[r_['filler']]} & {r_['h_c']:g} & {r_['eta10_esc_base']:.3f} & {r_['eta10_esc_rad']:.3f} & {r_['eta50_esc_base']:.3f} & {r_['eta50_esc_rad']:.3f}" for r_ in R8a["table"]]
SETN = {"G=potting1_2mm|eta=1.5|h=2": "potting $k_f=1$, $\\eta=1.5$, $h_c=2$", "G=air_2mm|eta=1.35|h=75": "air gap, $\\eta=1.35$, $h_c=75$",
        "V=dir1|G=air_2mm|eta=0.5|h=2": "air gap, strong split, $\\eta=0.5$, $h_c=2$"}
rb = [f"{'step 0.05 s' if k.startswith('dt0.05') else 'sub-steps halved'} & {SETN[k.split('|',1)[1]]} & {v['runs']} & {v['gained']+v['lost']} & {v['cascade_size_changed']} & {v['dt_max']:.2f}" for k, v in R8b.items()]
rl = [f"{'strong' if r_.tag == 'dir1' else 'mild'} & {FN[r_.filler]} & {r_.h_c:g} & {r_.eta10:.3f} ({r_.eta10_lo:.3f}--{r_.eta10_hi:.3f}) & {r_.eta50:.3f}" for r_ in LO.itertuples()]
out.append("\\section{Checks P8a--P8c}\n"
    + table(f"P8a: radiation at the geometric view factor $F_\\mathrm{{rad}}=0.16$ against the assumed 0.06 (same 40 seeds and $\\eta$ values); {R8a['less_escape']} fewer and {R8a['more_escape']} more escapes in {R8a['runs']} paired runs", "tab:s24a", "Filler & $h_c$ & $\\eta^*_{10}$, 0.06 & $\\eta^*_{10}$, 0.16 & $\\eta^*_{50}$, 0.06 & $\\eta^*_{50}$, 0.16", ra, "lrrrrr")
    + table("P8b: halved coupling step and halved sub-steps at three demanding settings, seed-paired with the original runs", "tab:s24b", "Variant & Setting & Runs & Flips & Size changes & Max shift (s)", rb, "llrrrr")
    + table("P8c: directional split extended below $\\eta=0.5$ (40 seeds), critical $\\eta$ with seed-block intervals", "tab:s24c", "Split & Filler & $h_c$ & $\\eta^*_{10}$ & $\\eta^*_{50}$", rl, "llrlr"))
rd = pd.read_csv(os.path.join(RV, "R3_rom_directional.csv")); bc = pd.read_csv(os.path.join(RV, "R3_rom_beta_crit.csv")); cc = pd.read_csv(os.path.join(RV, "R3_rom_correlated.csv"))
r1 = [f"{FN[r_.filler]} & {r_.h_c:g} & {eta_cell(r_.ROM_equal)} & {eta_cell(r_.MC_equal)} & {eta_cell(r_.ROM_c4)} & {eta_cell(r_.MC_c4)} & {eta_cell(r_.ROM_c1)} & {eta_cell(r_.MC_c1)}" for r_ in rd.itertuples()]
r2 = [f"{FN[r_.filler]} & {r_.h_c:g} & {eta_cell(r_.beta0)} & {eta_cell(getattr(r_, 'beta0_15'))} & {eta_cell(getattr(r_, 'beta0_3'))}" for r_ in bc.rename(columns={'beta0.15': 'beta0_15', 'beta0.3': 'beta0_3'}).itertuples()]
r3 = [f"{FN[r_.filler]} & {r_.h_c:g} & {r_.independent:.2f} & {r_.lot_6C:.2f} & {r_.lot_12C:.2f}" for r_ in cc.itertuples()]
out.append("\\section{Reduced-order model: directional splits, bypass of the can and correlated inputs}\n"
    + "The initiator's ejecta share is averaged over a 16-point grid on 0.75--0.90. For directional splits each neighbour receives its own share (3000 Dirichlet draws) and $P(K\\ge2)$ is evaluated with unequal probabilities; the Monte Carlo values for $c=1$ at or below the map grid are from campaign P8c.\n"
    + table("$\\eta^*_{10}$ for equal and directional splits: reduced-order model (ROM) and Monte Carlo (MC, map grid)", "tab:s25a", "Filler & $h_c$ & ROM equal & MC equal & ROM $c=4$ & MC $c=4$ & ROM $c=1$ & MC $c=1$", r1, "lrrrrrrr")
    + table("Reduced-order $\\eta^*_{10}$ with a fraction $\\beta$ of the captured vent heat deposited directly in the core", "tab:s25b", "Filler & $h_c$ & $\\beta=0$ & $\\beta=0.15$ & $\\beta=0.3$", r2, "lrrrr")
    + table("Reduced-order $\\eta^*_{10}$ with the neighbours' trigger mean lowered by up to 6 or 12~\\textdegree C when the initiator's ejecta share is at the top of its range (comonotone bracket)", "tab:s25c", "Filler & $h_c$ & Independent & 6~\\textdegree C & 12~\\textdegree C", r3, "lrrrr"))
TM = RVJ("R3_singlecell_timing.json"); PE = RVJ("R3_potting_edge.json")
out.append("\\section{Further details}\n" + f"Single cell (calibration v2.1, Fig.~2 of the article): core peak {TM['Tc_max']:.0f}~\\textdegree C at {TM['t_peak_core']:.0f} s, can peak {TM['Ts_max']:.0f}~\\textdegree C at {TM['t_peak_can']:.0f} s; core above 500~\\textdegree C for {TM['core_above_500']:.0f} s and can for {TM['can_above_500']:.0f} s. "
    + f"Table~4 of the article, potting with $k_f=1$ at $h_c=2$: $\\eta^*_{{10}}={PE['eta10']:.2f}$; in {PE['frac_beyond']*100:.0f}\\% of bootstrap replicates the crossing lies beyond $\\eta=1.5$, and the 2.5th percentile is {PE['lo']:.2f}.\n")
json.dump({"generated": True}, open(os.path.join(HERE, "output", "esm_flag.json"), "w")) if os.path.isdir(os.path.join(HERE, "output")) else None
TITLE = "Probabilistic Containment of Thermal-Runaway Propagation in 21700 Modules: An Energy-Consistent Model, a Design Rule and Tested Predictions"
doc = ("\\documentclass[11pt]{article}\n\\usepackage[a4paper,margin=2.2cm]{geometry}\n\\usepackage{booktabs,longtable,amsmath,amssymb,textcomp,float}\n\\usepackage[hidelinks]{hyperref}\n"
       "\\renewcommand{\\thetable}{S\\arabic{table}}\\renewcommand{\\thesection}{S\\arabic{section}}\n"
       "\\title{Online Resource 1\\\\[4pt]\\large " + TITLE + "}\\date{}\n\\begin{document}\n\\maketitle\n"
       "\\noindent This supplement contains derived model quantities, the verification tests, the Kim et al.\\ benchmark, full tables of the critical captured-ejecta fraction, first-ring statistics, the modelling-assumption, size, numerics and reduced-order campaigns, and the review campaigns. All tables are generated by \\texttt{manuscript\\_figures/mkesm.py} from the files in \\texttt{analysis/} of the code archive. Section, table and equation numbers without the prefix S refer to the article.\n\n"
       + "\n".join(out) + "\n\\end{document}\n")
os.makedirs(os.path.join(HERE, "output"), exist_ok=True)
open(os.path.join(HERE, "output", "OnlineResource1.tex"), "w").write(doc)
print("written", len(doc), "chars")
