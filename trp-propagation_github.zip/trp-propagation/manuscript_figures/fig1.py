import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
from figstyle import *; setup()
import numpy as np
from matplotlib.patches import Circle, FancyArrowPatch
fig, axs = plt.subplots(1, 2, figsize=(174*MM, 76*MM), gridspec_kw={'width_ratios':[1,1.25]})
# (a) module top view
ax = axs[0]; ax.set_aspect('equal'); ax.axis('off')
pitch, r = 23.0, 10.5
for i in range(5):
    for j in range(5):
        x, y = (j-2)*pitch, (2-i)*pitch
        ring = abs(i-2)+abs(j-2)
        fc, hatch = (OI['vermillion'], '////') if ring == 0 else ((OI['orange'], None) if ring == 1 else ('#E8E8E8', None))
        ax.add_patch(Circle((x,y), r, fc=fc, ec='k', lw=0.5, hatch=hatch))
        if j < 4: ax.plot([x+r, x+pitch-r], [y, y], color=OI['grey'], lw=1.8, solid_capstyle='butt')
        if i < 4: ax.plot([x, x], [y-r, y-pitch+r], color=OI['grey'], lw=1.8, solid_capstyle='butt')
for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
    ax.add_patch(FancyArrowPatch((dx*5, dy*5), (dx*(pitch-4), dy*(pitch-4)), arrowstyle='-|>', mutation_scale=7, lw=1.1, color='k'))
# a failed first-ring cell becomes a donor in turn (shown for the upper first-ring cell)
for dx, dy in ((0, 1), (-1, 0), (1, 0)):
    x0, y0 = 0, pitch
    ax.add_patch(FancyArrowPatch((x0 + dx*5, y0 + dy*5), (x0 + dx*(pitch-4), y0 + dy*(pitch-4)), arrowstyle='-|>', mutation_scale=6, lw=0.9, color='#555555', linestyle='--'))
ax.text(0, -2.75*pitch, 'every failed cell sends $\\eta\\,\\dot Q_{ej}$ to its face neighbours\n(solid: initiator; dashed: a failed first-ring cell)', ha='center', va='top', fontsize=6.6)
ax.set_xlim(-2.6*pitch, 2.85*pitch); ax.set_ylim(-3.35*pitch, 2.6*pitch)
panel(ax, 'a', x=-0.02, y=0.98)
# (b) two-node cell cross-section (schematic, not to scale)
ax = axs[1]; ax.set_aspect('equal'); ax.axis('off')
ax.add_patch(Circle((0,0), 10.5, fc='#CFCFCF', ec='k', lw=0.8))
ax.add_patch(Circle((0,0), 7.2, fc=OI['yellow'], ec='k', lw=0.6))
ax.text(0, 1.6, 'core', ha='center', va='center', fontsize=8, fontweight='bold')
ax.text(0, -1.2, '$T_c$', ha='center', va='center', fontsize=8)
ax.text(0, -9.0, 'can, $T_s$', ha='center', va='center', fontsize=7)
ax.add_patch(FancyArrowPatch((5.0, 5.0), (7.9, 7.9), arrowstyle='<|-|>', mutation_scale=6, lw=0.8))
ax.text(8.6, 8.4, '$G_{cs}$', fontsize=7.5)
ax.add_patch(FancyArrowPatch((10.6, -2), (17, -2), arrowstyle='-|>', mutation_scale=7, lw=1.0, color=OI['blue']))
ax.text(17.4, -2, 'cooling\n$h_c A_s (T_s - T_{amb})$', fontsize=7, va='center', color=OI['blue'])
ax.add_patch(FancyArrowPatch((-17, 2.5), (-10.4, 2.5), arrowstyle='-|>', mutation_scale=7, lw=1.0, color='#4D4D4D'))
ax.text(-17.4, 2.5, 'from neighbours, onto the can:\nconduction $G$, radiation,\n$(1-\\beta)$ of captured ejecta', fontsize=6.6, va='center', ha='right')
ax.add_patch(FancyArrowPatch((-17, -5.0), (-2.5, -5.0), arrowstyle='-|>', mutation_scale=7, lw=1.0, color=OI['orange'], linestyle='--'))
ax.text(-17.4, -5.0, 'into the core:\n$\\beta$ of captured ejecta', fontsize=6.6, va='center', ha='right', color='#A06000')
ax.add_patch(FancyArrowPatch((0, 7.4), (0, 16.5), arrowstyle='-|>', mutation_scale=8, lw=1.3, color=OI['vermillion']))
ax.text(1.2, 14.0, 'ejecta: share $f_{ej}$,\nlag $\\tau_{ej}$', fontsize=7, va='center', color=OI['vermillion'])
ax.text(-1.3, 14.0, 'reactions +\ninternal short', fontsize=7, va='center', ha='right')
ax.set_xlim(-31, 33); ax.set_ylim(-12.5, 18)
panel(ax, 'b', x=-0.02, y=0.98)
plt.tight_layout(w_pad=0.5); save(fig, 'Fig1')
