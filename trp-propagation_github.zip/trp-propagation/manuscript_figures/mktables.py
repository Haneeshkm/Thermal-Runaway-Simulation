"""Generate the result tables of the manuscript from the analysis files (no hand-typed numbers)."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
import numpy as np, pandas as pd, campaign as C
P = os.path.join(ROOT, 'analysis') + '/'; RV = os.path.join(ROOT, 'analysis', 'review') + '/'
out = []
J = lambda f: json.load(open(RV + f))
# ---------------- Table: campaigns
camp = [("P1", "Containment maps: $\\eta$ 0.5--1.5 $\\times$ $h_c$ 2--200 $\\times$ five fillers", "v2.1", 25600, "\\ref{sec:maps}--\\ref{sec:romres}"),
        ("P2", "Sixteen alternative modelling assumptions, paired with a reference", "v2.0", 21760, "\\ref{sec:design}"),
        ("P3", "Array size and initiator position", "v2.0", 4800, "\\ref{sec:robust}"),
        ("P4", "Numerical convergence (time step, sub-steps, horizon, radiation)", "v2.1", 1200, "\\ref{sec:robust}"),
        ("P5", "Test of predictions recorded before the campaign", "v2.0", 26880, "\\ref{sec:p5}"),
        ("P6a", "Calibration envelope: core- and surface-matched calibrations", "v2.1-core, v2.1-surf", 20760, "\\ref{sec:calib_robust}"),
        ("P6b", "$\\eta$ grid of step 0.02 at four settings (superseded by P7d)", "v2.1", 5200, "--"),
        ("P6c", "Spread and bounds of the trigger-temperature distribution", "v2.1", 4320, "\\ref{sec:calib_robust}"),
        ("P6d", "Directional split of captured ejecta", "v2.1", 9760, "\\ref{sec:directional}"),
        ("P6e", "Lumped-cell controls", "v2.0", 7680, "\\ref{sec:p5}"),
        ("P6f", "Array size and position near threshold; missing-neighbour vent share", "v2.1", 10240, "\\ref{sec:robust}, \\ref{sec:directional}"),
        ("P7a", "Delayed release of combustion heat for $\\eta>1$", "v2.1", 4140, "\\ref{sec:calib_robust}"),
        ("P7b", "Extension of near-boundary points to 200 seeds", "v2.1", 4480, "\\ref{sec:calib_robust}"),
        ("P7c", "Conduction-only diagonal links", "v2.1", 4440, "\\ref{sec:ring}"),
        ("P7d", "$\\eta$ grid of step 0.02 at all design-rule settings", "v2.1", 19000, "\\ref{sec:maps}, \\ref{sec:rule}"),
        ("P8a", "Radiation at the geometric view factor ($F_\\mathrm{rad}=0.16$)", "v2.1", 760, "\\ref{sec:robust}"),
        ("P8b", "Halved coupling step and sub-steps at three demanding settings", "v2.1", 360, "\\ref{sec:robust}"),
        ("P8c", "Strongly directional split below $\\eta=0.5$", "v2.1", 680, "\\ref{sec:directional}")]
tot = sum(c[3] for c in camp)
rows = [f"{a} & {b} & {c} & {d:,} & {e}" + r" \\" for a, b, c, d, e in camp]
out.append(r"""\begin{table}[t]
\caption{Simulation campaigns. Calibration v2.1 ($\tau_\mathrm{ej}=15$ s) is used for all primary results; the reference calibration v2.0 ($\tau_\mathrm{ej}=10$ s) for campaigns that compare model variants on the same seeds (Sect.~\ref{sec:calibration}). Total """ + f"{tot:,}" + r""" runs}\label{tab:campaigns}
\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}l>{\raggedright\arraybackslash}p{0.50\textwidth}>{\raggedright\arraybackslash}p{0.16\textwidth}rl@{}}
\toprule
ID & Purpose & Calibration & Runs & Sect.\\
\midrule
""" + "\n".join(rows) + r"""
\botrule
\end{tabular}
\end{table}""")
# ---------------- Table: critical eta (fine grid where available)
crit = pd.read_csv(P + 'T_critical_eta_v21.csv'); fine = pd.read_csv(P + 'T_critical_eta_fine.csv')
order = ['air_2mm', 'foam_2mm', 'silicone_2mm', 'potting1_2mm', 'potting2.4_2mm']
def cell(G, h):
    f = fine[np.isclose(fine.G, G) & np.isclose(fine.h_c, h)]
    if len(f):
        r = f.iloc[0]; return f"{r.eta10:.2f} ({r.eta10_lo:.2f}--{r.eta10_hi:.2f})"
    r = crit[np.isclose(crit.G, G) & np.isclose(crit.h_c, h)].iloc[0]; v = r.eta10
    if np.isinf(v): return '$>1.5$' if v > 0 else '$<0.5$'
    ed = J('R3_potting_edge.json')
    return f"{v:.2f} ({ed['lo']:.2f}--$\\ge$1.5)$^{{a}}$"
rows = []
for h in (2, 5, 10, 20, 35, 50, 75, 100):
    rows.append(f"{h:g} & " + " & ".join(cell(C.G_CASES[g], h) for g in order) + r" \\")
out.append(r"""\begin{table}[t]
\caption{Critical captured-ejecta fraction $\eta^*_{10}$ at which the probability of escape from the first ring reaches 10\%, with seed-block bootstrap 95\% intervals; $5\times5$ array, centre initiator, calibration v2.1. Estimates come from the $\eta$ grid of step 0.02 with 100 seeds per point (campaign P7d) wherever the crossing lies inside the grid, otherwise from the map of Fig.~\ref{fig:maps} (campaign P1)}\label{tab:crit}
\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}lccccc@{}}
\toprule
$h_c$ & Air gap & Foam & Silicone & Potting, $k_f=1$ & Potting, $k_f=2.4$\\
(W\,m$^{-2}$\,K$^{-1}$) & $G=0.013$ & $G=0.041$ & $G=0.102$ & $G=0.508$ & $G=1.219$ W\,K$^{-1}$\\
\midrule
""" + "\n".join(rows) + r"""
\botrule
\end{tabular}
\footnotetext[a]{Map estimate at the edge of the $\eta$ grid: in 36\% of bootstrap replicates the crossing lies beyond $\eta=1.5$, so the upper limit is at least 1.5.}
\end{table}""")
# ---------------- Table: closed form (fine grid, seed-block bootstrap)
L = J('ledger_R3_fine.json'); rows = []
for lev in ('10', '50'):
    for mode in ('mean', 'quantile'):
        q = L[f'closed{lev}_{mode}']; Tt = '210 (mean)' if mode == 'mean' else f"{L[f'Tq{lev}']:.1f} (quantile)"
        rows.append(f"{lev}\\% & {Tt} & {q['n']} & {q['C_eff']:.1f} ({q['ci_lo'][0]:.1f}--{q['ci_hi'][0]:.1f}) & {q['tau_h']:.0f} ({q['ci_lo'][1]:.0f}--{q['ci_hi'][1]:.0f}) & "
                    f"{q['tau_G']:.0f} ({q['ci_lo'][2]:.0f}--{q['ci_hi'][2]:.0f}) & {q['R2']:.3f} & {q['MAE_LOO']:.3f} ({q['max_LOO']:.3f}) & {q['MAE_LOFO']:.3f} ({q['max_LOFO']:.3f})" + r" \\")
out.append(r"""\begin{table}[t]
\caption{Closed-form ignition criterion, Eq.~(\ref{eq:closed}), fitted to the fine-grid critical $\eta$ of the three insulating fillers. $T_\mathrm{trig}$ is taken as the prior mean or as the effective quantile at which at least two of four neighbours fail with the stated probability; it enters only as a scale factor, so both choices fit equally well. Parameters with seed-block bootstrap 95\% intervals ($B=1000$); prediction errors in $\eta$ as mean (maximum) absolute error for leave-one-out (LOO) and leave-one-filler-out (LOFO) refits}\label{tab:closed}
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\begin{tabular}{@{}llcccccll@{}}
\toprule
Level & $T_\mathrm{trig}$ (\textdegree C) & $n$ & $C_\mathrm{eff}$ (J\,K$^{-1}$) & $\tau_h$ (s) & $\tau_G$ (s) & $R^2$ & LOO & LOFO\\
\midrule
""" + "\n".join(rows) + r"""
\botrule
\end{tabular}
\end{table}""")
# ---------------- Table 5: slope ratios with seed-block bootstrap, consistent rule
t=pd.read_csv(os.path.join(RV,'P5_slope_ratios_bootstrap.csv')); e6=pd.read_csv(os.path.join(RV,'P6e_slope_ratios_bootstrap.csv'))
nm={'k_r=0.40':r'Radial conductivity $k_r=0.40$','k_r=1.50':r'Radial conductivity $k_r=1.50$','tau_ej=20':r'Ejection lag $\tau_\mathrm{ej}=20$ s',
    'Ttrig=N(190,12)':r'Trigger prior $\mathcal{N}(190,12^2)$ \textdegree C','lumped':r'Lumped cell ($\tau_\mathrm{ej}=5$ s)',
    'beta=0.3':r'30\% of vent heat into the core ($\beta=0.3$)','lumped_tau10':r'Lumped cell ($\tau_\mathrm{ej}=10$ s)$^{b}$','twonode_tau5':r'Two-node cell ($\tau_\mathrm{ej}=5$ s)$^{b}$'}
tau={'k_r=0.40':'201','k_r=1.50':'65','tau_ej=20':'103','Ttrig=N(190,12)':'--','lumped':'10','beta=0.3':'--','lumped_tau10':'15','twonode_tau5':'88'}
def cellr(d,g):
    r=d[d.filler==g]
    if r.empty: return r'--$^{a}$'
    r=r.iloc[0]; return f"{r.ratio:.2f} ({r.ratio_lo:.2f}--{r.ratio_hi:.2f})"
rows=[]
for f in ['k_r=0.40','k_r=1.50','tau_ej=20','Ttrig=N(190,12)','lumped','beta=0.3']:
    d=t[t.variant==f]; pr=d.predicted.iloc[0]
    if pd.isna(pr): outc='no prediction'; prs='--'
    else:
        prs=f"{pr:.2f}"; outc='within 20\\%' if (d.err.abs()<=0.2).all() else 'direction only'
    rows.append(f"{nm[f]} & {tau[f]} & {prs} & {cellr(d,'air_2mm')} & {cellr(d,'silicone_2mm')} & {outc}"+r' \\')
for f in ['lumped_tau10','twonode_tau5']:
    d=e6[e6.variant==f]; pr=d.predicted.iloc[0]; outc='within 20\\%' if (d.err.abs()<=0.2).all() else 'direction only'
    rows.append(f"{nm[f]} & {tau[f]} & {pr:.2f} & {cellr(d,'air_2mm')} & {cellr(d,'silicone_2mm')} & {outc}"+r' \\')
out.append(r"""\begin{table}[t]
\caption{Slope of the containment boundary relative to the baseline slope at the 10\% escape level, with seed-block bootstrap 95\% intervals ($B=1000$). Slopes are fitted to $\eta^*_{10}$ estimates below the grid edge, with at least three per fit. Predictions for the first five variants were recorded before campaign P5 was run (reference calibration v2.0, $\tau_\mathrm{ej}=10$ s, predicted baseline exposure time 93 s). The prediction for the trigger prior is the scale factor of Eq.~(\ref{eq:closed}), $(190-25)/(210-25)=0.89$, not a change of $\tau$. $k_r$ in W\,m$^{-1}$\,K$^{-1}$}\label{tab:p5}
\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.30\textwidth}ccccl@{}}
\toprule
 & \multicolumn{2}{c}{Predicted} & \multicolumn{2}{c}{Measured ratio (95\% interval)} & \\
Variant & $\tau$ (s) & Ratio & Air gap & Silicone & Outcome\\
\midrule
"""+'\n'.join(rows)+r"""
\botrule
\end{tabular}
\footnotetext[a]{Fewer than three estimates below the grid edge.}
\footnotetext[b]{Control added in campaign P6e; the prediction applies the same formula but was evaluated after the runs.}
\end{table}""")
# ---------------- Table: robustness checks (P6, P7)
a = pd.read_csv(RV + 'P6a_rule.csv'); c6 = pd.read_csv(RV + 'P6c_critical_eta.csv'); d6 = pd.read_csv(RV + 'P6d_critical_eta.csv')
ds = pd.read_csv(RV + 'P6d_structure.csv').set_index('split'); dr = pd.read_csv(RV + 'P6d_rule.csv'); pf = pd.read_csv(RV + 'P6f_paired.csv').set_index('config')
L7a, L7b, L7c, L7d = J('ledger_R2_P7a.json'), J('ledger_R2_P7b.json'), J('ledger_R2_P7c.json'), J('ledger_R2_P7d.json')
k_rng = a.groupby('filler').kappa.agg(['min', 'max']); e_rng = a.groupby('filler').eta0.agg(['min', 'max'])
row_a = ("Calibration matched to the internal ($\\tau_\\mathrm{ej}=14$ s) or surface (20 s) peak (P6a) & "
         f"$\\eta_0$: {e_rng.loc['air_2mm','min']:.3f}--{e_rng.loc['air_2mm','max']:.3f}, {e_rng.loc['foam_2mm','min']:.3f}--{e_rng.loc['foam_2mm','max']:.3f}, {e_rng.loc['silicone_2mm','min']:.3f}--{e_rng.loc['silicone_2mm','max']:.3f}; "
         f"$\\kappa$: {k_rng.loc['air_2mm','min']:.4f}--{k_rng.loc['air_2mm','max']:.4f}, {k_rng.loc['foam_2mm','min']:.4f}--{k_rng.loc['foam_2mm','max']:.4f}, {k_rng.loc['silicone_2mm','min']:.4f}--{k_rng.loc['silicone_2mm','max']:.4f} (air, foam, silicone; $\\eta$ step 0.1); $R^2\\ge{a.R2.min():.3f}$")
base = c6[c6.tag == 'baseline'].set_index(['G', 'h_c']); dd = [r.eta10 - base.loc[(r.G, r.h_c)].eta10 for _, r in c6[c6.tag != 'baseline'].iterrows() if np.isfinite(r.eta10) and np.isfinite(base.loc[(r.G, r.h_c)].eta10)]
row_c = f"Trigger SD 8 or 16 \\textdegree C; bounds 165--260 \\textdegree C (P6c) & $\\eta^*_{{10}}$ changed by ${min(dd):+.3f}$ to ${max(dd):+.3f}$ (three variants, four settings)"
eq = d6[d6.tag == 'equal'].set_index(['G', 'h_c']); dl = [r.eta10 - eq.loc[(r.G, r.h_c)].eta10 for _, r in d6[d6.tag == 'dir4'].iterrows() if np.isfinite(r.eta10) and np.isfinite(eq.loc[(r.G, r.h_c)].eta10)]
row_d = (f"Directional split of captured ejecta, Dirichlet concentration 4 or 1 (P6d) & mild: $\\eta^*_{{10}}$ lower by {-max(dl):.2f}--{-min(dl):.2f}, still linear ($R^2\\ge{dr[dr.tag=='dir4'].R2.min():.3f}$); partial cascades at transition points "
         f"{ds.loc['equal','partial_frac_all']*100:.0f}\\%, {ds.loc['dir4','partial_frac_all']*100:.0f}\\%, {ds.loc['dir1','partial_frac_all']*100:.0f}\\% (equal, mild, strong); no escape without a first-ring failure")
row_e = "Lumped-cell controls, reference calibration v2.0 (P6e) & Table~\\ref{tab:p5}: the lumped cell misses the predicted slope with either ejection lag; the two-node cell with a 5 s lag matches it"
row_f = (f"Array size, initiator position, missing-neighbour vent share (P6f) & $7\\times7$ vs $5\\times5$: {int(pf.loc['7x7_centre|lost','more_escape']+pf.loc['7x7_centre|lost','less_escape'])} of {int(pf.loc['7x7_centre|lost','runs']):,} paired outcomes differ; "
         f"boundary initiators more vulnerable, mainly with silicone (Fig.~\\ref{{fig:directional}}d); redistributing the missing share raises the pooled escape probability to {pf.loc['5x5_edge|redist','P_esc']:.2f} (edge) and {pf.loc['5x5_corner|redist','P_esc']:.2f} (corner) against {pf['P_esc_ref'].iloc[0]:.2f}")
row_7c = (f"Conduction-only diagonal links (P7c) & 0 of {L7c['escapes']:,} escapes without a first-ring failure; {L7c['less_escape']} fewer and {L7c['more_escape']} more escapes than with face links only ({L7c['paired_n']:,} paired runs); "
          f"$\\eta^*_{{10}}$ higher by {min(r['d'] for r in L7c['eta10']):.3f}--{max(r['d'] for r in L7c['eta10']):.3f}")
row_7a = (f"Excess heat for $\\eta>1$ released with a 30 s or 120 s lag, same energy (P7a) & {L7a['comb30']['less_escape']} and {L7a['comb120']['less_escape']} fewer escapes, 0 more, at $\\eta>1$; "
          f"$\\eta^*_{{10}}$ above 1 raised by up to {L7a['d30_range'][1]:.2f} (30 s) and {L7a['d120_range'][1]:.2f} or beyond the grid (120 s)")
row_7b = (f"Near-boundary points extended from 40 to 200 seeds (P7b) & {L7b['points_extended']} points; highest escape probability {L7b['max_P200']:.3f}; $\\eta^*_{{10}}$ changed by at most {L7b['d_eta10'][1]:.4f}")
row_7d = (f"$\\eta$ grid of step 0.02 at all 20 design-rule settings (P7d) & $\\eta^*_{{10}}$ higher than the map estimate by {L7d['d10'][0]:.3f}--{L7d['d10'][2]:.3f} (median {L7d['d10'][1]:.3f}); $\\eta^*_{{50}}$ by ${L7d['d50'][0]:+.3f}$ to ${L7d['d50'][2]:+.3f}$; used in Table~\\ref{{tab:crit}} and Eq.~(\\ref{{eq:rule}})")
R8a, R8b, LOW = J('ledger_R3_radiation.json'), J('ledger_R3_numerics.json'), J('ledger_R3_loweta.json')
dtmax = max(v['dt_max'] for v in R8b.values()); flips = sum(v['gained'] + v['lost'] for v in R8b.values()); nr8b = sum(v['runs'] for v in R8b.values())
row_8a = (f"Radiation at the geometric view factor of adjacent cans, $F_\\mathrm{{rad}}=0.16$ (P8a) & {R8a['less_escape']} fewer and {R8a['more_escape']} more escapes ({R8a['runs']} paired runs); $\\eta^*_{{10}}$ higher by {R8a['d10'][0]:.3f}--{R8a['d10'][1]:.3f}")
row_8b = (f"Coupling step and sub-steps halved at three demanding settings (P8b) & {flips} of {nr8b} paired outcomes and no cascade size changed; first-neighbour failure times within {dtmax:.2f} s")
lw = [r_ for r_ in LOW['crit'] if r_['tag'] == 'dir1']
row_d = row_d + f"; strong: $\\eta^*_{{10}}$ = {min(r_['eta10'] for r_ in lw):.2f}--{max(r_['eta10'] for r_ in lw):.2f} at the five settings at or below the map grid (P8c)"
bt = pd.read_csv(RV + 'R3_rom_beta_rule.csv'); kb = {b: (bt[bt.beta == b].kappa.min(), bt[bt.beta == b].kappa.max()) for b in ('beta0', 'beta0.15', 'beta0.3')}
row_b = (f"Fraction $\\beta$ of vent heat into the core 0, 0.15, 0.3 (reduced-order model) & boundary linear at every $\\beta$; slope {kb['beta0'][0]:.4f}--{kb['beta0'][1]:.4f}, {kb['beta0.15'][0]:.4f}--{kb['beta0.15'][1]:.4f} and {kb['beta0.3'][0]:.4f}--{kb['beta0.3'][1]:.4f} across the fillers")
cr = pd.read_csv(RV + 'R3_rom_correlated.csv')
row_cr = (f"Neighbours' trigger mean up to 12 \\textdegree C lower when the initiator's ejecta share is high (reduced-order model) & $\\eta^*_{{10}}$ changed by ${min(cr.d6.min(), cr.d12.min()):.2f}$ to ${max(cr.d6.max(), cr.d12.max()):.2f}$ (three fillers, $h_c=2$, 10 and 35)")
rws = [row_7d, row_7b, row_8b, row_a, row_c, row_cr, row_b, row_7a, row_8a, row_7c, row_d, row_e, row_f]
out.append(r"""\begin{table}[t]
\caption{Robustness checks (calibration v2.1 unless stated). Settings and results in Sects.~\ref{sec:ring}--\ref{sec:directional}}\label{tab:robust}
\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{@{}>{\raggedright\arraybackslash}p{0.33\textwidth}>{\raggedright\arraybackslash}p{0.61\textwidth}@{}}
\toprule
Check & Result\\
\midrule
""" + "\n".join(r_ + r" \\" for r_ in rws) + r"""
\botrule
\end{tabular}
\end{table}""")
os.makedirs(os.path.join(HERE, 'output'), exist_ok=True)
open(os.path.join(HERE, 'output', 'tables_generated.tex'), 'w').write('\n\n'.join(out))
print('tables:', [s[s.index('label{') + 6:s.index('}', s.index('label{'))] for s in out])
