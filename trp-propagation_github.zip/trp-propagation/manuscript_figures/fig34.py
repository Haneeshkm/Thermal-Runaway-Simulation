import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
from figstyle import *; setup()
import numpy as np, pandas as pd, campaign as C
df = C.summarise(os.path.join(ROOT,'results_v2','P1b_phase_v21.jsonl.gz')); df['G'] = df.G_lo; df['eta'] = df.eta_lo
crit = pd.read_csv(os.path.join(ROOT,'analysis','T_critical_eta_v21.csv'))
fit = pd.read_csv(os.path.join(ROOT,'analysis','T_design_rule_fit_v21.csv'))
# boundary estimates: fine grid (P7d) for the insulating fillers, coarse grid (P1b) elsewhere
import json
fine = pd.read_csv(os.path.join(ROOT, 'analysis', 'T_critical_eta_fine.csv'))
LD = json.load(open(os.path.join(ROOT, 'analysis', 'review', 'ledger_R2_P7d.json')))
def bound(G, h):
    f = fine[np.isclose(fine.G, G) & np.isclose(fine.h_c, h)]
    if len(f): return float(f.eta10.iloc[0])
    c = crit[np.isclose(crit.G, G) & np.isclose(crit.h_c, h)]
    return float(c.eta10.iloc[0]) if len(c) else np.nan
# ---------- Fig 3: maps
fig, axs = plt.subplots(1, 5, figsize=(174*MM, 52*MM), sharey=True)
for k, (ax, (g, G)) in enumerate(zip(axs, C.G_CASES.items())):
    d = df[np.isclose(df.G, G)].pivot_table(index='eta', columns='h_c', values='P_esc')
    etas, hcs = d.index.values, d.columns.values
    im = ax.pcolormesh(np.arange(len(hcs)+1), np.arange(len(etas)+1), d.values, vmin=0, vmax=1, cmap='cividis', rasterized=True)
    xs, ys = [], []
    for i_, h in enumerate(hcs):
        e = bound(G, h)
        if np.isfinite(e) and e <= etas.max(): xs.append(i_+0.5); ys.append(np.interp(e, etas, np.arange(len(etas))) + 0.5)
    if xs: ax.plot(xs, ys, color='white', lw=1.4, marker='o', ms=2.5, mec='k', mew=0.4)
    ax.set_xticks(np.arange(len(hcs))+0.5); ax.set_xticklabels([f'{h:g}' for h in hcs], rotation=90, fontsize=6)
    ax.set_yticks(np.arange(len(etas))+0.5); ax.set_yticklabels([f'{e:g}' for e in etas], fontsize=6)
    short={'air_2mm':'air gap','foam_2mm':'foam','silicone_2mm':'silicone','potting1_2mm':'potting, k = 1','potting2.4_2mm':'potting, k = 2.4'}
    ax.set_title(short[g] + f'\nG = {G:.3g} W K$^{{-1}}$', fontsize=7)
    ax.set_xlabel('$h_c$ (W m$^{-2}$ K$^{-1}$)', fontsize=7)
    ax.spines['top'].set_visible(True); ax.spines['right'].set_visible(True)
    panel(ax, 'abcde'[k], x=-0.05, y=1.17)
axs[0].set_ylabel('captured-ejecta fraction η')
cb = fig.colorbar(im, ax=axs, fraction=0.015, pad=0.01); cb.set_label('P(escape from first ring)', fontsize=7); cb.ax.tick_params(labelsize=6)
save(fig, 'Fig3')
# ---------- Fig 4: boundary + linear rule (fine grid), with per-cell UA axis
A_S = 0.008
fig, ax = plt.subplots(figsize=(120*MM, 82*MM))
for g, (lab, col, mk) in FILLER.items():
    if g.startswith('potting'): continue
    G = C.G_CASES[g]; d = fine[np.isclose(fine.G, G)].sort_values('h_c')
    lo = (d.eta10 - d.eta10_lo).clip(lower=0); hi = (d.eta10_hi - d.eta10).clip(lower=0)
    ax.errorbar(d.h_c, d.eta10, yerr=[lo, hi], fmt=mk, ms=4, mfc=col, mec='k', mew=0.5, ecolor=col, elinewidth=0.8, capsize=2, ls='none', label=lab)
    r = LD[f'rule10_{g}']; hh = np.linspace(0, 100, 50); ax.plot(hh, r['eta0'] + r['kappa']*hh, color=col, lw=0.9)
ax.axhline(1.0, color=OI['grey'], lw=0.6, ls=':')
ax.text(99, 1.005, 'all ejecta energy captured', fontsize=6.3, color=OI['grey'], ha='right', va='bottom')
ax.text(3, 1.50, 'conductive potting (k = 1 and 2.4): η*$_{10}$ ≥ 1.49 at $h_c$ = 2,\nand > 1.5 for every $h_c$ ≥ 5 (not shown)', fontsize=6.3, va='top')
kmin = min(LD[f'rule10_{g}']['kappa'] for g in ('air_2mm','foam_2mm','silicone_2mm')); kmax = max(LD[f'rule10_{g}']['kappa'] for g in ('air_2mm','foam_2mm','silicone_2mm'))
ax.text(58, 0.72, f'lines: η*$_{{10}}$ = η$_0$ + κ $h_c$\nκ = {kmin:.4f}–{kmax:.4f} m$^2$ K W$^{{-1}}$', fontsize=6.5, va='top')
ax.set_xlim(0, 100); ax.set_ylim(0.5, 1.55)
ax.set_xlabel('cooling coefficient $h_c$ (W m$^{-2}$ K$^{-1}$)'); ax.set_ylabel('critical captured-ejecta fraction η*$_{10}$')
sec = ax.secondary_xaxis('top', functions=(lambda h: h * A_S, lambda u: u / A_S)); sec.set_xlabel('per-cell conductance to coolant UA = $h_c A_s$ (W K$^{-1}$)', fontsize=7); sec.tick_params(labelsize=7)
ax.legend(frameon=False, loc='upper left', bbox_to_anchor=(0.0, 0.84), fontsize=6.5)
save(fig, 'Fig4')
