import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
from figstyle import *; setup()
import numpy as np, pandas as pd, statsmodels.api as sm, campaign as C, matplotlib
P = os.path.join(ROOT, 'analysis') + '/'
P1 = pd.read_pickle(P+'cache/P1b_tidy.pkl')
# ---------- Fig 5
fig, axs = plt.subplots(1, 2, figsize=(174*MM, 60*MM))
ax = axs[0]; k = np.arange(5)
import json as _j; BK = _j.load(open(os.path.join(ROOT, 'analysis', 'review', 'ledger_R3b.json')))['PescK_bootstrap']
pe = np.array([BK[str(k_)]['P'] for k_ in range(5)]); lo = pe - np.array([BK[str(k_)]['ci'][0] for k_ in range(5)]); hi = np.array([BK[str(k_)]['ci'][1] for k_ in range(5)]) - pe; nn = np.array([BK[str(k_)]['n'] for k_ in range(5)])
ax.bar(k, pe, 0.6, color=OI['blue'], ec='k', lw=0.5, yerr=[lo, hi], capsize=2, error_kw=dict(lw=0.7))
for i_ in k: ax.text(i_, min(pe[i_] + hi[i_], 1.0) + 0.04, f'{pe[i_]:.2f}\nn = {nn[i_]:,}', ha='center', fontsize=6.3)
ax.set_xlabel('first-ring cells failed, K (of 4)'); ax.set_ylabel('P(escape beyond first ring)'); ax.set_ylim(0, 1.3); ax.set_xticks(k)
ax.set_yticks(np.arange(0, 1.01, 0.2))
panel(ax, 'a')
perc = pd.read_csv(P+'T_percolation_v21.csv'); ic = pd.read_csv(os.path.join(ROOT, 'analysis', 'review', 'R2_independent_cascade.csv'))
ax = axs[1]; x = np.arange(2); w = 0.26
def bar(xs, vals, col, hatch, lab):
    m = np.array([v.mean() for v in vals]); lo = m - np.array([v.min() for v in vals]); hi = np.array([v.max() for v in vals]) - m
    ax.bar(xs, m, w, yerr=[lo, hi], color=col, ec='k', lw=0.5, hatch=hatch, capsize=2, error_kw=dict(lw=0.7), label=lab)
bar(x - w, [perc.obs_partial_frac, perc.obs_full_frac], OI['blue'], None, 'simulated (Monte Carlo)')
bar(x, [perc.perc_partial_frac, perc.perc_full_frac], '#D9D9D9', '////', 'bond percolation, matched mean K')
bar(x + w, [ic.ic_partial, ic.ic_full], '#F6D7A7', '\\\\', 'independent cascade, matched K distribution')
ax.set_xticks(x); ax.set_xticklabels(['partial cascades\n(1 < n < 25)', 'full cascades\n(n = 25)'])
ax.set_ylabel('fraction of runs'); ax.set_ylim(0, 1.45); ax.set_yticks(np.arange(0, 1.01, 0.2)); ax.legend(frameon=False, loc='upper center', fontsize=6.0, ncol=1)
panel(ax, 'b')
plt.tight_layout(w_pad=2); save(fig, 'Fig5')
# ---------- Fig 6
att = pd.read_csv(P+'T_attribution_v21_cluster.csv', index_col=0)
names = {'Ttrig_r1_min_z':'lowest trigger temperature\nin the first ring', 'fej_ini_z':'initiator ejecta share $f_{ej}$',
         'fej_r1_mean_z':'mean first-ring ejecta share'}
fig, ax = plt.subplots(figsize=(100*MM, 45*MM))
y = np.arange(len(att))[::-1]
orr = att.OR.values; lo = att.CI_lo.values; hi = att.CI_hi.values
ax.errorbar(orr, y, xerr=[orr-lo, hi-orr], fmt='o', color='k', ms=4, capsize=2, elinewidth=0.8)
ax.axvline(1, color=OI['grey'], lw=0.6, ls='--')
for yi, o in zip(y, orr): ax.text(o, yi+0.22, f'{o:.2f}', ha='center', fontsize=6.5)
ax.set_yticks(y); ax.set_yticklabels([names[i] for i in att.index]); ax.set_xscale('log')
ax.set_xlabel('odds ratio for escape per prior SD (95% CI)'); ax.set_ylim(-0.6, len(att)-0.3)
ax.set_xticks([0.3,0.5,1,2,5,10]); ax.set_xticklabels(['0.3','0.5','1','2','5','10']); ax.minorticks_off(); ax.set_xlim(0.3, 12)
save(fig, 'Fig6')
# ---------- Fig 7
rom = pd.read_csv(P+'T_rom_vs_mc_fine.csv'); crit = pd.read_csv(P+'T_critical_eta_fine.csv')
rom['filler'] = rom.filler.str.replace('_2mm', '', regex=False)
import json; CF = json.load(open(os.path.join(ROOT, 'analysis', 'review', 'ledger_R3_fine.json')))['closed10_mean']
mk = {'air':('air gap','o',OI['blue']), 'foam':('insulating foam','s',OI['orange']), 'silicone':('insulating silicone','D',OI['green'])}
fig, axs = plt.subplots(1, 2, figsize=(174*MM, 72*MM))
ax = axs[0]
for f, (lab, m, col) in mk.items():
    d = rom[rom.filler == f]
    for L, filled in (('10', True), ('50', False)):
        dd = d[np.isfinite(d[f'MC_eta{L}']) & np.isfinite(d[f'ROM_eta{L}'])]
        ax.plot(dd[f'MC_eta{L}'], dd[f'ROM_eta{L}'], m, ms=4, mfc=col if filled else 'white', mec=col if not filled else 'k', mew=0.6, ls='none')
    ax.plot([], [], m, ms=4, mfc=col, mec='k', mew=0.5, ls='none', label=lab)
ax.plot([0.55, 1.55], [0.55, 1.55], 'k-', lw=0.6)
ax.plot([], [], 'o', ms=4, mfc='grey', mec='k', mew=0.5, ls='none', label='filled: 10% escape')
ax.plot([], [], 'o', ms=4, mfc='white', mec='grey', mew=0.6, ls='none', label='open: 50% escape')
ax.set_xlabel('critical η, Monte Carlo'); ax.set_ylabel('critical η, reduced-order model'); ax.set_xlim(0.55, 1.55); ax.set_ylim(0.55, 1.55)
ax.set_aspect('equal'); ax.legend(frameon=False, fontsize=6, loc='lower right', handletextpad=0.3); panel(ax, 'a')
# closed form fitted to the fine-grid Monte Carlo eta*10 (parameters from the seed-block bootstrap analysis)
A_s = 0.008; fEz = 0.825*83.9e3/4; dT = 185.0
d = crit[np.isfinite(crit.eta10)].copy()
ax = axs[1]; hh = np.linspace(0, 80, 50)
inv = {0.013:'air', 0.041:'foam', 0.102:'silicone'}
for G, f in inv.items():
    lab, mm_, col = mk[f]; dd = d[np.isclose(d.G, G)]
    ax.plot(dd.h_c, dd.eta10, mm_, ms=4, mfc=col, mec='k', mew=0.4, ls='none', label=f'{lab}, Monte Carlo')
    pred = (CF['C_eff'] + CF['tau_h']*hh*A_s + CF['tau_G']*3*G)*dT/fEz
    ax.plot(hh, pred, color=col, lw=0.9)
ax.set_xlabel('cooling coefficient $h_c$ (W m$^{-2}$ K$^{-1}$)'); ax.set_ylabel('critical captured-ejecta fraction η*$_{10}$')
ax.text(2, 1.47, f"closed form: $C_{{eff}}$ = {CF['C_eff']:.0f} J K$^{{-1}}$, $\\tau_h$ = {CF['tau_h']:.0f} s,\n$\\tau_G$ = {CF['tau_G']:.0f} s, R$^2$ = {CF['R2']:.3f}", fontsize=6.3, va='top')
ax.set_ylim(0.55, 1.5); ax.legend(frameon=False, fontsize=6, loc='lower right'); panel(ax, 'b')
plt.tight_layout(w_pad=2); save(fig, 'Fig7')
# ---------- Fig 8
t = pd.read_csv(os.path.join(ROOT, 'analysis', 'review', 'P5_slope_ratios_bootstrap.csv')); t = t[t.predicted.notna()]
e6 = pd.read_csv(os.path.join(ROOT, 'analysis', 'review', 'P6e_slope_ratios_bootstrap.csv'))
lab = {'k_r=0.40':('radial conductivity 0.40','o',OI['vermillion']), 'k_r=1.50':('radial conductivity 1.50','s',OI['blue']),
       'tau_ej=20':('ejection lag 20 s','D',OI['green']), 'Ttrig=N(190,12)':('trigger prior 190 °C','v',OI['orange']),
       'lumped':('lumped cell, lag 5 s','^',OI['purple']), 'lumped_tau10':('lumped cell, lag 10 s (control)','<',OI['sky']),
       'twonode_tau5':('two-node, lag 5 s (control)','>',OI['grey'])}
fig, ax = plt.subplots(figsize=(90*MM, 82*MM))
x = np.logspace(-1.15, 0.6, 20); ax.fill_between(x, x/1.2, x*1.2, color='#D9D9D9', lw=0, label='±20%'); ax.plot(x, x, 'k-', lw=0.6)
for df_, key in ((t, 'variant'), (e6, 'variant')):
    for _, r in df_.iterrows():
        l, m_, col = lab[r[key]]
        ax.errorbar(r.predicted, r.ratio, yerr=[[r.ratio - r.ratio_lo], [r.ratio_hi - r.ratio]], fmt=m_, ms=5,
                    mfc=col if r.filler == 'air_2mm' else 'white', mec=col if r.filler != 'air_2mm' else 'k', mew=0.7, ecolor=col, elinewidth=0.7, capsize=1.5)
for key, (l, m_, col) in lab.items(): ax.plot([], [], m_, ms=5, mfc=col, mec='k', mew=0.5, ls='none', label=l)
ax.plot([], [], 'o', ms=5, mfc='white', mec='k', mew=0.7, ls='none', label='open: silicone filler')
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(0.07, 4); ax.set_ylim(0.07, 4)
for a in (ax.xaxis, ax.yaxis):
    a.set_ticks([0.1,0.2,0.5,1,2]); a.set_ticklabels(['0.1','0.2','0.5','1','2']); a.set_minor_locator(matplotlib.ticker.NullLocator())
ax.set_xlabel('predicted slope ratio, exposure-time formula'); ax.set_ylabel('measured slope ratio (95% CI)')
ax.legend(frameon=False, fontsize=5.6, loc='upper left'); ax.set_aspect('equal')
save(fig, 'Fig8')
# ---------- Fig 9
e = pd.read_csv(P+'T_epistemic_paired.csv'); cd = pd.read_csv(os.path.join(ROOT, 'analysis', 'review', 'R3_P2_cell_dP.csv'))
FDR = json.load(open(os.path.join(ROOT, 'analysis', 'review', 'ledger_R2a.json')))['P2_fdr']['by_tag']
nm = {'trigger=surface':'trigger on can temperature','lumped':'lumped cell','isc_rule=rate':'internal short by heating rate',
      'k_r=0.40':'radial conductivity 0.40','beta=0.3':'30% of ejecta heat into core','ejecta=debit':'instant ejecta removal',
      'k_r=1.50':'radial conductivity 1.50','Ttrig=N(190,12)':'trigger prior 190 °C','f_core=0.70':'core fraction 0.70',
      'f_core=0.95':'core fraction 0.95','tau_ej=5':'ejection lag 5 s','tau_ej=20':'ejection lag 20 s','isc_dur=20':'short duration 20 s',
      'isc_dur=5':'short duration 5 s','radiation=off':'radiation off','Ttrig=N(230,12)':'trigger prior 230 °C'}
fig, (ax, ax2) = plt.subplots(1, 2, figsize=(160*MM, 92*MM), gridspec_kw={'width_ratios': [3.2, 1]})
ep = e[e.assumption != 'trigger=surface'].sort_values('mean_dP'); y = np.arange(len(ep)); rng_ = np.random.default_rng(0)
for yi, (a, v) in enumerate(zip(ep.assumption, ep.mean_dP)):
    col = OI['vermillion'] if v > 0 else OI['blue']
    ax.barh(yi, v, 0.65, color=col, ec='k', lw=0.4, hatch='////' if v > 0 else None, alpha=0.85)
    d = cd[cd.assumption == a].dP.values; ax.scatter(d, yi + rng_.uniform(-0.22, 0.22, len(d)), s=4, color='k', alpha=0.45, lw=0, zorder=3)
    ax.text(1.04, yi, f"{FDR[a]['sig_raw']} ({FDR[a]['sig_bh']})", va='center', ha='left', fontsize=6, transform=ax.get_yaxis_transform())
ax.set_yticks(y); ax.set_yticklabels([nm[a] for a in ep.assumption], fontsize=6.5); ax.axvline(0, color='k', lw=0.6)
ax.set_xlabel('change in P(escape) relative to reference'); ax.set_xlim(-1.05, 1.05); panel(ax, 'a')
ax.text(1.04, len(ep) - 0.2, 'cells sig.', fontsize=6, ha='left', transform=ax.get_yaxis_transform())
a = 'trigger=surface'; v = float(e[e.assumption == a].mean_dP.iloc[0]); d = cd[cd.assumption == a].dP.values
ax2.bar(0, v, 0.6, color='#BDBDBD', ec='k', lw=0.4, hatch='xxx'); ax2.scatter(rng_.uniform(-0.2, 0.2, len(d)), d, s=4, color='k', alpha=0.45, lw=0, zorder=3)
ax2.set_xticks([0]); ax2.set_xticklabels(['trigger on can\n(inconsistent,\nsanity check)'], fontsize=6.3); ax2.set_ylim(-0.05, 1.18); ax2.set_yticks(np.arange(0, 1.01, 0.2)); ax2.set_ylabel('change in P(escape)', fontsize=7)
ax2.text(0, 1.09, f"cells sig.: {FDR[a]['sig_raw']} ({FDR[a]['sig_bh']})", ha='center', va='bottom', fontsize=6); panel(ax2, 'b')
plt.tight_layout(w_pad=1.0); save(fig, 'Fig9')
print('done')
