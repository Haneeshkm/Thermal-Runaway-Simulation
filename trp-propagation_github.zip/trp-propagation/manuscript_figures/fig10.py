import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
from figstyle import *; setup()
import numpy as np, pandas as pd
RV = os.path.join(ROOT, 'analysis', 'review')
crit = pd.read_csv(os.path.join(RV, 'P6d_critical_eta.csv')); low = pd.read_csv(os.path.join(RV, 'R3_loweta_critical.csv'))
for _, r_ in low.iterrows():
    m_ = (crit.tag == r_.tag) & np.isclose(crit.G, r_.G) & (crit.h_c == r_.h_c)
    if m_.any(): crit.loc[m_, 'eta10'] = r_.eta10
    else: crit = pd.concat([crit, pd.DataFrame([{'tag': r_.tag, 'G': r_.G, 'h_c': r_.h_c, 'eta10': r_.eta10}])], ignore_index=True)
st = pd.read_csv(os.path.join(RV, 'P6d_structure.csv')).set_index('split')
t2 = pd.read_csv(os.path.join(RV, 'R2_top2_metric.csv')); sf = pd.read_csv(os.path.join(RV, 'R2_P6f_stratified.csv')).set_index('cfg')
fig, axs = plt.subplots(2, 2, figsize=(174*MM, 120*MM)); axs = axs.ravel()
# (a) boundary under vent split
ax = axs[0]; sty = {'equal': ('equal split', OI['black'], 'o'), 'dir4': ('directional, mild (c = 4)', OI['orange'], 's'), 'dir1': ('directional, strong (c = 1)', OI['vermillion'], '^')}
for tag, (lab, col, mk) in sty.items():
    for G, ls, filled in ((0.013, '-', True), (0.102, '--', False)):
        d = crit[(crit.tag == tag) & np.isclose(crit.G, G) & np.isfinite(crit.eta10)].sort_values('h_c')
        if not d.empty: ax.plot(d.h_c, d.eta10, ls=ls, marker=mk, color=col, ms=3.5, mfc=col if filled else 'white', lw=0.9)
for tag, (lab, col, mk) in sty.items(): ax.plot([], [], marker=mk, color=col, ls='-', ms=3.5, label=lab)
ax.plot([], [], 'k-', label='air gap (filled)'); ax.plot([], [], 'k--', label='silicone (open)')
ax.set_xlabel('$h_c$ (W m$^{-2}$ K$^{-1}$)'); ax.set_ylabel('critical captured fraction η*$_{10}$'); ax.set_ylim(0.2, 1.85); ax.set_yticks(np.arange(0.2, 1.61, 0.2))
ax.legend(frameon=False, fontsize=5.6, loc='upper left'); panel(ax, 'a')
# (b) cascade structure at transition points
ax = axs[1]; tags = ['equal', 'dir4', 'dir1']; x = np.arange(3); w = 0.36
ax.bar(x - w/2, [st.loc[t, 'partial_frac_all'] for t in tags], w, color=OI['sky'], ec='k', lw=0.5, label='partial cascades (of all runs)')
ax.bar(x + w/2, [st.loc[t, 'full_given_escape'] for t in tags], w, color=OI['blue'], ec='k', lw=0.5, hatch='////', label='full module loss, given escape')
ax.set_xticks(x); ax.set_xticklabels(['equal', 'mild (c = 4)', 'strong (c = 1)']); ax.set_xlabel('split of captured ejecta'); ax.set_ylabel('fraction of runs at transition points')
ax.set_ylim(0, 1.25); ax.set_yticks(np.arange(0, 1.01, 0.2)); ax.legend(frameon=False, fontsize=5.8, loc='upper center'); panel(ax, 'b')
# (c) exposure metrics: mean absolute split offset in log-odds
ax = axs[2]; xs = ['eta', 'eta_eff1', 'eta_eff2']; labs = ['total captured\nfraction η', 'largest share\n4ηw$_{(1)}$', 'two largest shares\n2η(w$_{(1)}$+w$_{(2)}$)']
m4 = [t2[t2.x == k].abs_dir4.mean() for k in xs]; m1 = [t2[t2.x == k].abs_dir1.mean() for k in xs]; x = np.arange(3)
ax.bar(x - w/2, m4, w, color=OI['orange'], ec='k', lw=0.5, label='mild (c = 4)'); ax.bar(x + w/2, m1, w, color=OI['vermillion'], ec='k', lw=0.5, hatch='\\\\\\\\', label='strong (c = 1)')
ax.set_xticks(x); ax.set_xticklabels(labs, fontsize=6.5); ax.set_ylabel('mean |split effect| (log odds)')
ax.legend(frameon=False, fontsize=6, loc='upper right'); panel(ax, 'c')
# (d) boundary condition, stratified by filler and cooling
ax = axs[3]; sets = [('air_2mm_h10', 'air\n$h_c$ = 10'), ('air_2mm_h35', 'air\n$h_c$ = 35'), ('silicone_2mm_h10', 'silicone\n$h_c$ = 10'), ('silicone_2mm_h35', 'silicone\n$h_c$ = 35')]
cfgs = [('5x5_centre|lost', '5×5 centre', '#FFFFFF', None), ('5x5_edge|lost', 'edge, share lost', '#D9D9D9', None),
        ('5x5_corner|lost', 'corner, share lost', '#8C8C8C', None), ('5x5_edge|redist', 'edge, share redistributed', OI['orange'], '\\\\\\\\'),
        ('5x5_corner|redist', 'corner, share redistributed', OI['vermillion'], '////')]
x = np.arange(len(sets)); w4 = 0.16
for k, (cf, lab, col, hat) in enumerate(cfgs):
    ax.bar(x + (k - 2)*w4, [sf.loc[cf, s] for s, _ in sets], w4, color=col, ec='k', lw=0.5, hatch=hat, label=lab)
ax.set_xticks(x); ax.set_xticklabels([l for _, l in sets], fontsize=6.5); ax.set_ylabel('P(escape), pooled over η = 0.6–1.3')
ax.set_ylim(0, 1.3); ax.set_yticks(np.arange(0, 1.01, 0.2)); ax.legend(frameon=False, fontsize=5.6, loc='upper center', ncol=2); panel(ax, 'd')
plt.tight_layout(h_pad=1.2, w_pad=1.2); save(fig, 'Fig10')
