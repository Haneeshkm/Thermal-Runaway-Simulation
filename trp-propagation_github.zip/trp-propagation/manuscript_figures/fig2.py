import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE); sys.path.insert(0, ROOT)
from figstyle import *; setup()
import numpy as np, trp_v2 as V
from matplotlib.patches import Rectangle
cfg = V.baseline_v2(calib='v2.1', n_rows=1, n_cols=1, h_c=2.0, fej_lo=0.83, fej_hi=0.83, t_max=900, early_stop=False,
                    T_seed=210.0, Ttrig_mean=205.0, Ttrig_lo=200.0, Ttrig_hi=209.0, sd_mass=0, sd_Cp=0, sd_H=0, record_history=True)
r = V.run(cfg, 0); L = r['ledger']; h = r['history']
t = np.array(h['t']); Ts = np.array(h['T'])[:,0]; Tc = np.array(h['Tc'])[:,0]
E_isc = cfg.omega*V.M50_E_ELEC*0.070/V.M50_MCELL_REF; E_tot = L['chem_released']; E_chem = E_tot - E_isc
E_ej = L['ejecta_removed']; E_body = E_tot - E_ej
print(f"total {E_tot/1e3:.1f} kJ; chem {E_chem/1e3:.1f}; ISC {E_isc/1e3:.1f}; ejecta {E_ej/1e3:.1f}; body {E_body/1e3:.1f}; can {Ts.max():.0f}; core {Tc.max():.0f}")
fig, axs = plt.subplots(1, 3, figsize=(174*MM, 58*MM), gridspec_kw={'width_ratios':[1.25,1,0.8]})
# (a) temperatures after trigger
ax = axs[0]
ax.plot(t, Tc, color=OI['vermillion'], lw=1.2, label='core (model)')
ax.plot(t, Ts, color=OI['blue'], lw=1.2, ls='--', label='can (model)')
ax.axhline(753, color=OI['blue'], lw=0.8, ls=':')
ax.axhline(1080, color=OI['vermillion'], lw=0.8, ls=':')
ax.text(60, 760, 'measured mean surface peak, 753 °C', fontsize=6.3, ha='left', va='bottom', color=OI['blue'])
ax.text(60, 1087, 'measured mean internal peak, 1080 °C', fontsize=6.3, ha='left', va='bottom', color=OI['vermillion'])
ax.set_xlim(0, 200); ax.set_ylim(150, 1160); ax.set_xlabel('time after trigger (s)'); ax.set_ylabel('temperature (°C)')
ax.legend(loc='lower right', frameon=False, bbox_to_anchor=(1.0, 0.0), ncol=2, handlelength=1.6, columnspacing=0.8); panel(ax, 'a')
# (b) self-heating rate of a fresh cell (adiabatic), ARC onset
R = 8.314; sc = 0.070/V.M50_MCELL_REF; mCp = 0.070*1100
def q(T):
    k = V.KIM_A*np.exp(-V.KIM_E/(R*T))
    return (V.KIM_H[0]*V.M50_MC*sc*k[0]*0.15 + V.KIM_H[1]*V.M50_MC*sc*k[1]*np.exp(-V.KIM_Z0/V.KIM_ZREF)*0.75
            + V.KIM_H[2]*V.M50_MP*sc*k[2]*0.04*0.96 + V.KIM_H[3]*V.M50_ME*sc*k[3])
TT = np.arange(50, 160, 0.1); rate = np.array([q(x+273.15) for x in TT])/mCp*60
ax = axs[1]; ax.semilogy(TT, rate, color='k', lw=1.1)
ax.axhline(0.02, color=OI['grey'], lw=0.7, ls='--'); ax.text(166, 0.026, 'ARC detection,\n0.02 °C min$^{-1}$', fontsize=6.3, ha='right', va='bottom')
on = TT[np.argmax(rate >= 0.02)]
ax.axvspan(85.5-4.9, 85.5, color=OI['green'], alpha=0.25, lw=0)
ax.plot([on], [0.02], 'o', color=OI['vermillion'], ms=4)
ax.text(95, 0.0012, f'model onset {on:.0f} °C\nmeasured 85.5 °C; shaded:\nheating-step bound (4.9 K)', fontsize=6.3, ha='left')
ax.set_xlabel('temperature (°C)'); ax.set_ylabel('self-heating rate (°C min$^{-1}$)'); ax.set_ylim(1e-4, 10); panel(ax, 'b')
# (c) energy budget
ax = axs[2]; w = 0.55
ax.bar(0, E_chem/1e3, w, color=OI['yellow'], ec='k', lw=0.5, label='chemistry')
ax.bar(0, E_isc/1e3, w, bottom=E_chem/1e3, color=OI['sky'], ec='k', lw=0.5, hatch='\\\\\\', label='internal short')
ax.bar(1, E_body/1e3, w, color='#CFCFCF', ec='k', lw=0.5, label='retained by cell')
ax.bar(1, E_ej/1e3, w, bottom=E_body/1e3, color=OI['vermillion'], ec='k', lw=0.5, hatch='////', label='ejecta')
ax.axhline(83.9, color='k', lw=0.6, ls=':'); ax.text(1.45, 84.8, 'measured mean\n83.9 kJ', fontsize=6.3, ha='right', va='bottom')
ax.set_xticks([0,1]); ax.set_xticklabels(['source', 'fate'])
ax.set_ylabel('energy (kJ)'); ax.set_ylim(0, 105); ax.set_xlim(-0.5, 1.5)
ax.legend(frameon=False, fontsize=6.3, loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=2, handlelength=1.2, columnspacing=0.6)
panel(ax, 'c', x=-0.3)
plt.tight_layout(w_pad=0.8); save(fig, 'Fig2')
