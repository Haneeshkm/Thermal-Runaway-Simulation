import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
OUTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output'); os.makedirs(OUTDIR, exist_ok=True)
MM = 1/25.4
OI = {'black':'#000000','orange':'#E69F00','sky':'#56B4E9','green':'#009E73','yellow':'#F0E442',
      'blue':'#0072B2','vermillion':'#D55E00','purple':'#CC79A7','grey':'#7F7F7F'}
FILLER = {'air_2mm':('air gap', OI['blue'],'o'), 'foam_2mm':('insulating foam', OI['orange'],'s'),
          'silicone_2mm':('insulating silicone', OI['green'],'D'), 'potting1_2mm':('conductive potting, k = 1', OI['purple'],'^'),
          'potting2.4_2mm':('conductive potting, k = 2.4', OI['vermillion'],'v')}
def setup():
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Liberation Sans','DejaVu Sans'],
        'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
        'axes.linewidth':0.6,'lines.linewidth':1.0,'xtick.major.width':0.5,'ytick.major.width':0.5,
        'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,
        'savefig.dpi':600,'mathtext.fontset':'custom','mathtext.rm':'Liberation Sans','mathtext.it':'Liberation Sans:italic',
        'mathtext.bf':'Liberation Sans:bold'})
def panel(ax, s, x=-0.14, y=1.03):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=9, fontweight='bold', va='bottom', ha='left')
def save(fig, name):
    fig.savefig(os.path.join(OUTDIR, f'{name}.pdf'), bbox_inches='tight', pad_inches=0.02)
    fig.savefig(os.path.join(OUTDIR, f'{name}.png'), bbox_inches='tight', pad_inches=0.02, dpi=300)
