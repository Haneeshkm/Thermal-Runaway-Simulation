"""Verification tests V1-V4 for trp_v2 (run: pytest -q tests/ from the repo root)."""
import json, os, sys
import numpy as np
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import trp_v2 as V

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
N_V1 = int(os.environ.get("TRP_N_V1", "100"))


def test_V1_legacy_regression():
    """v2 in legacy mode reproduces the cached v5 ensembles seed-by-seed."""
    for cool in ("air", "liquid"):
        ref = json.load(open(os.path.join(ROOT, "data", f"{cool}_ensemble_N100.json")))["runs"]
        cfg = V.legacy_v5_config(cool)
        for s in range(N_V1):
            r, R = V.run(cfg, s), ref[s]
            assert r["cells"]["trig"] == R["trig"], (cool, s)
            if R["span"] is not None:
                assert abs(r["span"] - R["span"]) < 0.05, (cool, s)
            if R["flux"]:
                for k in ("vent", "cond", "rad"):
                    assert abs(r["first_flux_v5"][k] - R["flux"][k]) < 1e-6, (cool, s, k)


def test_V2_energy_balance():
    for cfg in (V.Config(h_c=2.0), V.Config(h_c=200.0), V.Config(h_c=50.0, cell_model="twonode",
                trigger_node="core"), V.Config(h_c=50.0, vent_model="kinetic")):
        for s in range(5):
            assert abs(V.run(cfg, s)["ledger"]["balance_residual_rel"]) < 5e-3


def test_V3_twonode_lumped_limit():
    """Huge core-surface conductance: two-node outcomes match lumped (paired seeds)."""
    big = V.Config(h_c=2.0, cell_model="twonode", k_r=0.95e3, trigger_node="core", n_coarse=100)
    lum = V.Config(h_c=2.0, cell_model="lumped", n_coarse=100)
    agree = sum(V.run(big, s)["n_trig"] == V.run(lum, s)["n_trig"] for s in range(20))
    assert agree >= 19


def test_V4_vent_budget():
    cfg = V.Config(h_c=2.0, vent_model="pulse")
    for s in range(5):
        r = V.run(cfg, s); c = r["cells"]
        for i, t in enumerate(c["trig"]):
            if t:
                budget = c["eta"][i] * c["fej"][i] * c["Epost"][i]
                assert c["vent_delivered"][i] <= budget * (1 + 1e-9)
        assert r["ledger"]["ejecta_lost_to_enclosure"] >= 0


def test_V2b_baseline_energy_and_budget():
    """v2 baseline (two-node, Kim + ISC, lagged ejection): energy closes and delivery never exceeds ejecta."""
    for kw in (dict(h_c=2.0, eta_lo=0.85, eta_hi=0.85, G_lo=0.013, G_hi=0.013), dict(h_c=200.0)):
        for s in range(3):
            L = V.run(V.baseline_v2(**kw), s)["ledger"]
            assert abs(L["balance_residual_rel"]) < 1e-6
            assert L["ejecta_lost_to_enclosure"] >= -1e-6


def test_V9_single_cell_calibration():
    """Single cell (two-node baseline, nominal properties): total 83.9 kJ +- 1%, can peak within 590-800 C band +- 50."""
    cfg = V.baseline_v2(n_rows=1, n_cols=1, h_c=2.0, fej_lo=0.83, fej_hi=0.83, t_max=900, early_stop=False,
                        T_seed=210.0, Ttrig_mean=205.0, Ttrig_lo=200.0, Ttrig_hi=209.0, sd_mass=0, sd_Cp=0, sd_H=0)
    r = V.run(cfg, 0)
    assert abs(r["ledger"]["chem_released"] - 83.9e3) / 83.9e3 < 0.01
    assert 540.0 < r["cells"]["Tmax_s"][0] < 850.0


def test_V10_directional_vent_and_boundary():
    """New vent options (v2.2): energy closes, and no donor delivers more than eta x its ejected energy."""
    for kw in (dict(vent_split="dirichlet", split_conc=1.0), dict(vent_boundary="redistribute"),
               dict(vent_split="dirichlet", split_conc=4.0, vent_boundary="redistribute", initiator="corner")):
        r = V.run(V.baseline_v2(eta_lo=0.9, eta_hi=0.9, G_lo=0.013, G_hi=0.013, h_c=10.0, **kw), 3)
        assert abs(r["ledger"]["balance_residual_rel"]) < 1e-9, kw
        ej = r["ledger"]["ejecta_removed"]
        assert sum(r["cells"]["vent_delivered"]) <= 0.9 * ej * (1 + 1e-9), kw


def test_V11_diagonal_and_combustion_options():
    """v2.3 options: energy closes; diagonal links carry no vent heat; the delayed combustion kernel conserves added energy."""
    r = V.run(V.baseline_v2(eta_lo=0.9, eta_hi=0.9, G_lo=0.102, G_hi=0.102, h_c=10.0, diag_conduction=True, freeze_others=True, t_max=600.0), 0)
    assert abs(r["ledger"]["balance_residual_rel"]) < 1e-9
    c = r["cells"]
    assert all(c["cum_pre_vent"][i] == 0.0 for i, x in enumerate(c["ring"]) if x == 2 and (i // 5 - 2) != 0 and (i % 5 - 2) != 0)
    kw = dict(eta_lo=1.4, eta_hi=1.4, G_lo=0.013, G_hi=0.013, h_c=10.0, freeze_others=True, t_max=3000.0, early_stop=False)
    a = V.run(V.baseline_v2(comb_tau=0.0, **kw), 0)["cells"]["vent_delivered"][12]
    b = V.run(V.baseline_v2(comb_tau=120.0, **kw), 0)["cells"]["vent_delivered"][12]
    assert abs(a - b) / a < 1e-3
