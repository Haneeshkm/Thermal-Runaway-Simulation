# Campaign results

Place the campaign result files here, downloaded from Zenodo: https://doi.org/10.5281/zenodo.23613481

| File | Campaign | Size |
|---|---|---|
| `P1b_phase_v21.jsonl.gz` | containment maps, calibration v2.1 | 47 MB |
| `P2_epistemic.jsonl.gz` | modelling assumptions (v2.0) | 44 MB |
| `P3_size_position.jsonl.gz` | array size and initiator position (v2.0) | 11 MB |
| `P4b_numerics_v21.jsonl.gz` | numerics audit (v2.1) | 2.6 MB |
| `P5_robustness.jsonl.gz` | pre-registered prediction test (v2.0) | 52 MB |
| `P4c_numerics_mid_v21.jsonl.gz` | numerics at a transition point (v2.1) | 0.5 MB, included here |
| `P6a_v2.1-core.jsonl.gz`, `P6a_v2.1-surf.jsonl.gz` | calibration envelope | 22 MB each |
| `P6b_refine.jsonl.gz` | fine eta grid | 10 MB |
| `P6c_trigger.jsonl.gz` | trigger distribution | 9 MB |
| `P6d_split.jsonl.gz` | directional vent split | 22 MB |
| `P6e_lumped.jsonl.gz` | lumped-cell controls (v2.0) | 15 MB |
| `P6f_size_boundary.jsonl.gz` | size, position, boundary vent | 22 MB |
| `P7a_combustion.jsonl.gz`, `P7b_extend.jsonl.gz`, `P7c_diagonal.jsonl.gz`, `P7d_fine.jsonl.gz` | combustion timing, sampling extension, diagonal conduction, fine eta grid | see archive |

Each line is one run: the point name, seed, input overrides, outcome (`esc`, `full`, `n_trig`), per-cell trigger
times, rings, sampled inputs and peak temperatures, and the module energy ledger.
